package dev.ancientvisuals.mixin;

import dev.ancientvisuals.client.AV;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Read-only click counter for the CPS HUD element. Never generates or alters input. */
@Mixin(Mouse.class)
public abstract class MouseMixin {
    @Inject(method = "onMouseButton", at = @At("HEAD"))
    private void av$cps(long window, int button, int action, int mods, CallbackInfo ci) {
        AV.hook("mouse");
        if (action != GLFW.GLFW_PRESS) return;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (window != mc.getWindow().getHandle() || mc.currentScreen != null) return;
        long now = System.currentTimeMillis();
        if (button == GLFW.GLFW_MOUSE_BUTTON_LEFT) AV.leftCps.record(now);
        else if (button == GLFW.GLFW_MOUSE_BUTTON_RIGHT) AV.rightCps.record(now);
    }
}
