package dev.ancientvisuals.mixin;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.client.fx.FxEvents;
import dev.ancientvisuals.client.hud.Hitmarker;
import dev.ancientvisuals.core.module.ModuleRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.world.GameMode;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Replaces the vanilla crosshair with the configured style (only when the Crosshair module is on) and draws the hitmarker. */
@Mixin(InGameHud.class)
public abstract class InGameHudMixin {
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void av$crosshair(DrawContext ctx, RenderTickCounter tickCounter, CallbackInfo ci) {
        AV.hook("crosshair");
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.options.hudHidden || !mc.options.getPerspective().isFirstPerson()) return;
        if (mc.interactionManager != null && mc.interactionManager.getCurrentGameMode() == GameMode.SPECTATOR) return;
        if (mc.getDebugHud().shouldShowDebugHud()) return;
        int cx = ctx.getScaledWindowWidth() / 2, cy = ctx.getScaledWindowHeight() / 2;
        var cross = AV.crosshair;
        if (cross != null && cross.isEnabled()) {
            if (ModuleRegistry.guard(cross, "render", () -> cross.render(ctx, cx, cy, FxEvents.hitPulse))) ci.cancel();
        }
        Hitmarker.draw(ctx, cx, cy);
    }
}
