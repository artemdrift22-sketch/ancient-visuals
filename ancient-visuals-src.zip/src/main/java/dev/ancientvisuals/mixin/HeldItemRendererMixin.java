package dev.ancientvisuals.mixin;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.core.module.ModuleRegistry;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** First-person only: viewmodel transform and swing-timing remap. Does not change attack speed or reach. */
@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    @ModifyVariable(method = "renderFirstPersonItem", at = @At("HEAD"), argsOnly = true, ordinal = 2)
    private float av$swing(float swingProgress) {
        var s = AV.swing;
        if (s == null || !s.isEnabled() || swingProgress <= 0f) return swingProgress;
        try { return s.map(swingProgress); } catch (RuntimeException e) { return swingProgress; }
    }

    @Inject(method = "renderFirstPersonItem", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/util/math/MatrixStack;push()V", shift = At.Shift.AFTER, ordinal = 0))
    private void av$viewmodel(AbstractClientPlayerEntity player, float tickDelta, float pitch, Hand hand, float swingProgress, ItemStack item,
                              float equipProgress, MatrixStack matrices, VertexConsumerProvider vertexConsumers, int light, CallbackInfo ci) {
        AV.hook("held_item");
        var vm = AV.viewmodel;
        if (vm == null || !vm.isEnabled()) return;
        Arm arm = hand == Hand.MAIN_HAND ? player.getMainArm() : player.getMainArm().getOpposite();
        ModuleRegistry.guard(vm, "render", () -> vm.apply(matrices, arm, item));
    }
}
