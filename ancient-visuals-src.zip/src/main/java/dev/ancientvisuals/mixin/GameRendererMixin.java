package dev.ancientvisuals.mixin;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.client.fx.FxEvents;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Detects the local totem animation (the same moment vanilla shows the floating totem). */
@Mixin(GameRenderer.class)
public abstract class GameRendererMixin {
    @Inject(method = "showFloatingItem", at = @At("HEAD"))
    private void av$totem(ItemStack stack, CallbackInfo ci) {
        AV.hook("totem");
        if (stack != null && stack.isOf(Items.TOTEM_OF_UNDYING)) {
            try { FxEvents.onTotem(); } catch (RuntimeException ignored) { }
        }
    }
}
