package dev.ancientvisuals.mixin;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.ancientvisuals.client.fx.WorldFx;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** World presets: gentle fog colour tint and distance multiplier. Skipped underwater/lava/blindness. Not a shader. */
@Mixin(BackgroundRenderer.class)
public abstract class BackgroundRendererMixin {
    @Shadow private static float red;
    @Shadow private static float green;
    @Shadow private static float blue;

    @Inject(method = "render", at = @At("TAIL"))
    private static void av$fogColor(CallbackInfo ci) {
        Camera cam = MinecraftClient.getInstance().gameRenderer.getCamera();
        float[] t;
        try { t = WorldFx.tint(cam, red, green, blue); } catch (RuntimeException e) { return; }
        if (t == null || t.length < 3) return;
        red = t[0]; green = t[1]; blue = t[2];
        RenderSystem.clearColor(red, green, blue, 0.0f);
    }

    @Inject(method = "applyFog", at = @At("TAIL"))
    private static void av$fog(Camera camera, BackgroundRenderer.FogType fogType, float viewDistance, boolean thickFog, float tickDelta, CallbackInfo ci) {
        try { WorldFx.afterFog(camera, fogType); } catch (RuntimeException ignored) { }
    }
}
