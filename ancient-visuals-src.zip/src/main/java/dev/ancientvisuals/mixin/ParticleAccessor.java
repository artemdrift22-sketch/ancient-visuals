package dev.ancientvisuals.mixin;

import net.minecraft.client.particle.Particle;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(Particle.class)
public interface ParticleAccessor {
    @Accessor("gravityStrength") void setAvGravity(float v);
    @Accessor("velocityMultiplier") void setAvVelocityMultiplier(float v);
    @Accessor("alpha") void setAvAlpha(float v);
    @Accessor("angle") float getAvAngle();
    @Accessor("angle") void setAvAngle(float v);
    @Accessor("prevAngle") void setAvPrevAngle(float v);
    @Accessor("collidesWithWorld") void setAvCollides(boolean v);
}
