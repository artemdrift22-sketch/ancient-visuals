package dev.ancientvisuals.core.io;

import dev.ancientvisuals.core.json.Json;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** Validates imported JSON (profiles, themes, effects, HUD layouts). Imports are data only - nothing is executed. */
public final class ImportValidator {
    public static final int MAX_IMPORT = 512 * 1024;
    private ImportValidator() {}

    public static final class Result {
        public final List<String> errors = new ArrayList<>();
        public final List<String> warnings = new ArrayList<>();
        public Map<String, Object> data;
        public boolean ok() { return errors.isEmpty() && data != null; }
        public String summary() { return ok() ? (warnings.isEmpty() ? "OK" : "OK, " + warnings.size() + " warning(s)") : String.join("; ", errors); }
    }

    /** Parses text and checks it is an Ancient Visuals export of the expected kind. */
    public static Result parse(String text, String expectedKind) {
        Result r = new Result();
        if (text == null || text.isBlank()) { r.errors.add("empty input"); return r; }
        if (text.length() > MAX_IMPORT) { r.errors.add("import too large (" + text.length() / 1024 + " KB > 512 KB)"); return r; }
        Map<String, Object> m;
        try { m = Json.parseObject(text.trim()); }
        catch (RuntimeException e) { r.errors.add("invalid JSON: " + e.getMessage()); return r; }
        String kind = Json.str(m, "kind", null);
        if (kind == null) r.errors.add("missing 'kind'");
        else if (!kind.equals(expectedKind)) r.errors.add("expected kind '" + expectedKind + "' but got '" + kind + "'");
        int fmt = Json.integer(m, "format", -1);
        if (fmt < 1) r.errors.add("missing 'format'");
        else if (fmt > 1) r.warnings.add("export format " + fmt + " is newer; unknown fields are ignored");
        String name = Json.str(m, "name", null);
        if (name != null && name.length() > 64) r.errors.add("name longer than 64 characters");
        if (Json.obj(m, "data") == null) r.errors.add("missing 'data' object");
        if (r.errors.isEmpty()) r.data = m;
        return r;
    }

    public static Map<String, Object> envelope(String kind, String name, Map<String, Object> data) {
        Map<String, Object> m = new java.util.LinkedHashMap<>();
        m.put("kind", kind);
        m.put("format", 1L);
        m.put("name", name);
        m.put("data", data);
        return m;
    }
}
