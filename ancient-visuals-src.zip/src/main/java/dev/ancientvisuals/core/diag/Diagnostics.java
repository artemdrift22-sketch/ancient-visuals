package dev.ancientvisuals.core.diag;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

/** In-memory diagnostic log used by the Compatibility Center. Never stores secrets. */
public final class Diagnostics {
    public enum Level { INFO, WARN, ERROR }
    public record Entry(String time, Level level, String source, String message) {
        @Override public String toString() { return time + " [" + level + "] " + source + ": " + message; }
    }

    private static final int LIMIT = 300;
    private static final ArrayDeque<Entry> LOG = new ArrayDeque<>();
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static volatile Consumer<Entry> sink;
    private static int errors, warnings;

    private Diagnostics() {}

    /** Optional external sink (e.g. SLF4J logger in the client). */
    public static void setSink(Consumer<Entry> s) { sink = s; }

    public static synchronized void log(Level level, String source, String message) {
        Entry e = new Entry(LocalTime.now().format(FMT), level, source, scrub(message));
        LOG.addLast(e);
        while (LOG.size() > LIMIT) LOG.removeFirst();
        if (level == Level.ERROR) errors++;
        if (level == Level.WARN) warnings++;
        Consumer<Entry> s = sink;
        if (s != null) try { s.accept(e); } catch (RuntimeException ignored) { }
    }
    public static void info(String src, String msg) { log(Level.INFO, src, msg); }
    public static void warn(String src, String msg) { log(Level.WARN, src, msg); }
    public static void error(String src, String msg, Throwable t) { log(Level.ERROR, src, msg + (t == null ? "" : " -> " + t.getClass().getSimpleName() + ": " + t.getMessage())); }

    public static synchronized List<Entry> entries() { return new ArrayList<>(LOG); }
    public static synchronized int errorCount() { return errors; }
    public static synchronized int warningCount() { return warnings; }
    public static synchronized void clear() { LOG.clear(); errors = 0; warnings = 0; }

    /** Removes user home paths so exported reports do not leak the account name. */
    static String scrub(String m) {
        if (m == null) return "";
        String home = System.getProperty("user.home");
        String out = m;
        if (home != null && home.length() > 3) out = out.replace(home, "~");
        return out.length() > 500 ? out.substring(0, 500) + "..." : out;
    }
}
