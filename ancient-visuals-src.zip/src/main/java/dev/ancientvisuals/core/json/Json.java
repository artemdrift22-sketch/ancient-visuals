package dev.ancientvisuals.core.json;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Minimal, strict JSON parser/writer. Objects become LinkedHashMap, arrays ArrayList, numbers Long or Double.
 * Depth and size limits protect against hostile imports. No code is ever executed from JSON.
 */
public final class Json {
    public static final int MAX_DEPTH = 64;
    public static final int MAX_LENGTH = 4 * 1024 * 1024;

    private final String s;
    private int i;

    private Json(String s) { this.s = s; }

    public static Object parse(String text) {
        if (text == null) throw new JsonException("null input");
        if (text.length() > MAX_LENGTH) throw new JsonException("input too large");
        Json p = new Json(text);
        p.ws();
        Object v = p.value(0);
        p.ws();
        if (p.i != p.s.length()) throw new JsonException("trailing data at " + p.i);
        return v;
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> parseObject(String text) {
        Object o = parse(text);
        if (!(o instanceof Map)) throw new JsonException("expected object");
        return (Map<String, Object>) o;
    }

    private void ws() { while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++; }
    private char peek() { if (i >= s.length()) throw new JsonException("unexpected end"); return s.charAt(i); }

    private Object value(int depth) {
        if (depth > MAX_DEPTH) throw new JsonException("too deep");
        char c = peek();
        switch (c) {
            case '{': return object(depth);
            case '[': return array(depth);
            case '"': return string();
            case 't': lit("true"); return Boolean.TRUE;
            case 'f': lit("false"); return Boolean.FALSE;
            case 'n': lit("null"); return null;
            default: if (c == '-' || (c >= '0' && c <= '9')) return number(); throw new JsonException("unexpected '" + c + "' at " + i);
        }
    }

    private void lit(String w) { if (!s.startsWith(w, i)) throw new JsonException("expected " + w + " at " + i); i += w.length(); }

    private Map<String, Object> object(int depth) {
        Map<String, Object> m = new LinkedHashMap<>();
        i++; ws();
        if (peek() == '}') { i++; return m; }
        while (true) {
            ws();
            if (peek() != '"') throw new JsonException("expected key at " + i);
            String k = string();
            ws();
            if (peek() != ':') throw new JsonException("expected ':' at " + i);
            i++; ws();
            m.put(k, value(depth + 1));
            ws();
            char c = peek(); i++;
            if (c == '}') return m;
            if (c != ',') throw new JsonException("expected ',' or '}' at " + (i - 1));
        }
    }

    private List<Object> array(int depth) {
        List<Object> l = new ArrayList<>();
        i++; ws();
        if (peek() == ']') { i++; return l; }
        while (true) {
            ws();
            l.add(value(depth + 1));
            ws();
            char c = peek(); i++;
            if (c == ']') return l;
            if (c != ',') throw new JsonException("expected ',' or ']' at " + (i - 1));
        }
    }

    private String string() {
        StringBuilder b = new StringBuilder();
        i++;
        while (true) {
            if (i >= s.length()) throw new JsonException("unterminated string");
            char c = s.charAt(i++);
            if (c == '"') return b.toString();
            if (c == '\\') {
                if (i >= s.length()) throw new JsonException("bad escape");
                char e = s.charAt(i++);
                switch (e) {
                    case '"': b.append('"'); break;
                    case '\\': b.append('\\'); break;
                    case '/': b.append('/'); break;
                    case 'b': b.append('\b'); break;
                    case 'f': b.append('\f'); break;
                    case 'n': b.append('\n'); break;
                    case 'r': b.append('\r'); break;
                    case 't': b.append('\t'); break;
                    case 'u':
                        if (i + 4 > s.length()) throw new JsonException("bad unicode escape");
                        try { b.append((char) Integer.parseInt(s.substring(i, i + 4), 16)); } catch (NumberFormatException ex) { throw new JsonException("bad unicode escape"); }
                        i += 4; break;
                    default: throw new JsonException("bad escape \\" + e);
                }
            } else if (c < 0x20) {
                throw new JsonException("control char in string");
            } else b.append(c);
        }
    }

    private Object number() {
        int st = i;
        if (peek() == '-') i++;
        while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
        boolean dbl = false;
        if (i < s.length() && s.charAt(i) == '.') { dbl = true; i++; while (i < s.length() && Character.isDigit(s.charAt(i))) i++; }
        if (i < s.length() && (s.charAt(i) == 'e' || s.charAt(i) == 'E')) {
            dbl = true; i++;
            if (i < s.length() && (s.charAt(i) == '+' || s.charAt(i) == '-')) i++;
            while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
        }
        String n = s.substring(st, i);
        if (n.equals("-") || n.isEmpty()) throw new JsonException("bad number at " + st);
        try {
            if (!dbl) { try { return Long.parseLong(n); } catch (NumberFormatException big) { return Double.parseDouble(n); } }
            return Double.parseDouble(n);
        } catch (NumberFormatException e) { throw new JsonException("bad number " + n); }
    }

    // ---------------------------------------------------------------- writer
    public static String write(Object o) { return write(o, true); }
    public static String write(Object o, boolean pretty) { StringBuilder b = new StringBuilder(); write(b, o, pretty, 0); return b.toString(); }

    private static void indent(StringBuilder b, boolean pretty, int lvl) { if (pretty) { b.append('\n'); for (int k = 0; k < lvl; k++) b.append("  "); } }

    private static void write(StringBuilder b, Object o, boolean pretty, int lvl) {
        if (o == null) b.append("null");
        else if (o instanceof String str) quote(b, str);
        else if (o instanceof Boolean) b.append(o);
        else if (o instanceof Double d) { if (d.isNaN() || d.isInfinite()) b.append("0"); else if (d == Math.rint(d) && Math.abs(d) < 1e15) b.append(d.longValue()); else b.append(d); }
        else if (o instanceof Float f) write(b, (double) f, pretty, lvl);
        else if (o instanceof Number) b.append(o);
        else if (o instanceof Enum<?> e) quote(b, e.name());
        else if (o instanceof Map<?, ?> m) {
            b.append('{');
            boolean first = true;
            for (Map.Entry<?, ?> e : m.entrySet()) {
                if (!first) b.append(',');
                first = false;
                indent(b, pretty, lvl + 1);
                quote(b, String.valueOf(e.getKey()));
                b.append(pretty ? ": " : ":");
                write(b, e.getValue(), pretty, lvl + 1);
            }
            if (!m.isEmpty()) indent(b, pretty, lvl);
            b.append('}');
        } else if (o instanceof Iterable<?> it) {
            b.append('[');
            boolean first = true, any = false;
            for (Object x : it) {
                if (!first) b.append(',');
                first = false; any = true;
                indent(b, pretty, lvl + 1);
                write(b, x, pretty, lvl + 1);
            }
            if (any) indent(b, pretty, lvl);
            b.append(']');
        } else if (o instanceof int[] arr) {
            List<Object> l = new ArrayList<>();
            for (int v : arr) l.add((long) v);
            write(b, l, pretty, lvl);
        } else quote(b, o.toString());
    }

    private static void quote(StringBuilder b, String s) {
        b.append('"');
        for (int k = 0; k < s.length(); k++) {
            char c = s.charAt(k);
            switch (c) {
                case '"': b.append("\\\""); break;
                case '\\': b.append("\\\\"); break;
                case '\n': b.append("\\n"); break;
                case '\r': b.append("\\r"); break;
                case '\t': b.append("\\t"); break;
                default: if (c < 0x20) b.append(String.format("\\u%04x", (int) c)); else b.append(c);
            }
        }
        b.append('"');
    }

    // ---------------------------------------------------------------- typed helpers
    public static String str(Map<String, Object> m, String k, String def) { Object o = m == null ? null : m.get(k); return o instanceof String s ? s : def; }
    public static double num(Map<String, Object> m, String k, double def) { Object o = m == null ? null : m.get(k); return o instanceof Number n ? n.doubleValue() : def; }
    public static int integer(Map<String, Object> m, String k, int def) { Object o = m == null ? null : m.get(k); return o instanceof Number n ? (int) Math.max(Integer.MIN_VALUE, Math.min(Integer.MAX_VALUE, n.longValue())) : def; }
    public static boolean bool(Map<String, Object> m, String k, boolean def) { Object o = m == null ? null : m.get(k); return o instanceof Boolean b ? b : def; }
    @SuppressWarnings("unchecked")
    public static Map<String, Object> obj(Map<String, Object> m, String k) { Object o = m == null ? null : m.get(k); return o instanceof Map ? (Map<String, Object>) o : null; }
    @SuppressWarnings("unchecked")
    public static List<Object> list(Map<String, Object> m, String k) { Object o = m == null ? null : m.get(k); return o instanceof List ? (List<Object>) o : null; }

    /** Deep copy of a JSON tree (maps/lists/primitives). */
    @SuppressWarnings("unchecked")
    public static <T> T deepCopy(T o) {
        if (o instanceof Map<?, ?> m) { Map<String, Object> c = new LinkedHashMap<>(); for (Map.Entry<?, ?> e : m.entrySet()) c.put(String.valueOf(e.getKey()), deepCopy(e.getValue())); return (T) c; }
        if (o instanceof List<?> l) { List<Object> c = new ArrayList<>(); for (Object x : l) c.add(deepCopy(x)); return (T) c; }
        return o;
    }

    public static final class JsonException extends RuntimeException {
        public JsonException(String m) { super(m); }
    }
}
