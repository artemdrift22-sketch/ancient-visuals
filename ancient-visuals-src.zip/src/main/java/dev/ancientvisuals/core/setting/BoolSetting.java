package dev.ancientvisuals.core.setting;

public final class BoolSetting extends Setting<Boolean> {
    public BoolSetting(String id, String name, boolean def) { super(id, name, def); }
    public boolean on() { return Boolean.TRUE.equals(value); }
    public void toggle() { set(!on()); }
    @Override protected Boolean sanitize(Boolean v) { return v; }
    @Override public Object toJson() { return value; }
    @Override public boolean fromJson(Object o) { return o instanceof Boolean b && set(b); }
    @Override public boolean parse(String t) {
        if (t == null) return false;
        String s = t.trim().toLowerCase();
        if (s.equals("true") || s.equals("on") || s.equals("1") || s.equals("yes")) return set(true);
        if (s.equals("false") || s.equals("off") || s.equals("0") || s.equals("no")) return set(false);
        return false;
    }
    @Override public String displayValue() { return on() ? "ON" : "OFF"; }
}
