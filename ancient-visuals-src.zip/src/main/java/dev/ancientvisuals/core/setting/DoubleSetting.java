package dev.ancientvisuals.core.setting;

import java.util.Locale;

public final class DoubleSetting extends Setting<Double> {
    private final double min, max, step;
    private String suffix = "";
    private int decimals = 2;
    public DoubleSetting(String id, String name, double def, double min, double max, double step) {
        super(id, name, def);
        if (min > max || def < min || def > max) throw new IllegalArgumentException("bad range for " + id);
        this.min = min; this.max = max; this.step = step <= 0 ? 0.01 : step;
        decimals = step >= 1 ? 0 : step >= 0.1 ? 1 : 2;
    }
    public DoubleSetting suffix(String s) { suffix = s; return this; }
    public double min() { return min; }
    public double max() { return max; }
    public double step() { return step; }
    public double d() { return value; }
    public float f() { return value.floatValue(); }
    public double fraction() { return max == min ? 0 : (value - min) / (max - min); }
    public void setFraction(double f) { set(min + Math.max(0, Math.min(1, f)) * (max - min)); }
    public void nudge(int dir) { set(value + dir * step); }
    @Override protected Double sanitize(Double v) {
        if (v == null || v.isNaN() || v.isInfinite()) return null;
        double c = Math.max(min, Math.min(max, v));
        double snapped = min + Math.round((c - min) / step) * step;
        snapped = Math.max(min, Math.min(max, snapped));
        return Math.round(snapped * 1e6) / 1e6;
    }
    @Override public Object toJson() { return value; }
    @Override public boolean fromJson(Object o) { return o instanceof Number n && set(n.doubleValue()); }
    @Override public boolean parse(String t) { try { return set(Double.parseDouble(t.trim())); } catch (RuntimeException e) { return false; } }
    @Override public String displayValue() { return String.format(Locale.ROOT, "%." + decimals + "f", value) + suffix; }
}
