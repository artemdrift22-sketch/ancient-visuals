package dev.ancientvisuals.core.setting;

import dev.ancientvisuals.core.util.Colors;

public final class ColorSetting extends Setting<Integer> {
    private final boolean alpha;
    public ColorSetting(String id, String name, int def) { this(id, name, def, true); }
    public ColorSetting(String id, String name, int def, boolean alpha) { super(id, name, def); this.alpha = alpha; }
    public boolean allowsAlpha() { return alpha; }
    public int argb() { return value; }
    @Override protected Integer sanitize(Integer v) { if (v == null) return null; return alpha ? v : (v | 0xFF000000); }
    @Override public Object toJson() { return Colors.toHex(value); }
    @Override public boolean fromJson(Object o) {
        if (o instanceof String s) return parse(s);
        if (o instanceof Number n) return set((int) n.longValue());
        return false;
    }
    @Override public boolean parse(String t) { try { return set(Colors.parseHex(t)); } catch (RuntimeException e) { return false; } }
    @Override public String displayValue() { return Colors.toHex(value); }
}
