package dev.ancientvisuals.core.setting;

/** A button row. Holds no persistent value. */
public final class ActionSetting extends Setting<Boolean> {
    private final Runnable action;
    private final boolean dangerous;
    public ActionSetting(String id, String name, Runnable action) { this(id, name, false, action); }
    public ActionSetting(String id, String name, boolean dangerous, Runnable action) { super(id, name, false); this.action = action; this.dangerous = dangerous; }
    public boolean dangerous() { return dangerous; }
    public void run() { action.run(); }
    @Override protected Boolean sanitize(Boolean v) { return false; }
    @Override public Object toJson() { return null; }
    @Override public boolean fromJson(Object o) { return true; }
    @Override public boolean parse(String t) { return false; }
    @Override public String displayValue() { return ""; }
}
