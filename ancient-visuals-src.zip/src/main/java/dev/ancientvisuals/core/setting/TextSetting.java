package dev.ancientvisuals.core.setting;

public final class TextSetting extends Setting<String> {
    private final int maxLength;
    public TextSetting(String id, String name, String def, int maxLength) { super(id, name, def); this.maxLength = maxLength; }
    public int maxLength() { return maxLength; }
    @Override protected String sanitize(String v) {
        if (v == null) return null;
        StringBuilder b = new StringBuilder();
        for (char c : v.toCharArray()) if (c >= 0x20 && c != 0x7F && c != '\u00A7') b.append(c); // strip control + formatting codes
        String s = b.toString();
        return s.length() > maxLength ? s.substring(0, maxLength) : s;
    }
    @Override public Object toJson() { return value; }
    @Override public boolean fromJson(Object o) { return o instanceof String s && set(s); }
    @Override public boolean parse(String t) { return set(t); }
}
