package dev.ancientvisuals.core.setting;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

/** Typed, validated setting. Invalid values are rejected instead of being stored. */
public abstract class Setting<T> {
    private final String id;
    private final String name;
    private String description = "";
    private final T defaultValue;
    protected T value;
    private BooleanSupplier visible = () -> true;
    private final List<Consumer<T>> listeners = new ArrayList<>();
    private String group = "";

    protected Setting(String id, String name, T def) {
        if (id == null || !id.matches("[a-z0-9_.]+")) throw new IllegalArgumentException("bad setting id: " + id);
        this.id = id; this.name = name; this.defaultValue = def; this.value = def;
    }

    public String id() { return id; }
    public String name() { return name; }
    public String description() { return description; }
    public String group() { return group; }
    public T get() { return value; }
    public T defaultValue() { return defaultValue; }
    public boolean isDefault() { return Objects.equals(value, defaultValue); }
    public boolean isVisible() { try { return visible.getAsBoolean(); } catch (RuntimeException e) { return true; } }

    @SuppressWarnings("unchecked")
    public <S extends Setting<T>> S desc(String d) { description = d == null ? "" : d; return (S) this; }
    @SuppressWarnings("unchecked")
    public <S extends Setting<T>> S visibleWhen(BooleanSupplier s) { visible = s; return (S) this; }
    @SuppressWarnings("unchecked")
    public <S extends Setting<T>> S inGroup(String g) { group = g == null ? "" : g; return (S) this; }
    public void onChange(Consumer<T> l) { listeners.add(l); }

    /** @return true when accepted (also when unchanged). */
    public boolean set(T v) {
        T n = sanitize(v);
        if (n == null) return false;
        if (!Objects.equals(n, value)) {
            value = n;
            for (Consumer<T> l : listeners) { try { l.accept(n); } catch (RuntimeException ignored) { } }
            SettingEvents.fire(this);
        }
        return true;
    }

    public void reset() { set(defaultValue); }

    /** Returns a valid version of v, or null when v must be rejected. */
    protected abstract T sanitize(T v);
    public abstract Object toJson();
    /** @return false when the JSON value was invalid; the current value is kept in that case. */
    public abstract boolean fromJson(Object o);
    /** Parses a human/DSL string (used by presets and the command palette). */
    public abstract boolean parse(String text);
    public String displayValue() { return String.valueOf(value); }
}
