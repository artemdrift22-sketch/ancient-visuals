package dev.ancientvisuals.core.setting;

/** GLFW key code; -1 = unbound. Key names are resolved in the client layer. */
public final class KeySetting extends Setting<Integer> {
    public static final int NONE = -1;
    public KeySetting(String id, String name, int def) { super(id, name, def); }
    public int key() { return value; }
    public boolean bound() { return value != NONE; }
    @Override protected Integer sanitize(Integer v) { return v == null ? null : (v < -1 || v > 400 ? null : v); }
    @Override public Object toJson() { return (long) value; }
    @Override public boolean fromJson(Object o) { return o instanceof Number n && set(n.intValue()); }
    @Override public boolean parse(String t) { try { return set(Integer.parseInt(t.trim())); } catch (RuntimeException e) { return false; } }
    @Override public String displayValue() { return bound() ? "#" + value : "-"; }
}
