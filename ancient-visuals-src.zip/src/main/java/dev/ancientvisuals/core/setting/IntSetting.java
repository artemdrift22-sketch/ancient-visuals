package dev.ancientvisuals.core.setting;

public final class IntSetting extends Setting<Integer> {
    private final int min, max, step;
    private String suffix = "";
    public IntSetting(String id, String name, int def, int min, int max) { this(id, name, def, min, max, 1); }
    public IntSetting(String id, String name, int def, int min, int max, int step) {
        super(id, name, def);
        if (min > max || def < min || def > max) throw new IllegalArgumentException("bad range for " + id);
        this.min = min; this.max = max; this.step = Math.max(1, step);
    }
    public IntSetting suffix(String s) { suffix = s; return this; }
    public int min() { return min; }
    public int max() { return max; }
    public int step() { return step; }
    public int i() { return value; }
    public double fraction() { return max == min ? 0 : (value - min) / (double) (max - min); }
    public void setFraction(double f) { set((int) Math.round(min + Math.max(0, Math.min(1, f)) * (max - min))); }
    public void nudge(int dir) { set(value + dir * step); }
    @Override protected Integer sanitize(Integer v) {
        if (v == null) return null;
        int c = Math.max(min, Math.min(max, v));
        return min + Math.round((c - min) / (float) step) * step > max ? max : min + Math.round((c - min) / (float) step) * step;
    }
    @Override public Object toJson() { return (long) value; }
    @Override public boolean fromJson(Object o) { return o instanceof Number n && !Double.isNaN(n.doubleValue()) && set((int) Math.round(n.doubleValue())); }
    @Override public boolean parse(String t) { try { return set(Integer.parseInt(t.trim())); } catch (RuntimeException e) { return false; } }
    @Override public String displayValue() { return value + suffix; }
}
