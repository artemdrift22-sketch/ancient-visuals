package dev.ancientvisuals.core.setting;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;

/** String choice from a (possibly dynamic) list of ids, e.g. theme or effect ids. */
public final class ChoiceSetting extends Setting<String> {
    private final Supplier<List<String>> options;
    private Function<String, String> labeler = s -> s;
    public ChoiceSetting(String id, String name, String def, Supplier<List<String>> options) { super(id, name, def); this.options = options; }
    public ChoiceSetting labels(Function<String, String> l) { labeler = l; return this; }
    public List<String> options() { List<String> o = options.get(); return o == null ? new ArrayList<>() : o; }
    public void cycle(int dir) {
        List<String> o = options();
        if (o.isEmpty()) return;
        int i = o.indexOf(value);
        set(o.get(Math.floorMod((i < 0 ? 0 : i) + dir, o.size())));
    }
    @Override protected String sanitize(String v) { return v != null && options().contains(v) ? v : null; }
    @Override public Object toJson() { return value; }
    @Override public boolean fromJson(Object o) { return o instanceof String s && set(s); }
    @Override public boolean parse(String t) { return t != null && set(t.trim()); }
    @Override public String displayValue() { try { return labeler.apply(value); } catch (RuntimeException e) { return value; } }
}
