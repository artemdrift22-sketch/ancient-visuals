package dev.ancientvisuals.core.setting;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

/** Global change bus: used for autosave, change history and "recent settings". */
public final class SettingEvents {
    private static final List<Consumer<Setting<?>>> LISTENERS = new CopyOnWriteArrayList<>();
    private static int muted;
    private SettingEvents() {}
    public static void listen(Consumer<Setting<?>> l) { LISTENERS.add(l); }
    static void fire(Setting<?> s) { if (muted > 0) return; for (Consumer<Setting<?>> l : LISTENERS) { try { l.accept(s); } catch (RuntimeException ignored) { } } }
    /** Bulk operations (profile switch, import) mute per-setting events. */
    public static void mute(Runnable r) { muted++; try { r.run(); } finally { muted--; } }
    public static void clearListeners() { LISTENERS.clear(); }
}
