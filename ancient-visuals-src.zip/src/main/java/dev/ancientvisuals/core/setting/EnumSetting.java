package dev.ancientvisuals.core.setting;

public final class EnumSetting<E extends Enum<E>> extends Setting<E> {
    private final E[] values;
    public EnumSetting(String id, String name, E def) { super(id, name, def); values = def.getDeclaringClass().getEnumConstants(); }
    public E[] values() { return values; }
    public void cycle(int dir) { set(values[Math.floorMod(value.ordinal() + dir, values.length)]); }
    @Override protected E sanitize(E v) { return v; }
    @Override public Object toJson() { return value.name(); }
    @Override public boolean fromJson(Object o) { return o instanceof String s && parse(s); }
    @Override public boolean parse(String t) {
        if (t == null) return false;
        for (E e : values) if (e.name().equalsIgnoreCase(t.trim())) return set(e);
        return false;
    }
    @Override public String displayValue() { return pretty(value.name()); }
    public static String pretty(String n) {
        String[] parts = n.toLowerCase().split("_");
        StringBuilder b = new StringBuilder();
        for (String p : parts) { if (p.isEmpty()) continue; if (b.length() > 0) b.append(' '); b.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)); }
        return b.toString();
    }
}
