package dev.ancientvisuals.core.setting;

import dev.ancientvisuals.core.util.Colors;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/** 2..4 evenly spaced colour stops. Stored as an immutable list so equals() works. */
public final class GradientSetting extends Setting<List<Integer>> {
    public GradientSetting(String id, String name, Integer... stops) { super(id, name, List.copyOf(Arrays.asList(stops))); }
    public int stops() { return value.size(); }
    public int stop(int i) { return value.get(Math.max(0, Math.min(value.size() - 1, i))); }
    public void setStop(int i, int color) { List<Integer> l = new ArrayList<>(value); if (i >= 0 && i < l.size()) { l.set(i, color); set(l); } }
    public int sample(double t) {
        t = Math.max(0, Math.min(1, t));
        if (value.size() == 1) return value.get(0);
        double p = t * (value.size() - 1);
        int i = (int) Math.floor(p);
        if (i >= value.size() - 1) return value.get(value.size() - 1);
        return Colors.lerp(value.get(i), value.get(i + 1), p - i);
    }
    @Override protected List<Integer> sanitize(List<Integer> v) {
        if (v == null || v.size() < 2 || v.size() > 4) return null;
        for (Integer c : v) if (c == null) return null;
        return List.copyOf(v);
    }
    @Override public Object toJson() { List<Object> l = new ArrayList<>(); for (int c : value) l.add(Colors.toHex(c)); return l; }
    @Override public boolean fromJson(Object o) {
        if (!(o instanceof List<?> l)) return false;
        List<Integer> out = new ArrayList<>();
        try { for (Object x : l) out.add(Colors.parseHex(String.valueOf(x))); } catch (RuntimeException e) { return false; }
        return set(out);
    }
    @Override public boolean parse(String t) {
        if (t == null) return false;
        List<Integer> out = new ArrayList<>();
        try { for (String p : t.split("[,; ]+")) if (!p.isBlank()) out.add(Colors.parseHex(p)); } catch (RuntimeException e) { return false; }
        return set(out);
    }
    @Override public String displayValue() { return value.size() + " stops"; }
}
