package dev.ancientvisuals.core.util;

public enum Easing {
    LINEAR, IN_QUAD, OUT_QUAD, IN_OUT_QUAD, OUT_CUBIC, IN_OUT_CUBIC, IN_OUT_SINE, OUT_BACK, OUT_ELASTIC, OUT_BOUNCE, PULSE, FADE_LATE;

    public double apply(double t) {
        t = Math.max(0, Math.min(1, t));
        switch (this) {
            case IN_QUAD: return t * t;
            case OUT_QUAD: return 1 - (1 - t) * (1 - t);
            case IN_OUT_QUAD: return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
            case OUT_CUBIC: return 1 - Math.pow(1 - t, 3);
            case IN_OUT_CUBIC: return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
            case IN_OUT_SINE: return -(Math.cos(Math.PI * t) - 1) / 2;
            case OUT_BACK: { double c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); }
            case OUT_ELASTIC: return t == 0 || t == 1 ? t : Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * (2 * Math.PI) / 3) + 1;
            case OUT_BOUNCE: {
                double n1 = 7.5625, d1 = 2.75;
                if (t < 1 / d1) return n1 * t * t;
                if (t < 2 / d1) { t -= 1.5 / d1; return n1 * t * t + 0.75; }
                if (t < 2.5 / d1) { t -= 2.25 / d1; return n1 * t * t + 0.9375; }
                t -= 2.625 / d1; return n1 * t * t + 0.984375;
            }
            case PULSE: return Math.sin(Math.PI * t);
            case FADE_LATE: return t < 0.7 ? 0 : (t - 0.7) / 0.3;
            default: return t;
        }
    }
}
