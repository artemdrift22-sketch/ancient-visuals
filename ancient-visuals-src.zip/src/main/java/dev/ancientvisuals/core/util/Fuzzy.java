package dev.ancientvisuals.core.util;

import java.util.Locale;

/** Subsequence fuzzy matcher used by search and the command palette. */
public final class Fuzzy {
    private Fuzzy() {}

    /** @return score > 0 when every query char appears in order, otherwise -1. Higher is better. */
    public static int score(String query, String text) {
        if (query == null || query.isBlank()) return 1;
        if (text == null || text.isEmpty()) return -1;
        String q = query.toLowerCase(Locale.ROOT).trim(), t = text.toLowerCase(Locale.ROOT);
        int idx = t.indexOf(q);
        if (idx >= 0) return 1000 - idx * 2 + (idx == 0 || !Character.isLetterOrDigit(t.charAt(idx - 1)) ? 200 : 0) - (t.length() - q.length());
        int score = 0, ti = 0, streak = 0;
        for (int qi = 0; qi < q.length(); qi++) {
            char c = q.charAt(qi);
            if (c == ' ') continue;
            boolean found = false;
            while (ti < t.length()) {
                char tc = t.charAt(ti);
                boolean wordStart = ti == 0 || !Character.isLetterOrDigit(t.charAt(ti - 1));
                ti++;
                if (tc == c) { streak++; score += 10 + streak * 5 + (wordStart ? 15 : 0); found = true; break; }
                streak = 0;
            }
            if (!found) return -1;
        }
        return Math.max(1, score - (t.length() / 4));
    }
}
