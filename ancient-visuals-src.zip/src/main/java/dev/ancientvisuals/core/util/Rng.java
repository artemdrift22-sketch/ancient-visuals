package dev.ancientvisuals.core.util;

/** Small deterministic xorshift RNG, so effect previews are reproducible from a seed. */
public final class Rng {
    private long s;
    public Rng(long seed) { s = seed == 0 ? 0x9E3779B97F4A7C15L : seed; }
    public long nextLong() { s ^= s << 13; s ^= s >>> 7; s ^= s << 17; return s; }
    public double nextDouble() { return (nextLong() >>> 11) * 0x1.0p-53; }
    public int nextInt(int bound) { return bound <= 0 ? 0 : (int) Math.floorMod(nextLong(), (long) bound); }
    public double range(double a, double b) { return a + (b - a) * nextDouble(); }
    public double signed() { return nextDouble() * 2 - 1; }
    public boolean chance(double p) { return nextDouble() < p; }
    public double gaussian() { double u = Math.max(1e-9, nextDouble()), v = nextDouble(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
}
