package dev.ancientvisuals.core.util;

import java.util.Arrays;

/** Fixed-size ring of doubles (frame times, samples). */
public final class RingBuffer {
    private final double[] data;
    private int head, size;
    public RingBuffer(int capacity) { data = new double[Math.max(1, capacity)]; }
    public void add(double v) { data[head] = v; head = (head + 1) % data.length; if (size < data.length) size++; }
    public int size() { return size; }
    public int capacity() { return data.length; }
    /** i = 0 is the oldest sample. */
    public double get(int i) { return data[Math.floorMod(head - size + i, data.length)]; }
    public double last() { return size == 0 ? 0 : get(size - 1); }
    public double average() { if (size == 0) return 0; double s = 0; for (int i = 0; i < size; i++) s += get(i); return s / size; }
    public double max() { double m = 0; for (int i = 0; i < size; i++) m = Math.max(m, get(i)); return m; }
    public double min() { if (size == 0) return 0; double m = Double.MAX_VALUE; for (int i = 0; i < size; i++) m = Math.min(m, get(i)); return m; }
    /** p in 0..1, e.g. 0.99 for the 99th percentile. */
    public double percentile(double p) {
        if (size == 0) return 0;
        double[] c = new double[size];
        for (int i = 0; i < size; i++) c[i] = get(i);
        Arrays.sort(c);
        return c[(int) Math.min(size - 1, Math.max(0, Math.round(p * (size - 1))))];
    }
    public void clear() { head = 0; size = 0; }
}
