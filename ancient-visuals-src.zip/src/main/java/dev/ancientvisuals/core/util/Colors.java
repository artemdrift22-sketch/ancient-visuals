package dev.ancientvisuals.core.util;

/** ARGB colour helpers. Pure Java, no Minecraft dependencies. */
public final class Colors {
    private Colors() {}

    public static int clamp8(int v) { return v < 0 ? 0 : Math.min(255, v); }
    public static int argb(int a, int r, int g, int b) { return (clamp8(a) << 24) | (clamp8(r) << 16) | (clamp8(g) << 8) | clamp8(b); }
    public static int rgb(int rgb) { return 0xFF000000 | (rgb & 0xFFFFFF); }
    public static int a(int c) { return c >>> 24; }
    public static int r(int c) { return (c >> 16) & 0xFF; }
    public static int g(int c) { return (c >> 8) & 0xFF; }
    public static int b(int c) { return c & 0xFF; }
    public static int withAlpha(int c, int alpha) { return (clamp8(alpha) << 24) | (c & 0xFFFFFF); }
    public static int mulAlpha(int c, double f) { return withAlpha(c, (int) Math.round(a(c) * Math.max(0, Math.min(1, f)))); }

    public static int lerp(int c1, int c2, double t) {
        t = Math.max(0, Math.min(1, t));
        return argb((int) Math.round(a(c1) + (a(c2) - a(c1)) * t), (int) Math.round(r(c1) + (r(c2) - r(c1)) * t),
                (int) Math.round(g(c1) + (g(c2) - g(c1)) * t), (int) Math.round(b(c1) + (b(c2) - b(c1)) * t));
    }
    public static int lighten(int c, double f) { return withAlpha(lerp(c | 0xFF000000, 0xFFFFFFFF, f), a(c)); }
    public static int darken(int c, double f) { return withAlpha(lerp(c | 0xFF000000, 0xFF000000, f), a(c)); }

    /** @return {h 0..360, s 0..1, v 0..1} */
    public static float[] toHsv(int c) {
        float r = r(c) / 255f, g = g(c) / 255f, b = b(c) / 255f;
        float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b)), d = max - min;
        float h = 0;
        if (d > 1e-6f) {
            if (max == r) h = 60 * (((g - b) / d) % 6);
            else if (max == g) h = 60 * (((b - r) / d) + 2);
            else h = 60 * (((r - g) / d) + 4);
        }
        if (h < 0) h += 360;
        return new float[] { h, max <= 0 ? 0 : d / max, max };
    }

    public static int fromHsv(float h, float s, float v, int alpha) {
        h = ((h % 360) + 360) % 360; s = Math.max(0, Math.min(1, s)); v = Math.max(0, Math.min(1, v));
        float c = v * s, x = c * (1 - Math.abs((h / 60f) % 2 - 1)), m = v - c;
        float r, g, b;
        if (h < 60) { r = c; g = x; b = 0; } else if (h < 120) { r = x; g = c; b = 0; } else if (h < 180) { r = 0; g = c; b = x; }
        else if (h < 240) { r = 0; g = x; b = c; } else if (h < 300) { r = x; g = 0; b = c; } else { r = c; g = 0; b = x; }
        return argb(alpha, Math.round((r + m) * 255), Math.round((g + m) * 255), Math.round((b + m) * 255));
    }

    public static String toHex(int c) { return String.format("#%08X", c); }

    /** Parses #RGB, #RRGGBB or #AARRGGBB (with or without '#'). */
    public static int parseHex(String s) {
        if (s == null) throw new IllegalArgumentException("null colour");
        String h = s.trim();
        if (h.startsWith("#")) h = h.substring(1);
        if (h.startsWith("0x") || h.startsWith("0X")) h = h.substring(2);
        if (!h.matches("[0-9a-fA-F]+")) throw new IllegalArgumentException("not hex: " + s);
        if (h.length() == 3) h = "" + h.charAt(0) + h.charAt(0) + h.charAt(1) + h.charAt(1) + h.charAt(2) + h.charAt(2);
        if (h.length() == 6) return 0xFF000000 | Integer.parseInt(h, 16);
        if (h.length() == 8) return (int) Long.parseLong(h, 16);
        throw new IllegalArgumentException("bad length: " + s);
    }

    private static double channel(int v) { double c = v / 255.0; return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); }
    public static double luminance(int c) { return 0.2126 * channel(r(c)) + 0.7152 * channel(g(c)) + 0.0722 * channel(b(c)); }
    /** WCAG contrast ratio, 1..21. */
    public static double contrast(int c1, int c2) {
        double l1 = luminance(c1), l2 = luminance(c2);
        return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
    }
    public static int readableOn(int bg) { return contrast(bg, 0xFFFFFFFF) >= contrast(bg, 0xFF101418) ? 0xFFFFFFFF : 0xFF101418; }
    /** Moves fg away from bg until the contrast ratio reaches min (or white/black is hit). */
    public static int ensureContrast(int fg, int bg, double min) {
        if (contrast(fg, bg) >= min) return fg;
        boolean towardWhite = luminance(bg) < 0.4;
        int c = fg;
        for (int i = 1; i <= 10 && contrast(c, bg) < min; i++) c = towardWhite ? lighten(fg, i / 10.0) : darken(fg, i / 10.0);
        return c;
    }
    public static int grayscale(int c) { int l = (int) Math.round(r(c) * 0.299 + g(c) * 0.587 + b(c) * 0.114); return argb(a(c), l, l, l); }
}
