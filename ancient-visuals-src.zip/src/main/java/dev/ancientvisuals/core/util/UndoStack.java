package dev.ancientvisuals.core.util;

import java.util.ArrayDeque;
import java.util.Deque;

/** Generic snapshot based undo/redo history with a size limit. */
public final class UndoStack<T> {
    private final Deque<T> undo = new ArrayDeque<>(), redo = new ArrayDeque<>();
    private final int limit;
    public UndoStack(int limit) { this.limit = Math.max(1, limit); }
    /** Call before a change with the state that existed before it. */
    public void push(T before) {
        if (before == null) return;
        if (!undo.isEmpty() && undo.peek().equals(before)) return;
        undo.push(before);
        while (undo.size() > limit) undo.removeLast();
        redo.clear();
    }
    public boolean canUndo() { return !undo.isEmpty(); }
    public boolean canRedo() { return !redo.isEmpty(); }
    public T undo(T current) { if (undo.isEmpty()) return null; redo.push(current); return undo.pop(); }
    public T redo(T current) { if (redo.isEmpty()) return null; undo.push(current); return redo.pop(); }
    public int undoSize() { return undo.size(); }
    public void clear() { undo.clear(); redo.clear(); }
}
