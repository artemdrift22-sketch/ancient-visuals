package dev.ancientvisuals.core.util;

import java.util.ArrayDeque;

/** Counts real input events inside a sliding one second window (CPS display only, never generates input). */
public final class ClickCounter {
    private final ArrayDeque<Long> times = new ArrayDeque<>();
    public synchronized void record(long nowMs) { times.addLast(nowMs); trim(nowMs); }
    public synchronized int cps(long nowMs) { trim(nowMs); return times.size(); }
    private void trim(long now) { while (!times.isEmpty() && now - times.peekFirst() > 1000) times.removeFirst(); while (times.size() > 200) times.removeFirst(); }
}
