package dev.ancientvisuals.core.theme;

/** Structural layout of the ClickGUI - shells differ in structure, not only colour. */
public enum ShellLayout {
    SIDEBAR,        // floating window: category rail | module list | settings
    TOP_TABS,       // full-width tabs on top, two columns below
    TILE_GRID,      // modules as tiles, settings in a drawer on the right
    COMPACT_LIST,   // one dense column grouped by category, settings at the side
    BOOK_SPREAD,    // two "pages" with a spine (manuscript look)
    CENTER_COLUMN,  // narrow centred column, settings expand inline (accordion)
    ARC_DEPTH       // category cards on an arc with depth scaling (2.5D; no real 3D needed)
}
