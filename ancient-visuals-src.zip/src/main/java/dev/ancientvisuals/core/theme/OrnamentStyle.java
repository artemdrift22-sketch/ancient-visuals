package dev.ancientvisuals.core.theme;

public enum OrnamentStyle { NONE, MEANDER, LAUREL, WAVES, RAYS, MOSAIC, COLUMNS, RIVETS, SCROLL, DOTS }
