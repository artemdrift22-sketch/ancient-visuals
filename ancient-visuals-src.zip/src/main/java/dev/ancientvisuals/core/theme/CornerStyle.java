package dev.ancientvisuals.core.theme;

public enum CornerStyle { SQUARE, ROUNDED, CHAMFER, NOTCHED, STEPPED, PILL, TAB }
