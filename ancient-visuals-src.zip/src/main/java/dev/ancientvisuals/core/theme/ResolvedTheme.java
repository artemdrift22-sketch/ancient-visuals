package dev.ancientvisuals.core.theme;

/** Effective theme after user overrides and accessibility rules. */
public record ResolvedTheme(Shell shell, Palette palette, ShellLayout layout, CornerStyle corner, int radius, OrnamentStyle ornament,
                            double ornamentIntensity, int rowHeight, int padding, double panelAlpha, boolean animations, double animSpeed,
                            boolean highContrast, boolean textShadow) {
    public int alpha(int argb) {
        int a = (int) Math.round(((argb >>> 24) & 0xFF) * panelAlpha * shell.panelAlpha() / 255.0);
        return (Math.max(0, Math.min(255, a)) << 24) | (argb & 0xFFFFFF);
    }
}
