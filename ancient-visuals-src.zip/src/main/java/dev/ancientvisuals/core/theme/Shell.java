package dev.ancientvisuals.core.theme;

/** Structural GUI shell. Each shell has its own layout, geometry, controls and ornament placement. */
public record Shell(String id, String name, String description, ShellLayout layout, CornerStyle corner, int radius,
                    OrnamentStyle ornament, double ornamentIntensity, int rowHeight, int padding, int panelAlpha,
                    boolean shadow, Toggle toggle, Slider slider, boolean upperHeaders, Anim anim, String palette) {
    public enum Toggle { SWITCH, CHECK, GEM, PILL, TEXT }
    public enum Slider { BAR, NOTCHED, BEADS, LINE, BLOCKS }
    public enum Anim { FADE, SLIDE, SCALE, UNFOLD, NONE }
}
