package dev.ancientvisuals.core.theme;

import dev.ancientvisuals.core.json.Json;
import dev.ancientvisuals.core.util.Colors;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Colour tokens. Components read tokens, never hard-coded colours. */
public record Palette(String id, String name, boolean dark,
                      int primary, int secondary, int accent,
                      int background, int surface, int surfaceAlt, int border,
                      int text, int textMuted, int hover, int active, int disabled,
                      int success, int warning, int error, int ornament) {

    public static final String[] TOKENS = { "primary", "secondary", "accent", "background", "surface", "surfaceAlt", "border", "text", "textMuted", "hover", "active", "disabled", "success", "warning", "error", "ornament" };

    /** Derives a full palette from five base colours. */
    public static Palette of(String id, String name, boolean dark, int primary, int secondary, int accent, int background, int text) {
        int surface = dark ? Colors.lighten(background, 0.06) : Colors.darken(background, 0.03);
        int surfaceAlt = dark ? Colors.lighten(background, 0.12) : Colors.darken(background, 0.08);
        int border = Colors.lerp(primary, background, dark ? 0.35 : 0.25);
        int muted = Colors.lerp(text, background, 0.42);
        int hover = Colors.lerp(surface, primary, 0.18);
        int active = Colors.lerp(surface, primary, 0.42);
        int disabled = Colors.lerp(text, background, 0.7);
        return new Palette(id, name, dark, primary, secondary, accent, background, surface, surfaceAlt, border, text, muted, hover, active, disabled,
                dark ? 0xFF5FD38D : 0xFF2E9E5B, dark ? 0xFFF2C14E : 0xFFC98A0B, dark ? 0xFFFF6B6B : 0xFFC73B3B, accent);
    }

    public int get(String token) {
        return switch (token) {
            case "primary" -> primary; case "secondary" -> secondary; case "accent" -> accent; case "background" -> background;
            case "surface" -> surface; case "surfaceAlt" -> surfaceAlt; case "border" -> border; case "text" -> text;
            case "textMuted" -> textMuted; case "hover" -> hover; case "active" -> active; case "disabled" -> disabled;
            case "success" -> success; case "warning" -> warning; case "error" -> error; case "ornament" -> ornament;
            default -> throw new IllegalArgumentException("unknown token " + token);
        };
    }

    public Palette with(String token, int c) {
        int[] v = new int[TOKENS.length];
        for (int i = 0; i < TOKENS.length; i++) v[i] = TOKENS[i].equals(token) ? c : get(TOKENS[i]);
        return new Palette(id, name, dark, v[0], v[1], v[2], v[3], v[4], v[5], v[6], v[7], v[8], v[9], v[10], v[11], v[12], v[13], v[14], v[15]);
    }
    public Palette renamed(String nid, String nname) { return new Palette(nid, nname, dark, primary, secondary, accent, background, surface, surfaceAlt, border, text, textMuted, hover, active, disabled, success, warning, error, ornament); }

    /** High contrast variant used by the accessibility option. */
    public Palette highContrast() {
        int bg = dark ? 0xFF000000 : 0xFFFFFFFF, fg = dark ? 0xFFFFFFFF : 0xFF000000;
        return new Palette(id + "_hc", name + " (HC)", dark, Colors.ensureContrast(primary, bg, 4.5), secondary, Colors.ensureContrast(accent, bg, 4.5), bg, bg,
                dark ? 0xFF1A1A1A : 0xFFEDEDED, fg, fg, Colors.ensureContrast(textMuted, bg, 7), Colors.lerp(bg, primary, 0.35), Colors.lerp(bg, primary, 0.6), 0xFF808080,
                success, warning, error, Colors.ensureContrast(ornament, bg, 3));
    }

    /** Contrast problems (WCAG AA 4.5:1 for text). */
    public List<String> validate() {
        List<String> w = new ArrayList<>();
        if (Colors.contrast(text, surface) < 4.5) w.add(String.format("text on surface contrast %.1f:1 < 4.5:1", Colors.contrast(text, surface)));
        if (Colors.contrast(text, background) < 4.5) w.add(String.format("text on background contrast %.1f:1 < 4.5:1", Colors.contrast(text, background)));
        if (Colors.contrast(textMuted, surface) < 3) w.add(String.format("muted text contrast %.1f:1 < 3:1", Colors.contrast(textMuted, surface)));
        if (Colors.contrast(primary, surface) < 1.5) w.add("primary hardly distinguishable from surface");
        return w;
    }

    public Map<String, Object> toJson() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", id); m.put("name", name); m.put("dark", dark);
        for (String t : TOKENS) m.put(t, Colors.toHex(get(t)));
        return m;
    }

    public static Palette fromJson(Map<String, Object> m, Palette fallback) {
        Palette p = fallback.renamed(Json.str(m, "id", fallback.id()), Json.str(m, "name", fallback.name()));
        for (String t : TOKENS) {
            String v = Json.str(m, t, null);
            if (v != null) try { p = p.with(t, Colors.parseHex(v)); } catch (IllegalArgumentException ignored) { }
        }
        return p;
    }
}
