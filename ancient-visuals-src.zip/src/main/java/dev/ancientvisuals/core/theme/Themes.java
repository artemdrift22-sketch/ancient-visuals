package dev.ancientvisuals.core.theme;

import java.util.ArrayList;
import java.util.List;

import static dev.ancientvisuals.core.theme.CornerStyle.*;
import static dev.ancientvisuals.core.theme.OrnamentStyle.*;
import static dev.ancientvisuals.core.theme.Shell.Anim;
import static dev.ancientvisuals.core.theme.Shell.Slider;
import static dev.ancientvisuals.core.theme.Shell.Toggle;
import static dev.ancientvisuals.core.theme.ShellLayout.*;

/** Built-in shells (18) and palettes/themes (20). */
public final class Themes {
    private Themes() {}

    public static final List<Shell> SHELLS = List.of(
        new Shell("olympus", "Olympus", "Flagship: azure rail, marble panels, meander header.", SIDEBAR, ROUNDED, 4, MEANDER, 0.8, 16, 6, 235, true, Toggle.SWITCH, Slider.BAR, true, Anim.SCALE, "olympus_azure"),
        new Shell("athena", "Athena", "Tactical: crisp tabs, chamfered plates, precise controls.", TOP_TABS, CHAMFER, 4, COLUMNS, 0.5, 14, 5, 240, false, Toggle.CHECK, Slider.NOTCHED, true, Anim.SLIDE, "athena_marble"),
        new Shell("poseidon", "Poseidon", "Fluid: wave bands, pill controls, deep blue tiles.", TILE_GRID, PILL, 6, WAVES, 0.9, 16, 6, 225, true, Toggle.PILL, Slider.LINE, false, Anim.UNFOLD, "poseidon_tides"),
        new Shell("apollo", "Apollo", "Radiant: sun-ray header, warm gold accents, centred column.", CENTER_COLUMN, ROUNDED, 5, RAYS, 0.85, 16, 7, 230, true, Toggle.GEM, Slider.BEADS, true, Anim.SCALE, "apollo_radiance"),
        new Shell("marble_classic", "Marble Classic", "Calm white marble, thin borders, classic list.", SIDEBAR, SQUARE, 0, COLUMNS, 0.35, 15, 6, 245, false, Toggle.SWITCH, Slider.BAR, false, Anim.FADE, "classical_white"),
        new Shell("divine_artifact", "Divine Artifact", "Relic cards on an arc with depth and gold rivets.", ARC_DEPTH, NOTCHED, 3, RIVETS, 0.9, 16, 6, 235, true, Toggle.GEM, Slider.BEADS, true, Anim.UNFOLD, "divine_gold"),
        new Shell("arena", "Arena", "Combat clarity: dense list, no decoration, high contrast.", COMPACT_LIST, SQUARE, 0, NONE, 0.0, 12, 4, 245, false, Toggle.TEXT, Slider.BLOCKS, true, Anim.NONE, "arena_clarity"),
        new Shell("minimal_blue", "Minimal Blue", "Quiet azure minimalism with a single accent line.", TOP_TABS, ROUNDED, 3, NONE, 0.0, 15, 5, 230, false, Toggle.SWITCH, Slider.LINE, false, Anim.FADE, "azure_minimal"),
        new Shell("ornamental", "Ornamental", "Rich meanders and laurels, but ornaments stay inside panels.", SIDEBAR, STEPPED, 4, LAUREL, 1.0, 17, 7, 235, true, Toggle.GEM, Slider.NOTCHED, true, Anim.UNFOLD, "hera_laurel"),
        new Shell("transparent_classic", "Transparent Classic", "See-through vanilla-like panels for playing while tuning.", COMPACT_LIST, SQUARE, 0, NONE, 0.0, 13, 4, 150, false, Toggle.CHECK, Slider.BAR, false, Anim.FADE, "transparent_vanilla"),
        new Shell("spatial", "Spatial 2.5D", "Category cards in perspective; 2D fallback is the same layout without depth.", ARC_DEPTH, ROUNDED, 6, DOTS, 0.5, 16, 6, 220, true, Toggle.PILL, Slider.LINE, false, Anim.SCALE, "zeus_storm"),
        new Shell("accessible", "Accessible High Contrast", "Large rows, strong focus rings, no ornaments, no motion.", COMPACT_LIST, SQUARE, 0, NONE, 0.0, 20, 8, 255, false, Toggle.TEXT, Slider.BLOCKS, false, Anim.NONE, "arena_clarity"),
        new Shell("aegean_mosaic", "Aegean Mosaic", "Tiled mosaic headers, sea-glass tiles.", TILE_GRID, NOTCHED, 2, MOSAIC, 0.8, 15, 6, 235, true, Toggle.CHECK, Slider.BLOCKS, false, Anim.UNFOLD, "aegean_mosaic"),
        new Shell("manuscript", "Ancient Manuscript", "Two parchment pages with a spine and scroll ornaments.", BOOK_SPREAD, TAB, 4, SCROLL, 0.8, 15, 8, 245, true, Toggle.CHECK, Slider.LINE, false, Anim.UNFOLD, "ancient_manuscript"),
        new Shell("bronze_automaton", "Bronze Automaton", "Riveted bronze plates, notched sliders, mechanical feel.", SIDEBAR, NOTCHED, 3, RIVETS, 1.0, 16, 6, 245, true, Toggle.GEM, Slider.NOTCHED, true, Anim.SLIDE, "bronze_automaton"),
        new Shell("classical_white", "Classical White", "Open, airy, centred layout with column fluting.", CENTER_COLUMN, SQUARE, 0, COLUMNS, 0.5, 16, 8, 245, false, Toggle.SWITCH, Slider.LINE, true, Anim.FADE, "classical_white"),
        new Shell("cobalt_compact", "Cobalt Compact", "Maximum density in deep cobalt for small screens.", COMPACT_LIST, CHAMFER, 2, DOTS, 0.3, 11, 3, 240, false, Toggle.CHECK, Slider.BLOCKS, true, Anim.NONE, "marble_cobalt"),
        new Shell("user_custom", "User Custom", "Your own combination; edit layout, corners and ornaments in Theme settings.", SIDEBAR, ROUNDED, 4, MEANDER, 0.6, 16, 6, 235, true, Toggle.SWITCH, Slider.BAR, true, Anim.SCALE, "user_custom")
    );

    public static final List<Palette> PALETTES = List.of(
        Palette.of("olympus_azure", "Olympus Azure", false, 0xFF2F6FD6, 0xFF1D3F8F, 0xFFD4A537, 0xFFF4F1EA, 0xFF16233A),
        Palette.of("athena_marble", "Athena Marble", false, 0xFF3E5C8A, 0xFF7A8BA6, 0xFFB8903A, 0xFFEDEBE6, 0xFF1C2230),
        Palette.of("poseidon_tides", "Poseidon Tides", true, 0xFF2BA3C9, 0xFF1A5C8C, 0xFF7FE0D2, 0xFF0C1C2E, 0xFFE6F4FA),
        Palette.of("apollo_radiance", "Apollo Radiance", false, 0xFFE0A21B, 0xFF2F6FD6, 0xFFF5D06F, 0xFFFBF6E9, 0xFF2A1E08),
        Palette.of("hera_laurel", "Hera Laurel", false, 0xFF4E7D4A, 0xFF2F6FD6, 0xFFC9A440, 0xFFF3F1E6, 0xFF1D2A1B),
        Palette.of("zeus_storm", "Zeus Storm", true, 0xFF5B8CFF, 0xFF2B3A66, 0xFFF2E36B, 0xFF121726, 0xFFE8ECF8),
        Palette.of("hermes_motion", "Hermes Motion", false, 0xFF1E9BD7, 0xFF6C7A89, 0xFFE58E26, 0xFFF2F5F8, 0xFF14202B),
        Palette.of("artemis_wilds", "Artemis Wilds", true, 0xFF7DB8A0, 0xFF3B5E52, 0xFFCFD8E8, 0xFF13201C, 0xFFE9F2EE),
        Palette.of("hades_obsidian", "Hades Obsidian", true, 0xFF6A7BFF, 0xFF3A2A5C, 0xFFB8C0FF, 0xFF0D0D14, 0xFFE4E4F0),
        Palette.of("aegean_mosaic", "Aegean Mosaic", false, 0xFF1C7FB8, 0xFF31A39B, 0xFFE3B341, 0xFFEFF5F6, 0xFF10263A),
        Palette.of("classical_white", "Classical White", false, 0xFF4A6FA5, 0xFF9AA5B5, 0xFFB89B58, 0xFFFAFAF7, 0xFF1E2430),
        Palette.of("azure_minimal", "Azure Minimal", false, 0xFF2D7FF9, 0xFF8FB3EA, 0xFF2D7FF9, 0xFFF7F9FC, 0xFF17202E),
        Palette.of("divine_gold", "Divine Gold Accent", true, 0xFFD9B04C, 0xFF2F6FD6, 0xFFF3DC8C, 0xFF151A26, 0xFFF6F0DC),
        Palette.of("marble_cobalt", "Marble & Cobalt", true, 0xFF2F55D4, 0xFF9DB0E8, 0xFFE9E6DD, 0xFF0F1A3A, 0xFFF1F3FA),
        Palette.of("arena_clarity", "Arena Clarity", true, 0xFF3D8BFF, 0xFF8899AA, 0xFFFFC233, 0xFF0B0E12, 0xFFFFFFFF),
        Palette.of("transparent_vanilla", "Transparent Vanilla+", true, 0xFFA0C4FF, 0xFF8B8B8B, 0xFFFFE08A, 0xFF101010, 0xFFF0F0F0),
        Palette.of("ancient_manuscript", "Ancient Manuscript", false, 0xFF7A4E21, 0xFF2F5D8C, 0xFFA8322D, 0xFFF1E4C6, 0xFF2B1C0C),
        Palette.of("bronze_automaton", "Bronze Automaton", true, 0xFFC0803A, 0xFF5E7C8A, 0xFFE8C07A, 0xFF1B1611, 0xFFF3E6D3),
        Palette.of("temple_sunset", "Temple Sunset", false, 0xFFD9643A, 0xFF3D5FA8, 0xFFF0B65A, 0xFFFBEFE4, 0xFF2A140C),
        Palette.of("user_custom", "User Custom Theme", false, 0xFF2F6FD6, 0xFF1D3F8F, 0xFFD4A537, 0xFFF4F1EA, 0xFF16233A)
    );

    public static Shell shell(String id) { for (Shell s : SHELLS) if (s.id().equals(id)) return s; return SHELLS.get(0); }
    public static Palette palette(String id) { for (Palette p : PALETTES) if (p.id().equals(id)) return p; return PALETTES.get(0); }
    public static List<String> shellIds() { List<String> l = new ArrayList<>(); for (Shell s : SHELLS) l.add(s.id()); return l; }
    public static List<String> paletteIds() { List<String> l = new ArrayList<>(); for (Palette p : PALETTES) l.add(p.id()); return l; }
}
