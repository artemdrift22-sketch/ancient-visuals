package dev.ancientvisuals.core.hud;

import dev.ancientvisuals.core.json.Json;

import java.util.LinkedHashMap;
import java.util.Map;

/** Placement of one HUD element. Offsets are relative to the anchor point and scale with nothing (GUI pixels). */
public final class HudBox {
    public final String id;
    public Anchor anchor;
    public double offsetX, offsetY;
    public double scale = 1.0;
    public double opacity = 1.0;
    public String group = "";
    /** Measured each frame (unscaled). */
    public int width = 40, height = 10;

    public HudBox(String id, Anchor anchor, double ox, double oy) { this.id = id; this.anchor = anchor; this.offsetX = ox; this.offsetY = oy; }

    public double scaledW() { return width * scale; }
    public double scaledH() { return height * scale; }
    public double x(double sw) { return anchor.fx * sw + offsetX - anchor.fx * scaledW(); }
    public double y(double sh) { return anchor.fy * sh + offsetY - anchor.fy * scaledH(); }

    /** Moves the box so its top-left is at (x,y), re-anchoring to the nearest screen region. */
    public void setTopLeft(double x, double y, double sw, double sh) {
        anchor = Anchor.nearest(x + scaledW() / 2, y + scaledH() / 2, sw, sh);
        offsetX = x - anchor.fx * sw + anchor.fx * scaledW();
        offsetY = y - anchor.fy * sh + anchor.fy * scaledH();
    }

    /** Keeps the box fully on screen (inside safe margin). */
    public void clamp(double sw, double sh, double margin) {
        double x = x(sw), y = y(sh);
        double nx = Math.max(margin, Math.min(sw - margin - scaledW(), x));
        double ny = Math.max(margin, Math.min(sh - margin - scaledH(), y));
        if (nx != x || ny != y) { offsetX += nx - x; offsetY += ny - y; }
    }

    public Map<String, Object> toJson() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("anchor", anchor.name()); m.put("x", offsetX); m.put("y", offsetY); m.put("scale", scale); m.put("opacity", opacity);
        if (!group.isEmpty()) m.put("group", group);
        return m;
    }

    public void fromJson(Map<String, Object> m) {
        try { anchor = Anchor.valueOf(Json.str(m, "anchor", anchor.name())); } catch (IllegalArgumentException ignored) { }
        offsetX = clampNum(Json.num(m, "x", offsetX), -4000, 4000);
        offsetY = clampNum(Json.num(m, "y", offsetY), -4000, 4000);
        scale = clampNum(Json.num(m, "scale", scale), 0.25, 4);
        opacity = clampNum(Json.num(m, "opacity", opacity), 0.05, 1);
        group = Json.str(m, "group", "");
    }
    private static double clampNum(double v, double lo, double hi) { return Double.isNaN(v) ? lo : Math.max(lo, Math.min(hi, v)); }

    public HudBox copy() { HudBox b = new HudBox(id, anchor, offsetX, offsetY); b.scale = scale; b.opacity = opacity; b.group = group; b.width = width; b.height = height; return b; }
}
