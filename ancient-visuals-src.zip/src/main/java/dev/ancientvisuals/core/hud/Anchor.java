package dev.ancientvisuals.core.hud;

public enum Anchor {
    TOP_LEFT(0, 0), TOP_CENTER(0.5, 0), TOP_RIGHT(1, 0),
    CENTER_LEFT(0, 0.5), CENTER(0.5, 0.5), CENTER_RIGHT(1, 0.5),
    BOTTOM_LEFT(0, 1), BOTTOM_CENTER(0.5, 1), BOTTOM_RIGHT(1, 1);
    public final double fx, fy;
    Anchor(double fx, double fy) { this.fx = fx; this.fy = fy; }
    /** Picks the anchor of the screen third that contains the point, so elements keep their place when the window is resized. */
    public static Anchor nearest(double cx, double cy, double sw, double sh) {
        int col = cx < sw / 3 ? 0 : cx > sw * 2 / 3 ? 2 : 1;
        int row = cy < sh / 3 ? 0 : cy > sh * 2 / 3 ? 2 : 1;
        return values()[row * 3 + col];
    }
}
