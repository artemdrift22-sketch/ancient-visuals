package dev.ancientvisuals.core.hud;

import dev.ancientvisuals.core.json.Json;
import dev.ancientvisuals.core.profile.SectionCodec;
import dev.ancientvisuals.core.render.Rect;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** All HUD boxes + editor helpers (snap, guides, overlap). Saved inside profiles. */
public final class HudLayout implements SectionCodec {
    private final Map<String, HudBox> boxes = new LinkedHashMap<>();
    private final Map<String, HudBox> defaults = new LinkedHashMap<>();

    public record Guide(boolean vertical, int pos) {}
    public record SnapResult(double x, double y, List<Guide> guides) {}

    public HudBox register(String id, Anchor a, double ox, double oy) {
        HudBox d = new HudBox(id, a, ox, oy);
        defaults.put(id, d);
        HudBox b = d.copy();
        boxes.put(id, b);
        return b;
    }
    public HudBox box(String id) { return boxes.get(id); }
    public List<HudBox> all() { return new ArrayList<>(boxes.values()); }

    public void resetBox(String id) { HudBox d = defaults.get(id), b = boxes.get(id); if (d == null || b == null) return; b.anchor = d.anchor; b.offsetX = d.offsetX; b.offsetY = d.offsetY; b.scale = d.scale; b.opacity = d.opacity; b.group = ""; }

    /** Snaps a proposed top-left to the grid and to edges/centres of other boxes and the screen. */
    public SnapResult snap(HudBox moving, double x, double y, double sw, double sh, int grid, double threshold, List<HudBox> others) {
        List<Guide> guides = new ArrayList<>();
        double w = moving.scaledW(), h = moving.scaledH();
        double bx = x, by = y;
        double bestDx = threshold + 1, bestDy = threshold + 1;
        List<double[]> vx = new ArrayList<>(), vy = new ArrayList<>();
        vx.add(new double[] { 0 }); vx.add(new double[] { sw / 2 }); vx.add(new double[] { sw });
        vy.add(new double[] { 0 }); vy.add(new double[] { sh / 2 }); vy.add(new double[] { sh });
        for (HudBox o : others) {
            if (o == moving) continue;
            double ox = o.x(sw), oy = o.y(sh);
            vx.add(new double[] { ox }); vx.add(new double[] { ox + o.scaledW() }); vx.add(new double[] { ox + o.scaledW() / 2 });
            vy.add(new double[] { oy }); vy.add(new double[] { oy + o.scaledH() }); vy.add(new double[] { oy + o.scaledH() / 2 });
        }
        double[] edgesX = { 0, w / 2, w }, edgesY = { 0, h / 2, h };
        double gx = Double.NaN, gy = Double.NaN;
        for (double[] t : vx) for (double e : edgesX) { double d = Math.abs(x + e - t[0]); if (d < bestDx && d <= threshold) { bestDx = d; bx = t[0] - e; gx = t[0]; } }
        for (double[] t : vy) for (double e : edgesY) { double d = Math.abs(y + e - t[0]); if (d < bestDy && d <= threshold) { bestDy = d; by = t[0] - e; gy = t[0]; } }
        if (Double.isNaN(gx) && grid > 1) bx = Math.round(x / grid) * (double) grid; else if (!Double.isNaN(gx)) guides.add(new Guide(true, (int) Math.round(gx)));
        if (Double.isNaN(gy) && grid > 1) by = Math.round(y / grid) * (double) grid; else if (!Double.isNaN(gy)) guides.add(new Guide(false, (int) Math.round(gy)));
        return new SnapResult(bx, by, guides);
    }

    public static Rect rect(HudBox b, double sw, double sh) { return new Rect((int) Math.round(b.x(sw)), (int) Math.round(b.y(sh)), (int) Math.ceil(b.scaledW()), (int) Math.ceil(b.scaledH())); }

    /** Pairs of visible boxes that overlap (editor hint). */
    public List<String[]> overlaps(List<HudBox> visible, double sw, double sh) {
        List<String[]> out = new ArrayList<>();
        for (int i = 0; i < visible.size(); i++) for (int j = i + 1; j < visible.size(); j++)
            if (rect(visible.get(i), sw, sh).intersects(rect(visible.get(j), sw, sh))) out.add(new String[] { visible.get(i).id, visible.get(j).id });
        return out;
    }

    /** Aligns boxes to the left edge / horizontal centre / top of the first one. */
    public void align(List<HudBox> sel, String mode, double sw, double sh) {
        if (sel.size() < 2) return;
        HudBox ref = sel.get(0);
        for (HudBox b : sel.subList(1, sel.size())) {
            double x = b.x(sw), y = b.y(sh);
            switch (mode) {
                case "left" -> x = ref.x(sw);
                case "right" -> x = ref.x(sw) + ref.scaledW() - b.scaledW();
                case "center" -> x = ref.x(sw) + ref.scaledW() / 2 - b.scaledW() / 2;
                case "top" -> y = ref.y(sh);
                case "bottom" -> y = ref.y(sh) + ref.scaledH() - b.scaledH();
                default -> { }
            }
            b.setTopLeft(x, y, sw, sh);
        }
    }

    /** Stacks boxes vertically under the first one with a gap. */
    public void distributeVertically(List<HudBox> sel, double gap, double sw, double sh) {
        if (sel.size() < 2) return;
        double y = sel.get(0).y(sh) + sel.get(0).scaledH() + gap;
        double x = sel.get(0).x(sw);
        for (HudBox b : sel.subList(1, sel.size())) { b.setTopLeft(x, y, sw, sh); y += b.scaledH() + gap; }
    }

    @Override public Object save() { Map<String, Object> m = new LinkedHashMap<>(); for (HudBox b : boxes.values()) m.put(b.id, b.toJson()); return m; }
    @Override public void load(Object data) {
        reset();
        if (!(data instanceof Map<?, ?> m)) return;
        for (Map.Entry<?, ?> e : m.entrySet()) {
            HudBox b = boxes.get(String.valueOf(e.getKey()));
            if (b != null && e.getValue() instanceof Map) { @SuppressWarnings("unchecked") Map<String, Object> bm = (Map<String, Object>) e.getValue(); b.fromJson(bm); }
        }
    }
    @Override public void reset() { for (String id : boxes.keySet()) resetBox(id); }

    public String serialize() { return Json.write(save(), false); }
    public void deserialize(String s) { try { load(Json.parse(s)); } catch (RuntimeException ignored) { } }
}
