package dev.ancientvisuals.core.companion;

/** Smooth follow math: keeps the companion near the shoulder, never inside the camera. */
public final class FollowController {
    public double x, y, z, yaw, prevX, prevY, prevZ, prevYaw;
    public float phase;
    private boolean placed;
    public double side = 0.9, back = 0.9, up = 1.1, smoothing = 0.18, teleportDistance = 12;

    public void reset() { placed = false; }

    public void tick(double px, double py, double pz, double playerYawDeg, float hover, boolean flies, float bob) {
        prevX = x; prevY = y; prevZ = z; prevYaw = yaw;
        double yaw = Math.toRadians(playerYawDeg);
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);
        double rx = -fz, rz = fx;
        double tx = px - fx * back + rx * side, tz = pz - fz * back + rz * side;
        phase += 0.12f;
        double ty = py + (flies ? up + hover * 0.4 : 0) + Math.sin(phase) * 0.06 * bob;
        if (!placed || dist(tx, ty, tz) > teleportDistance) { x = tx; y = ty; z = tz; prevX = x; prevY = y; prevZ = z; placed = true; }
        else { x += (tx - x) * smoothing; y += (ty - y) * smoothing; z += (tz - z) * smoothing; }
        double moveYaw = Math.toDegrees(Math.atan2(-(x - prevX), z - prevZ));
        double target = Math.hypot(x - prevX, z - prevZ) > 0.02 ? moveYaw : playerYawDeg;
        this.yaw = this.yaw + wrap(target - this.yaw) * 0.2;
    }
    public double dist(double a, double b, double c) { double dx = a - x, dy = b - y, dz = c - z; return Math.sqrt(dx * dx + dy * dy + dz * dz); }
    public static double wrap(double d) { d %= 360; if (d >= 180) d -= 360; if (d < -180) d += 360; return d; }
    public double lerpX(float t) { return prevX + (x - prevX) * t; }
    public double lerpY(float t) { return prevY + (y - prevY) * t; }
    public double lerpZ(float t) { return prevZ + (z - prevZ) * t; }
    public double lerpYaw(float t) { return prevYaw + wrap(yaw - prevYaw) * t; }
}
