package dev.ancientvisuals.core.companion;

/** Axis aligned box in 1/16 block units, origin = model centre at feet level. */
public record Voxel(float x, float y, float z, float w, float h, float d, int color, Part part) {
    public enum Part { BODY, HEAD, WING_L, WING_R, TAIL, LEG, EYE, DETAIL, GLOW }
}
