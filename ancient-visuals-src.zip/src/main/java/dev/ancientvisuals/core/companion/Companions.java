package dev.ancientvisuals.core.companion;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** The 20 procedural companions. Coordinates: x right, y up, z forward (head at +z), 1 unit = 1/16 block. */
public final class Companions {
    private static final Map<String, CompanionModel> BY_ID = new LinkedHashMap<>();
    private static void add(CompanionModel m) { BY_ID.put(m.id, m); }
    private static CompanionModel.Builder b(String id, String name) { return new CompanionModel.Builder(id, name); }
    static final int EYE = 0xFF101418, GLOWE = 0xFFFFE08A, GOLD = 0xFFD4A537, MARBLE = 0xFFF4F1EA, AZURE = 0xFF2F6FD6, BRONZE = 0xFFB0763A;

    static {
        add(b("azure_dragon", "Azure Dragon").body(-2, 3, -3, 4, 3, 6, AZURE).head(-1.5f, 4, 3, 3, 2.5f, 3, 0xFF3F82E8).eyes(5.5f, 6, 0.8f, GLOWE)
            .detail(-1.5f, 6.5f, 3.5f, 0.6f, 1.5f, 0.6f, GOLD).detail(0.9f, 6.5f, 3.5f, 0.6f, 1.5f, 0.6f, GOLD).wings(5, -2, 5, 4, 0xFF1D3F8F)
            .tail(-1, 3.5f, -7, 2, 1.5f, 4, AZURE).tail(-0.5f, 3.8f, -9, 1, 1, 2, 0xFF5B8CFF).flying(0.9f).anim(0.7f, 0.5f).build());
        add(b("golden_griffin", "Golden Griffin").body(-2, 3, -3, 4, 3.5f, 6, 0xFFC9963A).head(-1.5f, 5, 2.5f, 3, 3, 3, MARBLE).detail(-0.5f, 5.5f, 5.5f, 1, 1, 1.5f, GOLD)
            .eyes(6.5f, 5.5f, 0.8f, EYE).wings(5.5f, -2, 5.5f, 4, GOLD).legs(1, 3, 1.3f, 2, 0xFF8A6A2A).tail(-0.5f, 4, -5, 1, 1, 3, 0xFFC9963A).flying(0.8f).build());
        add(b("olympus_owl", "Olympus Owl").body(-2, 1, -2, 4, 5, 4, 0xFF8A7A66).head(-2, 6, -1.8f, 4, 3, 3.6f, 0xFF9C8C76).eyes(7.2f, 1.9f, 1, GLOWE)
            .detail(-2, 9, -1, 1, 1, 1, 0xFF6A5A46).detail(1, 9, -1, 1, 1, 1, 0xFF6A5A46).wings(2.5f, -1.5f, 1.5f, 3, 0xFF6E604E).flying(0.5f).anim(0.4f, 0).build());
        add(b("celestial_pegasus", "Celestial Pegasus").body(-2, 4, -4, 4, 3.5f, 8, MARBLE).head(-1.2f, 7, 3.5f, 2.4f, 2.5f, 3.5f, MARBLE).eyes(8, 6.6f, 0.8f, 0xFF2F6FD6)
            .detail(-0.4f, 9.5f, 2, 0.8f, 1.5f, 3, 0xFFBFD9FF).legs(1, 4, 1.3f, 3, 0xFFE6E2D8).wings(6.5f, -2, 6, 4, 0xFFDDE8FF).tail(-0.5f, 5, -7, 1, 2.5f, 3, 0xFFBFD9FF)
            .glow(-0.5f, 11, 3.5f, 1, 1, 1, GLOWE).flying(0.7f).scale(1.1f).build());
        add(b("marble_phoenix", "Marble Phoenix").body(-1.5f, 3, -2.5f, 3, 3, 5, MARBLE).head(-1, 5.5f, 2, 2, 2, 2.5f, 0xFFFFF4E0).eyes(6.5f, 4.4f, 0.6f, 0xFFE0393E)
            .wings(4.5f, -2, 6, 4, 0xFFFF8A2B).tail(-1, 3.5f, -6, 2, 0.6f, 4, 0xFFE0A21B).glow(-0.5f, 4, -8, 1, 1, 2, 0xFFFFB347).flying(1.0f).anim(0.8f, 0.4f).build());
        add(b("bronze_automaton", "Bronze Automaton").body(-2.5f, 4, -1.5f, 5, 5, 3, BRONZE).head(-1.5f, 9, -1.5f, 3, 3, 3, 0xFFC88C4A).eyes(10.5f, 1.6f, 0.8f, 0xFF55E0FF)
            .box(dev.ancientvisuals.core.companion.Voxel.Part.LEG, -2, 0, -1, 1.5f, 4, 2, 0xFF8A5A2A).box(dev.ancientvisuals.core.companion.Voxel.Part.LEG, 0.5f, 0, -1, 1.5f, 4, 2, 0xFF8A5A2A)
            .detail(-3.5f, 5, -1, 1, 4, 2, 0xFF9A6A3A).detail(2.5f, 5, -1, 1, 4, 2, 0xFF9A6A3A).glow(-0.5f, 6, 1.6f, 1, 1, 0.3f, 0xFF55E0FF).anim(0.2f, 0).hover(0.2f).build());
        add(b("moon_fox", "Moon Fox").body(-1.5f, 2, -3, 3, 2.5f, 6, 0xFFDDE3F0).head(-1.5f, 3.5f, 2.5f, 3, 2.5f, 3, 0xFFEFF3FA).eyes(4.8f, 5.5f, 0.8f, 0xFF4A6AD0)
            .detail(-1.5f, 6, 3, 1, 1.5f, 1, 0xFFB0BCD8).detail(0.5f, 6, 3, 1, 1.5f, 1, 0xFFB0BCD8).legs(0.8f, 2, 1, 2, 0xFFB0BCD8)
            .tail(-1, 2.8f, -7, 2, 2, 4, 0xFFFFFFFF).glow(-0.5f, 3.2f, -8.5f, 1, 1, 1, 0xFFBFD9FF).anim(0.3f, 0.8f).hover(0.3f).build());
        add(b("laurel_sprite", "Laurel Sprite").body(-1, 2, -1, 2, 3, 2, 0xFF7FB069).head(-1.2f, 5, -1.2f, 2.4f, 2.4f, 2.4f, 0xFFA8D08D).eyes(6.2f, 1.25f, 0.5f, EYE)
            .detail(-2.2f, 7, -0.5f, 4.4f, 0.6f, 1, GOLD).wings(4, -0.5f, 2.5f, 1.5f, 0x90C8F0B0).glow(-0.4f, 8, -0.4f, 0.8f, 0.8f, 0.8f, GLOWE).flying(1.4f).scale(0.8f).build());
        add(b("mini_cerberus", "Mini Cerberus").body(-2.5f, 2, -3, 5, 3, 6, 0xFF3A2E2E).head(-4, 4, 2.5f, 2.5f, 2.5f, 2.5f, 0xFF4A3A3A).head(-1.25f, 4.5f, 3, 2.5f, 2.5f, 2.5f, 0xFF4A3A3A)
            .head(1.5f, 4, 2.5f, 2.5f, 2.5f, 2.5f, 0xFF4A3A3A).eyes(5.6f, 5.6f, 0.6f, 0xFFFF6A2B).legs(1, 2, 1.6f, 2, 0xFF2A2020).tail(-0.5f, 4, -5, 1, 1, 3, 0xFF2A2020).anim(0.2f, 1.0f).hover(0.2f).build());
        add(b("aegean_dolphin", "Aegean Dolphin").body(-1.5f, 3, -4, 3, 3, 8, 0xFF4A8FC2).head(-1, 3.5f, 4, 2, 2, 3, 0xFF5BA0D2).eyes(4.6f, 5, 1.1f, EYE)
            .detail(-0.5f, 6, -1, 1, 2, 2, 0xFF2F6F9F).tail(-2.5f, 3.8f, -6, 5, 0.6f, 2, 0xFF2F6F9F).detail(-1.2f, 3, -1, 2.4f, 0.5f, 4, 0xFFDDEEFF).flying(0).anim(1.0f, 0.6f).build());
        add(b("temple_cat", "Temple Cat").body(-1.5f, 2, -3, 3, 2.5f, 6, 0xFF2A2A2E).head(-1.5f, 3.5f, 2.5f, 3, 2.5f, 2.5f, 0xFF333338).eyes(5, 5, 0.8f, 0xFFD4A537)
            .detail(-1.5f, 6, 3, 1, 1, 1, 0xFF2A2A2E).detail(0.5f, 6, 3, 1, 1, 1, 0xFF2A2A2E).detail(-1.6f, 3.5f, 2.3f, 3.2f, 0.6f, 0.4f, GOLD)
            .legs(0.8f, 2, 1, 2, 0xFF222226).tail(-0.4f, 3.5f, -6.5f, 0.8f, 0.8f, 4, 0xFF2A2A2E).anim(0.2f, 0.9f).hover(0.2f).build());
        add(b("sun_hawk", "Sun Hawk").body(-1.5f, 3, -2.5f, 3, 2.5f, 5, 0xFFB07A3A).head(-1, 5, 2, 2, 2, 2.5f, 0xFFFFF0D0).detail(-0.4f, 5.4f, 4.5f, 0.8f, 0.8f, 1, GOLD)
            .eyes(6.2f, 4.4f, 0.6f, EYE).wings(4, -1.5f, 6.5f, 3.5f, 0xFF8A5A2A).tail(-1, 3.5f, -5, 2, 0.5f, 3, 0xFF8A5A2A).glow(-1.5f, 8, 0, 3, 0.4f, 3, 0x80FFE08A).flying(0.9f).build());
        add(b("marble_turtle", "Marble Turtle").body(-3, 1.5f, -3, 6, 2.5f, 6, MARBLE).detail(-2, 4, -2, 4, 1, 4, 0xFFD8D2C4).head(-1, 1.5f, 3, 2, 2, 2, 0xFF8FB08A)
            .eyes(3, 5, 0.6f, EYE).legs(1.2f, 1.5f, 2.5f, 2.5f, 0xFF8FB08A).detail(-2.6f, 3.2f, -2.6f, 5.2f, 0.3f, 5.2f, GOLD).anim(0.1f, 0).hover(0.1f).build());
        add(b("hermes_sparrow", "Hermes Sparrow").body(-1, 2.5f, -1.5f, 2, 2, 3, 0xFF8A6A4A).head(-1, 4.5f, 1, 2, 1.8f, 2, 0xFF9C7C5C).eyes(5.4f, 3, 0.5f, EYE)
            .wings(3.5f, -1, 3, 2, 0xFFD4A537).tail(-0.6f, 3, -3.5f, 1.2f, 0.4f, 2, 0xFF6A4A2A).detail(-1.5f, 6.2f, 0, 0.6f, 0.6f, 1.5f, 0xFFFFFFFF).detail(0.9f, 6.2f, 0, 0.6f, 0.6f, 1.5f, 0xFFFFFFFF)
            .flying(1.6f).scale(0.75f).build());
        add(b("athena_raven", "Athena Raven").body(-1.5f, 3, -2.5f, 3, 2.5f, 5, 0xFF1A1C24).head(-1, 5, 2, 2, 2, 2.5f, 0xFF22242E).detail(-0.4f, 5.4f, 4.5f, 0.8f, 0.6f, 1.2f, 0xFF3A3C46)
            .eyes(6.2f, 4.4f, 0.6f, 0xFF6FA8FF).wings(4, -1.5f, 5, 3.5f, 0xFF14161C).tail(-1, 3.5f, -5, 2, 0.5f, 3, 0xFF14161C).glow(-0.3f, 7.2f, 3, 0.6f, 0.6f, 0.6f, 0xFF6FA8FF).flying(0.8f).build());
        add(b("little_minotaur", "Little Minotaur").body(-2.5f, 4, -1.5f, 5, 4, 3, 0xFF6A4A32).head(-2, 8, -1.5f, 4, 3, 3.5f, 0xFF5A3A26).eyes(9.5f, 2, 0.9f, 0xFFE0393E)
            .detail(-3.5f, 10, 0, 1.5f, 0.8f, 0.8f, MARBLE).detail(2, 10, 0, 1.5f, 0.8f, 0.8f, MARBLE).detail(-0.5f, 8.5f, 2, 1, 0.6f, 0.4f, GOLD)
            .box(Voxel.Part.LEG, -2, 0, -1, 1.6f, 4, 2, 0xFF4A3222).box(Voxel.Part.LEG, 0.4f, 0, -1, 1.6f, 4, 2, 0xFF4A3222).anim(0.2f, 0).hover(0.2f).build());
        add(b("azure_serpent", "Azure Serpent").body(-1, 3, -1, 2, 2, 4, AZURE).body(-1, 3.5f, -4.5f, 2, 2, 3.5f, 0xFF3F82E8).body(-1, 4, -7.5f, 2, 1.8f, 3, AZURE)
            .head(-1.5f, 3, 3, 3, 2, 3, 0xFF1D3F8F).eyes(4.6f, 6, 0.8f, GLOWE).tail(-0.5f, 4.3f, -10, 1, 1, 2.5f, 0xFF5B8CFF).detail(-0.3f, 5, -2, 0.6f, 1, 0.6f, GOLD)
            .flying(0).anim(0.9f, 1.0f).build());
        add(b("olive_grove_spirit", "Olive Grove Spirit").body(-1.5f, 1, -1.5f, 3, 4, 3, 0xA07FA86A).head(-1.5f, 5, -1.5f, 3, 3, 3, 0xB0A8C88D).eyes(6.5f, 1.6f, 0.7f, 0xFFFFFFFF)
            .detail(-2.5f, 8, -0.5f, 1, 1, 1, 0xFF5A7A3A).detail(1.5f, 8, -0.5f, 1, 1, 1, 0xFF5A7A3A).detail(-0.5f, 8.5f, -0.5f, 1, 1, 1, 0xFF3A2A4A)
            .glow(-0.5f, 2, -0.5f, 1, 1, 1, GLOWE).flying(0).anim(0.9f, 0).scale(0.9f).build());
        add(b("tiny_centaur", "Tiny Centaur").body(-2, 3, -3.5f, 4, 3, 7, 0xFF8A6A4A).body(-1.5f, 6, 1.5f, 3, 4, 2, 0xFFE0C09A).head(-1.2f, 10, 1.2f, 2.4f, 2.4f, 2.4f, 0xFFE8CCA8)
            .eyes(11.2f, 3.7f, 0.6f, EYE).detail(-1.4f, 12.2f, 1, 2.8f, 0.6f, 2.8f, 0xFF4E7D4A).legs(1, 3, 1.3f, 2.5f, 0xFF6A4A2A).tail(-0.5f, 4, -6, 1, 2, 2.5f, 0xFF3A2A1A)
            .detail(1.5f, 7, 2, 0.5f, 5, 0.5f, GOLD).anim(0.2f, 0.6f).hover(0.2f).build());
        add(b("bronze_beetle", "Bronze Beetle").body(-2, 1, -2.5f, 4, 2, 5, BRONZE).detail(-2.1f, 2.8f, -2.4f, 2, 0.5f, 4.8f, 0xFFD49A5A).detail(0.1f, 2.8f, -2.4f, 2, 0.5f, 4.8f, 0xFFD49A5A)
            .head(-1.2f, 1, 2.5f, 2.4f, 1.6f, 1.6f, 0xFF7A4A22).eyes(2, 4.1f, 0.7f, 0xFF55E0FF).detail(-0.3f, 1.8f, 4, 0.6f, 0.6f, 2, GOLD)
            .legs(0.5f, 1, 2.2f, 1.5f, 0xFF5A3A1A).wings(3.2f, -2, 3, 3.5f, 0x8055E0FF).flying(1.8f).scale(0.8f).build());
    }

    private Companions() {}
    public static CompanionModel get(String id) { CompanionModel m = BY_ID.get(id); return m != null ? m : BY_ID.values().iterator().next(); }
    public static List<String> ids() { return new ArrayList<>(BY_ID.keySet()); }
    public static List<CompanionModel> all() { return new ArrayList<>(BY_ID.values()); }
}
