package dev.ancientvisuals.core.companion;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Procedural voxel model plus animation parameters. Rendered locally only. */
public final class CompanionModel {
    public final String id, name;
    public final List<Voxel> voxels;
    public final boolean flies;
    public final float bob, wingFlap, tailSwing, scale, hover;

    CompanionModel(String id, String name, List<Voxel> voxels, boolean flies, float bob, float wingFlap, float tailSwing, float scale, float hover) {
        this.id = id; this.name = name; this.voxels = Collections.unmodifiableList(new ArrayList<>(voxels));
        this.flies = flies; this.bob = bob; this.wingFlap = wingFlap; this.tailSwing = tailSwing; this.scale = scale; this.hover = hover;
    }

    /** Simple level of detail: drops DETAIL/GLOW voxels at low detail. */
    public List<Voxel> lod(int detail) {
        if (detail >= 2) return voxels;
        List<Voxel> l = new ArrayList<>();
        for (Voxel v : voxels) if (v.part() != Voxel.Part.DETAIL && (detail >= 1 || v.part() != Voxel.Part.GLOW)) l.add(v);
        return l;
    }

    public static final class Builder {
        private final String id, name;
        private final List<Voxel> v = new ArrayList<>();
        private boolean flies; private float bob = 0.6f, flap, tail, scale = 1, hover = 1.2f;
        public Builder(String id, String name) { this.id = id; this.name = name; }
        public Builder box(Voxel.Part p, float x, float y, float z, float w, float h, float d, int c) { v.add(new Voxel(x, y, z, w, h, d, c, p)); return this; }
        public Builder body(float x, float y, float z, float w, float h, float d, int c) { return box(Voxel.Part.BODY, x, y, z, w, h, d, c); }
        public Builder head(float x, float y, float z, float w, float h, float d, int c) { return box(Voxel.Part.HEAD, x, y, z, w, h, d, c); }
        public Builder eyes(float y, float z, float spread, int c) { box(Voxel.Part.EYE, -spread - 0.5f, y, z, 1, 1, 0.3f, c); return box(Voxel.Part.EYE, spread - 0.5f, y, z, 1, 1, 0.3f, c); }
        public Builder wings(float y, float z, float span, float len, int c) { box(Voxel.Part.WING_L, -span, y, z, span, 0.8f, len, c); return box(Voxel.Part.WING_R, 0, y, z, span, 0.8f, len, c); }
        public Builder legs(float w, float h, float dx, float dz, int c) {
            box(Voxel.Part.LEG, -dx - w / 2, 0, -dz - w / 2, w, h, w, c); box(Voxel.Part.LEG, dx - w / 2, 0, -dz - w / 2, w, h, w, c);
            box(Voxel.Part.LEG, -dx - w / 2, 0, dz - w / 2, w, h, w, c); return box(Voxel.Part.LEG, dx - w / 2, 0, dz - w / 2, w, h, w, c);
        }
        public Builder tail(float x, float y, float z, float w, float h, float d, int c) { return box(Voxel.Part.TAIL, x, y, z, w, h, d, c); }
        public Builder detail(float x, float y, float z, float w, float h, float d, int c) { return box(Voxel.Part.DETAIL, x, y, z, w, h, d, c); }
        public Builder glow(float x, float y, float z, float w, float h, float d, int c) { return box(Voxel.Part.GLOW, x, y, z, w, h, d, c); }
        public Builder flying(float flap) { flies = true; this.flap = flap; return this; }
        public Builder anim(float bob, float tail) { this.bob = bob; this.tail = tail; return this; }
        public Builder scale(float s) { scale = s; return this; }
        public Builder hover(float h) { hover = h; return this; }
        public CompanionModel build() { return new CompanionModel(id, name, v, flies, bob, flap, tail, scale, hover); }
    }
}
