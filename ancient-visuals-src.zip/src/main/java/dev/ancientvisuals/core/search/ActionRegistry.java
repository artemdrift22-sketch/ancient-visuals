package dev.ancientvisuals.core.search;

import dev.ancientvisuals.core.util.Fuzzy;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Command palette: quick actions found by fuzzy search. */
public final class ActionRegistry {
    public record Action(String id, String title, String section, String keywords, Runnable run) {}
    public record Hit(Action action, int score) {}
    private final Map<String, Action> actions = new LinkedHashMap<>();
    private final List<String> recent = new ArrayList<>();

    public void register(Action a) { register(a.id(), a.title(), a.section(), a.keywords(), a.run()); }
    public void register(String id, String title, String section, String keywords, Runnable run) { actions.put(id, new Action(id, title, section, keywords == null ? "" : keywords, run)); }
    public void unregisterPrefix(String prefix) { actions.keySet().removeIf(k -> k.startsWith(prefix)); }
    public int size() { return actions.size(); }
    public List<String> recent() { return List.copyOf(recent); }

    public List<Hit> search(String q, int limit) {
        List<Hit> hits = new ArrayList<>();
        for (Action a : actions.values()) {
            int s = q == null || q.isBlank() ? (recent.contains(a.id()) ? 1000 - recent.indexOf(a.id()) : 0)
                    : Math.max(Fuzzy.score(q, a.title()), Math.max(Fuzzy.score(q, a.keywords()) - 20, Fuzzy.score(q, a.section()) - 40));
            if (q == null || q.isBlank() || s > 0) hits.add(new Hit(a, s));
        }
        hits.sort((x, y) -> y.score() - x.score());
        return hits.size() > limit ? new ArrayList<>(hits.subList(0, limit)) : hits;
    }

    public boolean run(String id) {
        Action a = actions.get(id);
        if (a == null) return false;
        recent.remove(id); recent.add(0, id); while (recent.size() > 12) recent.remove(recent.size() - 1);
        a.run().run();
        return true;
    }
}
