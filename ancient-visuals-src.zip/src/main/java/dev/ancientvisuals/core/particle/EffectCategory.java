package dev.ancientvisuals.core.particle;

public enum EffectCategory { DIVINE, COMBAT, MOVEMENT, MAGIC, ELEMENTAL, SUPPORT }
