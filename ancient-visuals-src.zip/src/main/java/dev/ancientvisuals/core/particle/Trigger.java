package dev.ancientvisuals.core.particle;

/** Events detected on the client. Continuous triggers (MOVE, SPRINT, AMBIENT, IDLE) emit with a rate. */
public enum Trigger {
    JUMP(false), LAND(false), MOVE(true), SPRINT(true), HIT(false), DAMAGE_TAKEN(false), CRIT(false), TOTEM(false), HEAL(false),
    ITEM_USE(false), PORTAL(false), COMPANION_SPAWN(false), WATER(false), PICKUP(false), KILL(false), TEST(false), AMBIENT(true), IDLE(true);
    public final boolean continuous;
    Trigger(boolean c) { continuous = c; }
}
