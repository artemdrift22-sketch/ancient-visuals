package dev.ancientvisuals.core.particle;

import dev.ancientvisuals.core.perf.QualityLevel;
import dev.ancientvisuals.core.util.Colors;
import dev.ancientvisuals.core.util.Rng;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/** Turns effect definitions into scheduled particle requests, respecting quality, LOD and the budget. */
public final class EffectPlayer {
    private record Pending(long due, ParticleRequest req) {}
    private final List<Pending> queue = new ArrayList<>();
    private final Map<String, Double> accumulators = new HashMap<>();
    private final ParticleBudget budget = new ParticleBudget();
    private final Rng rng = new Rng(System.nanoTime());
    private long tick;
    public QualityLevel quality = QualityLevel.BALANCED;
    public double userMultiplier = 1.0;
    public int userMax = 900;

    public ParticleBudget budget() { return budget; }
    public int pending() { return queue.size(); }
    public int limit() { return (int) Math.min(userMax, quality.maxParticles); }

    public int plannedCount(EffectDef d, double intensity, double distance) {
        if (!d.enabled || quality.ordinal() < d.minQuality.ordinal()) return 0;
        double n = d.count * quality.particleMultiplier * userMultiplier * Math.max(0, intensity);
        if (distance > d.lodDistance) n *= 0.4;
        if (distance > d.lodDistance * 2) return 0;
        return (int) Math.max(n > 0.3 ? 1 : 0, Math.min(d.maxCount, Math.round(n)));
    }

    public int play(EffectDef d, double ox, double oy, double oz, double yaw, double intensity, double distance) {
        int n = plannedCount(d, intensity, distance);
        if (n <= 0) return 0;
        int extra = d.trail ? n : 0;
        int allowed = budget.reserve(n + extra, d.lifetime + 20, limit());
        if (allowed <= 0) return 0;
        if (d.trail) n = Math.max(1, allowed / 2); else n = allowed;
        List<Spawn> spawns = ShapeGen.generate(d, new Rng(d.seed ^ rng.nextLong()), yaw, n);
        for (Spawn s : spawns) {
            ParticleRequest r = request(d, s, ox, oy, oz);
            queue.add(new Pending(tick + s.delay(), r));
            if (d.trail) {
                ParticleRequest t = request(d, s, ox - s.vx() * 1.5, oy - s.vy() * 1.5, oz - s.vz() * 1.5);
                t.size *= 0.55f; t.alphaStart *= 0.6f; t.alphaEnd *= 0.4f;
                queue.add(new Pending(tick + s.delay() + 1, t));
            }
        }
        return spawns.size();
    }

    /** Continuous emitters (rate per second) accumulate fractional particles each tick. */
    public int emitContinuous(String key, EffectDef d, double ox, double oy, double oz, double yaw, double intensity) {
        double acc = accumulators.getOrDefault(key, 0.0) + d.rate / 20.0 * quality.particleMultiplier * userMultiplier * intensity;
        int whole = (int) acc;
        accumulators.put(key, acc - whole);
        if (whole <= 0) return 0;
        int allowed = budget.reserve(whole, d.lifetime + 5, limit());
        if (allowed <= 0) return 0;
        Rng r = new Rng(rng.nextLong());
        List<Spawn> spawns = ShapeGen.generate(d, r, yaw, Math.max(allowed, 1));
        for (int i = 0; i < allowed && !spawns.isEmpty(); i++) {
            Spawn s = spawns.get(r.nextInt(spawns.size()));
            queue.add(new Pending(tick, request(d, s, ox, oy, oz)));
        }
        return allowed;
    }

    ParticleRequest request(EffectDef d, Spawn s, double ox, double oy, double oz) {
        ParticleRequest r = new ParticleRequest();
        r.kind = s.secondary() && d.kind2 != null ? d.kind2 : d.kind;
        r.x = ox + s.x(); r.y = oy + s.y(); r.z = oz + s.z();
        double accel = 1 + d.acceleration;
        r.vx = s.vx() * accel; r.vy = s.vy() * accel; r.vz = s.vz() * accel;
        if (d.randomColor) { int c = Colors.fromHsv((float) (s.colorT() * 360), 0.72f, 1f, 255); r.colorStart = c; r.colorEnd = Colors.darken(c, 0.3); }
        else { r.colorStart = d.colorAt(s.colorT() * 0.5); r.colorEnd = d.colorAt(0.5 + s.colorT() * 0.5); }
        r.size = (float) (d.sizeAt(0) * s.sizeMul());
        r.alphaStart = (float) d.alphaAt(0); r.alphaEnd = (float) d.alphaAt(1); r.alphaCurve = d.alphaCurve;
        r.lifetime = Math.max(2, d.lifetime + (d.lifetimeVariance > 0 ? rng.nextInt(d.lifetimeVariance + 1) - d.lifetimeVariance / 2 : 0));
        r.gravity = (float) d.gravity; r.drag = (float) d.drag; r.angularVelocity = (float) d.angularVelocity; r.collides = d.collides;
        return r;
    }

    public int tick(ParticleSink sink) {
        tick++;
        budget.tick();
        int emitted = 0;
        for (Iterator<Pending> it = queue.iterator(); it.hasNext(); ) {
            Pending p = it.next();
            if (p.due() <= tick) {
                it.remove();
                boolean ok;
                try { ok = sink.spawn(p.req()); } catch (RuntimeException e) { ok = false; }
                if (ok) emitted++; else budget.release(1);
            }
        }
        return emitted;
    }

    public void clear() { queue.clear(); accumulators.clear(); budget.clear(); }
}
