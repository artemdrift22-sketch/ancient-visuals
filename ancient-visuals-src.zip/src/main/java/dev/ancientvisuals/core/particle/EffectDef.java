package dev.ancientvisuals.core.particle;

import dev.ancientvisuals.core.json.Json;
import dev.ancientvisuals.core.perf.QualityLevel;
import dev.ancientvisuals.core.util.Colors;
import dev.ancientvisuals.core.util.Easing;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Full parameter set of one particle effect. Mutable so the Particle Studio can edit a copy. */
public final class EffectDef {
    public String id, name, description = "";
    public EffectCategory category;
    public EmitterShape shape;
    public ParticleKind kind, kind2;
    public double secondaryRatio = 0.0;
    public int count = 24;
    public boolean burst = true;
    public double rate = 10;
    public int lifetime = 20, lifetimeVariance = 6;
    public double sizeStart = 1.0, sizeEnd = 0.6;
    public int colorStart = 0xFF2F6FD6, colorEnd = 0xFFD4A537;
    public boolean randomColor = false;
    public double alphaStart = 1.0, alphaEnd = 0.8;
    public Easing alphaCurve = Easing.LINEAR;
    public double speed = 0.1, spread = 0.8, height = 1.0;
    public double acceleration = 0.0, gravity = 0.0, drag = 0.96;
    public double rotation = 0, angularVelocity = 0;
    public double directionJitter = 0.1;
    public boolean trail = false;
    public int turns = 2;
    public Trigger trigger = Trigger.TEST;
    public int maxCount = 160;
    public QualityLevel minQuality = QualityLevel.LOW;
    public double lodDistance = 48;
    public long seed = 0;
    public double previewScale = 1.0, scale = 1.0, opacity = 1.0;
    public boolean enabled = true;
    public boolean collides = false;

    public EffectDef(String id, String name, EffectCategory cat, EmitterShape shape, ParticleKind kind) {
        this.id = id; this.name = name; this.category = cat; this.shape = shape; this.kind = kind;
    }

    public int colorAt(double t) { return Colors.lerp(colorStart, colorEnd, Math.max(0, Math.min(1, t))); }
    public double alphaAt(double t) { return (alphaStart + (alphaEnd - alphaStart) * alphaCurve.apply(Math.max(0, Math.min(1, t)))) * opacity; }
    public double sizeAt(double t) { return (sizeStart + (sizeEnd - sizeStart) * t) * scale; }

    public EffectDef copy() { EffectDef d = new EffectDef(id, name, category, shape, kind); d.fromJson(toJson()); return d; }

    /** Clamps everything into safe ranges and reports what was changed. */
    public List<String> validate() {
        List<String> w = new ArrayList<>();
        count = clampI(count, 1, 400, "count", w);
        maxCount = clampI(maxCount, 1, 800, "maxCount", w);
        lifetime = clampI(lifetime, 2, 200, "lifetime", w);
        lifetimeVariance = clampI(lifetimeVariance, 0, 100, "lifetimeVariance", w);
        turns = clampI(turns, 1, 8, "turns", w);
        rate = clampD(rate, 0, 120, "rate", w);
        sizeStart = clampD(sizeStart, 0.05, 4, "sizeStart", w); sizeEnd = clampD(sizeEnd, 0.05, 4, "sizeEnd", w);
        alphaStart = clampD(alphaStart, 0.1, 1, "alphaStart", w); alphaEnd = clampD(alphaEnd, 0.1, 1, "alphaEnd", w);
        speed = clampD(speed, 0, 2, "speed", w); spread = clampD(spread, 0, 6, "spread", w); height = clampD(height, 0, 6, "height", w);
        gravity = clampD(gravity, -0.2, 0.2, "gravity", w); drag = clampD(drag, 0.5, 1.0, "drag", w); acceleration = clampD(acceleration, -0.1, 0.1, "acceleration", w);
        angularVelocity = clampD(angularVelocity, -30, 30, "angularVelocity", w); rotation = clampD(rotation, -360, 360, "rotation", w);
        directionJitter = clampD(directionJitter, 0, 1, "directionJitter", w); secondaryRatio = clampD(secondaryRatio, 0, 1, "secondaryRatio", w);
        scale = clampD(scale, 0.1, 3, "scale", w); opacity = clampD(opacity, 0.1, 1, "opacity", w); previewScale = clampD(previewScale, 0.2, 4, "previewScale", w);
        lodDistance = clampD(lodDistance, 4, 128, "lodDistance", w);
        if (name == null || name.isBlank()) { name = id; w.add("name was empty"); }
        if (name.length() > 48) { name = name.substring(0, 48); w.add("name truncated"); }
        return w;
    }
    private static int clampI(int v, int lo, int hi, String n, List<String> w) { if (v < lo || v > hi) { w.add(n + " clamped"); return Math.max(lo, Math.min(hi, v)); } return v; }
    private static double clampD(double v, double lo, double hi, String n, List<String> w) { if (Double.isNaN(v) || v < lo || v > hi) { w.add(n + " clamped"); return Double.isNaN(v) ? lo : Math.max(lo, Math.min(hi, v)); } return v; }

    public Map<String, Object> toJson() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", id); m.put("name", name); m.put("description", description); m.put("category", category.name()); m.put("shape", shape.name());
        m.put("kind", kind.name()); if (kind2 != null) m.put("kind2", kind2.name()); m.put("secondaryRatio", secondaryRatio);
        m.put("count", count); m.put("burst", burst); m.put("rate", rate); m.put("lifetime", lifetime); m.put("lifetimeVariance", lifetimeVariance);
        m.put("sizeStart", sizeStart); m.put("sizeEnd", sizeEnd); m.put("colorStart", Colors.toHex(colorStart)); m.put("colorEnd", Colors.toHex(colorEnd));
        m.put("randomColor", randomColor); m.put("alphaStart", alphaStart); m.put("alphaEnd", alphaEnd); m.put("alphaCurve", alphaCurve.name());
        m.put("speed", speed); m.put("spread", spread); m.put("height", height); m.put("acceleration", acceleration); m.put("gravity", gravity); m.put("drag", drag);
        m.put("rotation", rotation); m.put("angularVelocity", angularVelocity); m.put("directionJitter", directionJitter); m.put("trail", trail); m.put("turns", turns);
        m.put("trigger", trigger.name()); m.put("maxCount", maxCount); m.put("minQuality", minQuality.name()); m.put("lodDistance", lodDistance); m.put("seed", seed);
        m.put("previewScale", previewScale); m.put("scale", scale); m.put("opacity", opacity); m.put("enabled", enabled); m.put("collides", collides);
        return m;
    }

    public void fromJson(Map<String, Object> m) {
        name = Json.str(m, "name", name); description = Json.str(m, "description", description);
        category = en(EffectCategory.class, Json.str(m, "category", null), category);
        shape = en(EmitterShape.class, Json.str(m, "shape", null), shape);
        kind = en(ParticleKind.class, Json.str(m, "kind", null), kind);
        kind2 = m.containsKey("kind2") ? en(ParticleKind.class, Json.str(m, "kind2", null), null) : null;
        secondaryRatio = Json.num(m, "secondaryRatio", secondaryRatio);
        count = Json.integer(m, "count", count); burst = Json.bool(m, "burst", burst); rate = Json.num(m, "rate", rate);
        lifetime = Json.integer(m, "lifetime", lifetime); lifetimeVariance = Json.integer(m, "lifetimeVariance", lifetimeVariance);
        sizeStart = Json.num(m, "sizeStart", sizeStart); sizeEnd = Json.num(m, "sizeEnd", sizeEnd);
        colorStart = col(Json.str(m, "colorStart", null), colorStart); colorEnd = col(Json.str(m, "colorEnd", null), colorEnd);
        randomColor = Json.bool(m, "randomColor", randomColor); alphaStart = Json.num(m, "alphaStart", alphaStart); alphaEnd = Json.num(m, "alphaEnd", alphaEnd);
        alphaCurve = en(Easing.class, Json.str(m, "alphaCurve", null), alphaCurve);
        speed = Json.num(m, "speed", speed); spread = Json.num(m, "spread", spread); height = Json.num(m, "height", height);
        acceleration = Json.num(m, "acceleration", acceleration); gravity = Json.num(m, "gravity", gravity); drag = Json.num(m, "drag", drag);
        rotation = Json.num(m, "rotation", rotation); angularVelocity = Json.num(m, "angularVelocity", angularVelocity); directionJitter = Json.num(m, "directionJitter", directionJitter);
        trail = Json.bool(m, "trail", trail); turns = Json.integer(m, "turns", turns);
        trigger = en(Trigger.class, Json.str(m, "trigger", null), trigger); maxCount = Json.integer(m, "maxCount", maxCount);
        minQuality = en(QualityLevel.class, Json.str(m, "minQuality", null), minQuality); lodDistance = Json.num(m, "lodDistance", lodDistance);
        seed = (long) Json.num(m, "seed", seed); previewScale = Json.num(m, "previewScale", previewScale); scale = Json.num(m, "scale", scale);
        opacity = Json.num(m, "opacity", opacity); enabled = Json.bool(m, "enabled", enabled); collides = Json.bool(m, "collides", collides);
        validate();
    }
    private static <E extends Enum<E>> E en(Class<E> c, String s, E def) { if (s == null) return def; try { return Enum.valueOf(c, s); } catch (IllegalArgumentException e) { return def; } }
    private static int col(String s, int def) { if (s == null) return def; try { return Colors.parseHex(s); } catch (IllegalArgumentException e) { return def; } }

    /** Fingerprint of the silhouette-defining parameters (used to verify that no two effects are clones). */
    public String silhouette() { return shape + "/" + kind + "/" + kind2 + "/" + Math.round(spread * 4) + "/" + Math.round(height * 4) + "/" + (count / 8) + "/" + Math.round(gravity * 100) + "/" + turns; }
}
