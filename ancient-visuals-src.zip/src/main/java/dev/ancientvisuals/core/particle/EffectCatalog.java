package dev.ancientvisuals.core.particle;

import dev.ancientvisuals.core.perf.QualityLevel;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static dev.ancientvisuals.core.particle.EffectCategory.*;
import static dev.ancientvisuals.core.particle.EmitterShape.*;
import static dev.ancientvisuals.core.particle.ParticleKind.*;

/** The 80 built-in effects. Every effect has its own silhouette (shape + sprite + geometry), not only a colour. */
public final class EffectCatalog {
    private static final int AZURE = 0xFF2F6FD6, COBALT = 0xFF1D3F8F, GOLD = 0xFFD4A537, MARBLE = 0xFFF4F1EA, WHITE = 0xFFFFFFFF,
            SKY = 0xFFBFD9FF, STORM = 0xFF5B8CFF, RED = 0xFFE0393E, CRIMSON = 0xFF8C1C24, LEAF = 0xFF4E7D4A, SUN = 0xFFFFE08A, AMBER = 0xFFE0A21B,
            EMBER = 0xFFFF8A2B, SEA = 0xFF2BA3C9, VIOLET = 0xFF8A5BFF, SAND = 0xFFD9C08C, GREY = 0xFFB9B9B4, SOUL_TEAL = 0xFF56E0E6, PINK = 0xFFF2A7C6;

    private static final Map<String, EffectDef> BY_ID = new LinkedHashMap<>();
    public static final List<EffectDef> ALL;

    private static final class B {
        final EffectDef d;
        B(EffectDef d) { this.d = d; }
        B n(int c) { d.count = c; return this; }
        B life(int t) { d.lifetime = t; d.lifetimeVariance = Math.max(1, t / 4); return this; }
        B size(double a, double b) { d.sizeStart = a; d.sizeEnd = b; return this; }
        B col(int a, int b) { d.colorStart = a; d.colorEnd = b; return this; }
        B sp(double s) { d.speed = s; return this; }
        B r(double r) { d.spread = r; return this; }
        B h(double h) { d.height = h; return this; }
        B g(double g) { d.gravity = g; return this; }
        B drag(double v) { d.drag = v; return this; }
        B k2(ParticleKind k, double ratio) { d.kind2 = k; d.secondaryRatio = ratio; return this; }
        B on(Trigger t) { d.trigger = t; return this; }
        B cont(double rate) { d.burst = false; d.rate = rate; return this; }
        B turns(int t) { d.turns = t; return this; }
        B rnd() { d.randomColor = true; return this; }
        B trail() { d.trail = true; return this; }
        B spin(double av) { d.angularVelocity = av; return this; }
        B q(QualityLevel q) { d.minQuality = q; return this; }
        B fade(double a0, double a1) { d.alphaStart = a0; d.alphaEnd = a1; return this; }
        B desc(String s) { d.description = s; return this; }
    }

    private static B e(String id, String name, EffectCategory c, EmitterShape s, ParticleKind k) {
        EffectDef d = new EffectDef(id, name, c, s, k);
        d.seed = id.hashCode();
        if (BY_ID.containsKey(id)) throw new IllegalStateException("duplicate effect " + id);
        BY_ID.put(id, d);
        return new B(d);
    }

    static {
        // ---- Divine (01-16)
        e("zeus_arc", "Zeus Arc", DIVINE, BOLT, SPARK).k2(END_ROD, 0.3).n(36).h(2.4).r(1.2).col(SKY, STORM).life(8).on(Trigger.CRIT).desc("Jagged lightning bolt from above with a short branch.");
        e("olympus_burst", "Olympus Burst", DIVINE, BURST, END_ROD).k2(GLOW, 0.3).n(40).sp(0.25).h(1.2).col(AZURE, GOLD).life(18).on(Trigger.KILL).desc("Spherical azure-gold burst.");
        e("aegis_burst", "Aegis Burst", DIVINE, SHOCKWAVE, DUST).k2(GLOW, 0.2).n(48).sp(0.35).r(1.0).col(GOLD, AZURE).life(12).on(Trigger.DAMAGE_TAKEN).desc("Shield-like double ring pushed outwards.");
        e("divine_halo", "Divine Halo", DIVINE, HALO, END_ROD).n(24).r(1.0).h(2.1).sp(0.05).col(GOLD, WHITE).life(14).cont(6).on(Trigger.IDLE).desc("Slowly rotating halo above the head.");
        e("rune_glyphs", "Rune Glyphs", DIVINE, GLYPH, ENCHANT).n(60).r(1.4).turns(1).col(AZURE, COBALT).life(30).on(Trigger.LAND).desc("An omega rune drawn on the ground.");
        e("celestial_dust", "Celestial Dust", DIVINE, DRIFT, WAX).n(40).r(1.5).h(2.0).g(-0.002).col(WHITE, AZURE).life(40).cont(4).on(Trigger.AMBIENT).desc("Fine sparkling dust floating upwards.");
        e("golden_embers", "Golden Embers", DIVINE, FOUNTAIN, DUST).n(30).sp(0.25).g(0.03).col(GOLD, EMBER).life(24).on(Trigger.HEAL).desc("Gold sparks thrown up and falling back.");
        e("laurel_leaves", "Laurel Leaves", DIVINE, SPIRAL, HAPPY).k2(DUST, 0.4).n(36).turns(3).h(2.0).r(0.9).col(LEAF, GOLD).life(20).on(Trigger.HEAL).desc("Rising laurel wreath spiral.");
        e("sun_disk", "Sun Disk", DIVINE, DISK, DUST).n(70).r(1.3).sp(0.05).col(SUN, AMBER).life(20).size(1.2, 0.8).on(Trigger.LAND).desc("Filled solar disk, brighter in the middle.");
        e("athena_sigil", "Athena Sigil", DIVINE, GLYPH, GLOW).n(70).r(1.8).turns(2).col(MARBLE, AZURE).life(34).on(Trigger.TEST).desc("A large delta sigil of the goddess of wisdom.");
        e("poseidon_ripple", "Poseidon Ripple", DIVINE, RING, SPLASH).k2(BUBBLE, 0.3).n(40).r(1.4).sp(0.12).col(SEA, WHITE).life(14).on(Trigger.WATER).desc("Water ring spreading on the surface.");
        e("apollo_rays", "Apollo Rays", DIVINE, RAYS, END_ROD).n(64).r(1.6).h(1.4).col(GOLD, WHITE).life(16).on(Trigger.TEST).desc("Eight sun rays growing outwards.");
        e("hermes_streak", "Hermes Streak", DIVINE, STREAK, SPARK).k2(WHITE_SMOKE, 0.3).n(30).r(1.2).sp(0.1).col(SKY, WHITE).life(10).cont(12).on(Trigger.SPRINT).desc("Fast streak line behind the runner.");
        e("hera_bloom", "Hera Bloom", DIVINE, SPIRAL, CHERRY).n(48).turns(4).h(0.2).r(1.5).life(30).on(Trigger.HEAL).desc("Flat blooming flower of petals.");
        e("divine_pillars", "Divine Pillars", DIVINE, PILLAR, END_ROD).k2(GLOW, 0.25).n(60).h(3.0).r(1.1).sp(0.03).col(WHITE, GOLD).life(18).on(Trigger.TOTEM).desc("Four light pillars like temple columns.");
        e("marble_fragments", "Marble Fragments", DIVINE, FRAGMENTS, DUST).n(18).sp(0.3).g(0.04).size(1.6, 1.2).col(MARBLE, GREY).life(22).on(Trigger.HIT).desc("Heavy marble chips falling to the ground.");
        // ---- Combat (17-30)
        e("critical_stars", "Critical Stars", COMBAT, BURST, CRIT).k2(FIREWORK, 0.2).n(22).sp(0.4).h(1.4).col(WHITE, GOLD).life(10).on(Trigger.CRIT).desc("Star burst on a critical hit.");
        e("blade_arc", "Blade Arc", COMBAT, ARC, DUST).n(30).r(1.6).sp(0.05).col(WHITE, AZURE).life(6).size(0.9, 0.5).on(Trigger.HIT).desc("Wide sword arc in front of the player.");
        e("impact_sparks", "Impact Sparks", COMBAT, BURST, SPARK).n(24).sp(0.5).g(0.04).h(1.2).life(10).col(SUN, EMBER).on(Trigger.HIT).desc("Sparks bouncing off the target.");
        e("damage_flash", "Damage Flash", COMBAT, BURST, DUST).n(30).sp(0.08).r(0.0).h(1.0).life(5).col(RED, CRIMSON).size(1.4, 1.0).on(Trigger.DAMAGE_TAKEN).desc("Short red flash around the body.");
        e("hit_bubbles", "Hit Bubbles", COMBAT, DRIFT, BUBBLE).n(16).r(0.6).h(1.5).sp(0.05).life(12).on(Trigger.HIT).desc("Playful bubbles on hit.");
        e("hitmarker_burst", "Hitmarker Burst", COMBAT, CROSS, CRIT).turns(2).n(16).r(0.5).h(1.6).sp(0.1).life(6).col(WHITE, WHITE).on(Trigger.HIT).desc("An X-shaped hitmarker in the air.");
        e("shockwave_ring", "Shockwave Ring", COMBAT, SHOCKWAVE, CLOUD).n(40).sp(0.4).r(0.6).life(10).col(WHITE, GREY).on(Trigger.KILL).desc("Fast expanding cloud ring.");
        e("impact_dust", "Impact Dust", COMBAT, RING, DUST_PLUME).n(16).r(0.5).sp(0.05).life(14).on(Trigger.LAND).desc("Low dust puffs around the impact.");
        e("prism_shards", "Prism Shards", COMBAT, FRAGMENTS, DUST).rnd().n(24).sp(0.35).r(0.4).g(0.02).life(16).on(Trigger.CRIT).desc("Multicoloured prism shards.");
        e("combo_spark", "Combo Spark", COMBAT, ORBIT, SPARK).n(12).r(0.7).h(1.8).sp(0.15).life(10).col(SKY, GOLD).on(Trigger.HIT).desc("Sparks circling the target.");
        e("damage_glyph", "Damage Glyph", COMBAT, GLYPH, DUST).turns(3).n(50).r(1.0).life(16).col(RED, CRIMSON).on(Trigger.DAMAGE_TAKEN).desc("A red sigma glyph under your feet.");
        e("stagger_lines", "Stagger Lines", COMBAT, RAYS, SMOKE).n(32).r(0.9).h(2.0).sp(0.05).life(8).col(GREY, WHITE).on(Trigger.HIT).desc("Short radial stagger lines.");
        e("hit_color_pulse", "Hit Color Pulse", COMBAT, RING, DUST).n(24).r(0.6).sp(0.15).life(7).col(RED, 0xFFFFB3B3).on(Trigger.HIT).desc("Red pulse ring around the target.");
        e("deflect_spark", "Deflect Spark", COMBAT, ARC, SPARK).n(18).r(0.9).sp(0.2).life(6).col(SUN, WHITE).on(Trigger.DAMAGE_TAKEN).desc("Small arc of deflected sparks.");
        // ---- Movement (31-42)
        e("jump_circle", "Jump Circle", MOVEMENT, RING, GLOW).n(32).r(0.7).sp(0.02).col(AZURE, WHITE).life(12).on(Trigger.JUMP).desc("Clean circle on the ground when jumping.");
        e("landing_ring", "Landing Ring", MOVEMENT, SHOCKWAVE, WHITE_SMOKE).n(28).sp(0.25).r(0.5).life(10).on(Trigger.LAND).desc("Soft smoke ring on landing.");
        e("sprint_streaks", "Sprint Streaks", MOVEMENT, STREAK, CLOUD).n(10).r(0.6).sp(0.05).life(8).cont(10).on(Trigger.SPRINT).desc("Thin wind streaks while sprinting.");
        e("footstep_dust", "Footstep Dust", MOVEMENT, DISK, DUST).n(4).r(0.25).sp(0.02).col(SAND, GREY).life(14).cont(4).on(Trigger.MOVE).desc("Tiny dust under the feet.");
        e("wind_spirals", "Wind Spirals", MOVEMENT, HELIX, CLOUD).n(30).turns(2).h(1.8).r(0.8).life(10).on(Trigger.SPRINT).desc("Double wind helix around the body.");
        e("dash_echo", "Dash Echo", MOVEMENT, STREAK, DUST).n(20).r(0.8).h(1.6).size(2.0, 1.5).sp(0.0).col(AZURE, COBALT).fade(0.6, 0.2).life(8).on(Trigger.SPRINT).desc("Ghostly echo silhouette left behind.");
        e("motion_ribbons", "Motion Ribbons", MOVEMENT, RIBBON, END_ROD).turns(2).n(24).r(1.0).life(10).cont(8).on(Trigger.MOVE).desc("Waving ribbon following your path.");
        e("comet_trails", "Comet Trails", MOVEMENT, RIBBON, FIREWORK).turns(1).n(20).r(1.2).life(12).trail().col(SKY, AZURE).on(Trigger.SPRINT).desc("Comet-like tail with sparkling echo.");
        e("orbiting_stars", "Orbiting Stars", MOVEMENT, ORBIT, END_ROD).n(16).r(1.0).h(1.2).sp(0.1).life(14).cont(3).on(Trigger.IDLE).desc("Stars orbiting the body.");
        e("step_glyphs", "Step Glyphs", MOVEMENT, GLYPH, WAX).turns(4).n(30).r(0.6).life(20).col(GOLD, AZURE).on(Trigger.MOVE).desc("Tiny glyphs printed where you step.");
        e("feather_drift", "Feather Drift", MOVEMENT, DRIFT, ASH).n(20).r(1.2).h(2.2).g(0.005).life(40).col(WHITE, MARBLE).on(Trigger.JUMP).desc("Feathers slowly falling around you.");
        e("ground_pulse", "Ground Pulse", MOVEMENT, DISK, GLOW).n(40).r(0.9).sp(0.1).life(10).col(AZURE, SKY).on(Trigger.LAND).desc("Glowing pulse spreading on the ground.");
        // ---- Magic (43-54)
        e("arcane_circles", "Arcane Circles", MAGIC, RING, WITCH).n(48).r(1.2).sp(0.0).life(20).col(VIOLET, AZURE).on(Trigger.TEST).desc("Static magic circle.");
        e("ethereal_ribbons", "Ethereal Ribbons", MAGIC, RIBBON, GLOW).turns(3).n(40).r(1.5).life(18).col(SKY, VIOLET).on(Trigger.TEST).desc("Long glowing ethereal ribbon.");
        e("glyph_burst", "Glyph Burst", MAGIC, GLYPH, MAGIC_CRIT).turns(5).n(56).r(1.2).sp(0.3).life(16).col(VIOLET, WHITE).on(Trigger.CRIT).desc("Phi glyph that bursts upwards.");
        e("portal_fragments", "Portal Fragments", MAGIC, FRAGMENTS, PORTAL).n(30).sp(0.3).life(20).col(VIOLET, 0xFF3A1A6A).on(Trigger.PORTAL).desc("Violet fragments after a portal.");
        e("echo_rings", "Echo Rings", MAGIC, SHOCKWAVE, SCULK_SOUL).n(24).sp(0.2).r(0.8).life(16).on(Trigger.TEST).desc("Sculk echo rings.");
        e("spirit_wisps", "Spirit Wisps", MAGIC, ORBIT, SOUL).n(10).r(1.3).h(1.6).sp(0.08).life(24).on(Trigger.IDLE).desc("Few wisps slowly circling.");
        e("starfall", "Starfall", MAGIC, STARFALL, END_ROD).n(30).r(1.5).h(4.0).sp(0.25).life(20).col(WHITE, SKY).on(Trigger.TEST).desc("Stars raining down.");
        e("astral_comets", "Astral Comets", MAGIC, STARFALL, FIREWORK).n(12).h(5.0).r(1.0).sp(0.4).life(18).trail().col(SKY, GOLD).on(Trigger.KILL).desc("Few big comets with trails.");
        e("celestial_spiral", "Celestial Spiral", MAGIC, SPIRAL, END_ROD).turns(4).h(2.6).r(1.2).n(60).life(20).col(AZURE, WHITE).on(Trigger.TEST).desc("Tall rising spiral of light.");
        e("spectral_threads", "Spectral Threads", MAGIC, HELIX, REVERSE_PORTAL).turns(3).h(2.4).r(1.0).n(50).life(18).on(Trigger.PORTAL).desc("Two spectral threads twisting upwards.");
        e("relic_pulse", "Relic Pulse", MAGIC, HALO, ENCHANT).n(30).r(2.2).h(1.0).sp(0.1).life(18).on(Trigger.ITEM_USE).desc("Wide pulse of enchantment runes at waist height.");
        e("divine_orbit", "Divine Orbit", MAGIC, ORBIT, GLOW).n(20).r(0.8).h(2.2).sp(0.2).life(12).col(GOLD, AZURE).on(Trigger.TEST).desc("Fast orbit above the head.");
        // ---- Elemental (55-68)
        e("ember_drift", "Ember Drift", ELEMENTAL, DRIFT, DUST).n(24).r(1.0).h(1.0).g(-0.004).col(EMBER, RED).life(30).cont(3).on(Trigger.AMBIENT).desc("Embers floating upward.");
        e("phoenix_sparks", "Phoenix Sparks", ELEMENTAL, FOUNTAIN, FLAME).k2(LAVA, 0.1).n(30).sp(0.3).life(16).on(Trigger.TOTEM).desc("Flame fountain like a phoenix rising.");
        e("flame_petals", "Flame Petals", ELEMENTAL, RAYS, FLAME).n(40).r(1.0).h(0.4).life(12).on(Trigger.TEST).desc("Flower of fire rays on the ground.");
        e("water_ripples", "Water Ripples", ELEMENTAL, RING, DRIP_WATER).n(50).r(1.8).sp(0.0).life(16).col(SEA, WHITE).on(Trigger.WATER).desc("Wide still ring of droplets.");
        e("mist_puff", "Mist Puff", ELEMENTAL, DRIFT, WHITE_SMOKE).n(16).r(1.0).h(0.8).sp(0.02).life(30).on(Trigger.TEST).desc("Low lingering mist.");
        e("rain_splashes", "Rain Splashes", ELEMENTAL, STARFALL, DRIP_WATER).n(40).h(3.0).r(1.2).sp(0.3).life(16).col(SEA, SEA).on(Trigger.TEST).desc("Local rain shower.");
        e("leaf_swirl", "Leaf Swirl", ELEMENTAL, VORTEX, CHERRY).turns(2).n(40).r(1.5).h(2.0).sp(0.08).life(26).on(Trigger.TEST).desc("Leaves pulled into a swirl.");
        e("pollen_drift", "Pollen Drift", ELEMENTAL, DRIFT, SPORE).n(30).r(2.0).h(2.5).life(40).cont(4).on(Trigger.AMBIENT).desc("Spore blossom pollen in the air.");
        e("fireflies", "Fireflies", ELEMENTAL, DRIFT, GLOW).n(12).r(3.0).h(2.0).sp(0.03).life(60).col(0xFFE9FF7A, 0xFF9CD65C).cont(1.5).on(Trigger.AMBIENT).desc("Few slow glowing fireflies.");
        e("sand_sweep", "Sand Sweep", ELEMENTAL, STREAK, DUST).n(30).r(1.4).h(0.2).sp(0.06).col(SAND, 0xFFB09060).life(14).on(Trigger.SPRINT).desc("Low sand sweeping behind you.");
        e("dust_vortex", "Dust Vortex", ELEMENTAL, VORTEX, DUST).turns(3).n(44).r(1.2).h(1.6).sp(0.06).col(SAND, GREY).life(20).on(Trigger.TEST).desc("Small dust devil.");
        e("cloud_puff", "Cloud Puff", ELEMENTAL, BURST, CLOUD).n(14).sp(0.08).h(0.6).life(16).on(Trigger.JUMP).desc("Soft cloud puff.");
        e("lava_sparks", "Lava Sparks", ELEMENTAL, FOUNTAIN, LAVA).n(10).sp(0.35).life(20).on(Trigger.TEST).desc("Popping lava drops.");
        e("ender_fragments", "Ender Fragments", ELEMENTAL, BURST, PORTAL).n(40).sp(0.5).h(1.0).life(18).on(Trigger.PORTAL).desc("Ender particles pulled out in all directions.");
        // ---- Support (69-80)
        e("healing_motifs", "Healing Motifs", SUPPORT, SPIRAL, HEART).n(8).turns(1).h(2.0).r(0.7).life(20).on(Trigger.HEAL).desc("Few hearts rising in a slow spiral.");
        e("totem_halo", "Totem Halo", SUPPORT, HALO, TOTEM).n(36).r(1.6).h(2.2).sp(0.08).life(24).col(0xFFF2E36B, 0xFF5FD38D).on(Trigger.TOTEM).desc("Big totem halo above the head.");
        e("totem_shards", "Totem Shards", SUPPORT, FRAGMENTS, TOTEM).n(30).sp(0.4).life(24).col(0xFFF2E36B, 0xFF5FD38D).on(Trigger.TOTEM).desc("Totem shards flying apart.");
        e("potion_mist", "Potion Mist", SUPPORT, DRIFT, WITCH).n(20).r(0.9).h(2.0).sp(0.02).life(26).col(VIOLET, PINK).on(Trigger.ITEM_USE).desc("Mist around you while drinking.");
        e("item_pickup_spark", "Item Pickup Spark", SUPPORT, BURST, WAX).n(8).sp(0.1).h(0.4).life(10).col(GOLD, WHITE).on(Trigger.PICKUP).desc("Tiny spark on item pickup.");
        e("enchantment_dust", "Enchantment Dust", SUPPORT, FOUNTAIN, ENCHANT).n(40).sp(0.15).life(24).on(Trigger.ITEM_USE).desc("Runes flowing up like a fountain.");
        e("chest_open_glimmer", "Chest Open Glimmer", SUPPORT, FOUNTAIN, END_ROD).n(14).sp(0.12).r(0.4).life(16).col(GOLD, WHITE).on(Trigger.ITEM_USE).desc("Glimmer when a container is opened.");
        e("companion_arrival", "Companion Arrival", SUPPORT, VORTEX, END_ROD).turns(2).n(40).r(1.0).h(1.4).sp(0.08).life(18).col(AZURE, GOLD).on(Trigger.COMPANION_SPAWN).desc("Swirl that reveals your companion.");
        e("companion_trail", "Companion Trail", SUPPORT, RIBBON, DUST).turns(1).n(10).r(0.4).h(0.8).size(0.6, 0.3).life(12).cont(4).col(AZURE, MARBLE).on(Trigger.MOVE).desc("Soft trail behind a companion.");
        e("boss_sigils", "Boss Sigils", SUPPORT, GLYPH, SOUL_FLAME).turns(3).n(80).r(2.4).life(40).q(QualityLevel.BALANCED).on(Trigger.TEST).desc("Big soul-fire sigil for boss fights.");
        e("victory_confetti", "Victory Confetti", SUPPORT, CONFETTI, DUST).rnd().n(60).sp(0.35).r(1.0).h(2.0).g(0.02).life(40).on(Trigger.KILL).desc("Colourful confetti.");
        e("marble_dust", "Marble Dust", SUPPORT, MOSAIC, DUST).n(49).r(0.9).sp(0.02).col(MARBLE, GREY).life(18).on(Trigger.TEST).desc("Mosaic tiles of marble dust on the ground.");
        ALL = Collections.unmodifiableList(new ArrayList<>(BY_ID.values()));
    }

    private EffectCatalog() {}

    public static EffectDef get(String id) { return BY_ID.get(id); }
    public static List<String> ids() { return new ArrayList<>(BY_ID.keySet()); }
    public static List<EffectDef> byCategory(EffectCategory c) { List<EffectDef> l = new ArrayList<>(); for (EffectDef d : ALL) if (d.category == c) l.add(d); return l; }
    public static List<EffectDef> forTrigger(Trigger t) { List<EffectDef> l = new ArrayList<>(); for (EffectDef d : ALL) if (d.trigger == t) l.add(d); return l; }
}
