package dev.ancientvisuals.core.particle;

/** Vanilla particle sprites we drive. tintable = colour from the effect is applied. */
public enum ParticleKind {
    DUST(true), GLOW(true), SPARK(true), END_ROD(true), ENCHANT(true), FLAME(false), SOUL_FLAME(false), SMOKE(true), CLOUD(true), BUBBLE(true),
    CHERRY(false), CRIT(true), MAGIC_CRIT(true), HEART(false), NOTE(false), PORTAL(true), REVERSE_PORTAL(true), SPLASH(true), DRIP_WATER(true),
    LAVA(false), WAX(true), SCRAPE(true), FIREWORK(true), TOTEM(true), ASH(true), SPORE(true), SOUL(false), HAPPY(true), WITCH(true),
    DRAGON(true), NAUTILUS(true), DOLPHIN(true), POOF(true), SWEEP(true), SCULK_SOUL(false), WHITE_SMOKE(true), DUST_PLUME(true);
    public final boolean tintable;
    ParticleKind(boolean t) { tintable = t; }
}
