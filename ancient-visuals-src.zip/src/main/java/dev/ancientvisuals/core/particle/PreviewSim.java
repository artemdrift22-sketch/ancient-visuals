package dev.ancientvisuals.core.particle;

import dev.ancientvisuals.core.util.Colors;
import dev.ancientvisuals.core.util.Rng;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Lightweight simulation used by the Particle Studio preview (same shape generator as in-world playback). */
public final class PreviewSim {
    public static final class P {
        public double x, y, z, vx, vy, vz, angle;
        public int age, life, delay;
        public ParticleRequest req;
        public double t() { return life <= 0 ? 1 : Math.min(1, age / (double) life); }
        public int color() { return Colors.lerp(req.colorStart, req.colorEnd, t()); }
        public double alpha() { return req.alphaStart + (req.alphaEnd - req.alphaStart) * req.alphaCurve.apply(t()); }
    }
    private final List<P> live = new ArrayList<>();
    private final EffectPlayer helper = new EffectPlayer();
    public static final int MAX = 1200;

    public List<P> particles() { return live; }
    public void clear() { live.clear(); }

    public void play(EffectDef d, long seed, double yaw) {
        int n = Math.min(400, d.count);
        for (Spawn s : ShapeGen.generate(d, new Rng(seed == 0 ? 1 : seed), yaw, n)) {
            if (live.size() >= MAX) break;
            P p = new P();
            p.req = helper.request(d, s, 0, 0, 0);
            p.x = p.req.x; p.y = p.req.y; p.z = p.req.z; p.vx = p.req.vx; p.vy = p.req.vy; p.vz = p.req.vz;
            p.life = p.req.lifetime; p.delay = s.delay();
            live.add(p);
        }
    }

    public void tick() {
        for (Iterator<P> it = live.iterator(); it.hasNext(); ) {
            P p = it.next();
            if (p.delay > 0) { p.delay--; continue; }
            p.vy -= p.req.gravity;
            p.vx *= p.req.drag; p.vy *= p.req.drag; p.vz *= p.req.drag;
            p.x += p.vx; p.y += p.vy; p.z += p.vz;
            p.angle += p.req.angularVelocity;
            if (++p.age >= p.life) it.remove();
        }
    }

    /** Simple orbit camera projection: returns screen offset (x,y) in units and depth. */
    public static double[] project(double x, double y, double z, double camYaw, double camPitch) {
        double cy = Math.cos(camYaw), sy = Math.sin(camYaw);
        double rx = x * cy - z * sy, rz = x * sy + z * cy;
        double cp = Math.cos(camPitch), sp = Math.sin(camPitch);
        double ry = y * cp - rz * sp, depth = y * sp + rz * cp;
        return new double[] { rx, -ry, depth };
    }
}
