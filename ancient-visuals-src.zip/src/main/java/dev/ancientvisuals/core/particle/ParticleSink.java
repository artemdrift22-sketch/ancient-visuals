package dev.ancientvisuals.core.particle;

@FunctionalInterface
public interface ParticleSink {
    /** @return true if the particle was actually created */
    boolean spawn(ParticleRequest r);
}
