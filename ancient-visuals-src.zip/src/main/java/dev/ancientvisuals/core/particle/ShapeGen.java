package dev.ancientvisuals.core.particle;

import dev.ancientvisuals.core.util.Rng;

import java.util.ArrayList;
import java.util.List;

/** Generates the silhouette of an effect: positions, velocities and delays per particle. Pure math, no Minecraft. */
public final class ShapeGen {
    private ShapeGen() {}

    static final String[][] GLYPHS = {
        { "#..#..#", "#..#..#", ".#.#.#.", "..###..", "...#...", "...#...", "..###.." }, // psi
        { "..###..", ".#...#.", "#.....#", "#.....#", ".#...#.", "..#.#..", "###.###" }, // omega
        { "...#...", "..#.#..", "..#.#..", ".#...#.", ".#...#.", "#.....#", "#######" }, // delta
        { "#######", ".#.....", "..#....", "...#...", "..#....", ".#.....", "#######" }, // sigma
        { "...#...", ".#####.", "#..#..#", "#..#..#", ".#####.", "...#...", "...#..." }  // phi
    };

    public static List<Spawn> generate(EffectDef d, Rng rng, double yawDeg, int n) {
        List<Spawn> out = new ArrayList<>(Math.max(0, n));
        if (n <= 0) return out;
        double yaw = Math.toRadians(yawDeg);
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);   // forward
        double rx = -fz, rz = fx;                          // right
        double r = d.spread, h = d.height, s = d.speed, j = d.directionJitter * 0.08;
        List<int[]> glyphCells = null;
        double[][] bolt = null;
        if (d.shape == EmitterShape.GLYPH) {
            String[] g = GLYPHS[(int) Math.floorMod(d.seed + d.turns, (long) GLYPHS.length)];
            glyphCells = new ArrayList<>();
            for (int y = 0; y < g.length; y++) for (int x = 0; x < g[y].length(); x++) if (g[y].charAt(x) == '#') glyphCells.add(new int[] { x, y });
        }
        if (d.shape == EmitterShape.BOLT) {
            int segs = 7;
            bolt = new double[segs + 1][2];
            for (int i = 0; i <= segs; i++) { bolt[i][0] = i == 0 || i == segs ? 0 : rng.signed() * r * 0.35; bolt[i][1] = i == 0 || i == segs ? 0 : rng.signed() * r * 0.35; }
        }
        int side = (int) Math.ceil(Math.sqrt(n));
        for (int i = 0; i < n; i++) {
            double t = n == 1 ? 0 : i / (double) (n - 1);
            double u = i / (double) n;
            double x = 0, y = 0, z = 0, vx = 0, vy = 0, vz = 0, colorT = t;
            int delay = 0;
            double sizeMul = 0.8 + 0.4 * rng.nextDouble();
            switch (d.shape) {
                case RING -> { double a = u * Math.PI * 2; x = Math.cos(a) * r; z = Math.sin(a) * r; y = 0.05; vx = Math.cos(a) * s * 0.3; vz = Math.sin(a) * s * 0.3; }
                case SHOCKWAVE -> { int layer = i % 2; double a = u * Math.PI * 2; double rr = r * 0.3; x = Math.cos(a) * rr; z = Math.sin(a) * rr; y = 0.08 + layer * 0.05; vx = Math.cos(a) * s * (1 - layer * 0.35); vz = Math.sin(a) * s * (1 - layer * 0.35); delay = layer * 3; }
                case DISK -> { double a = rng.nextDouble() * Math.PI * 2, rr = Math.sqrt(rng.nextDouble()) * r; x = Math.cos(a) * rr; z = Math.sin(a) * rr; y = 0.03; vy = s * 0.5 * rng.nextDouble(); colorT = rr / Math.max(0.01, r); }
                case HALO -> { double a = u * Math.PI * 2; x = Math.cos(a) * r * 0.5; z = Math.sin(a) * r * 0.5; y = h; vx = -Math.sin(a) * s * 0.2; vz = Math.cos(a) * s * 0.2; }
                case SPIRAL -> { double a = t * d.turns * Math.PI * 2; double rr = r * (1 - 0.6 * t); x = Math.cos(a) * rr; z = Math.sin(a) * rr; y = t * h; vx = -Math.sin(a) * s * 0.2; vz = Math.cos(a) * s * 0.2; vy = 0.01; delay = (int) (t * 12); }
                case HELIX -> { int strand = i % 2; double a = t * d.turns * Math.PI * 2 + strand * Math.PI; x = Math.cos(a) * r * 0.6; z = Math.sin(a) * r * 0.6; y = t * h; delay = (int) (t * 10); colorT = strand; }
                case BOLT -> {
                    double pos = t * (bolt.length - 1); int seg = Math.min(bolt.length - 2, (int) pos); double f = pos - seg;
                    x = bolt[seg][0] + (bolt[seg + 1][0] - bolt[seg][0]) * f; z = bolt[seg][1] + (bolt[seg + 1][1] - bolt[seg][1]) * f; y = h * (1 - t) + 0.1;
                    if (i % 6 == 5) { x += rng.signed() * r * 0.3; z += rng.signed() * r * 0.3; sizeMul *= 0.7; }
                    vy = -s * 0.1;
                }
                case BURST -> { double gx = rng.gaussian(), gy = rng.gaussian(), gz = rng.gaussian(); double len = Math.max(1e-6, Math.sqrt(gx * gx + gy * gy + gz * gz)); double m = s * (0.5 + 0.5 * rng.nextDouble()); y = h * 0.5; vx = gx / len * m; vy = gy / len * m; vz = gz / len * m; }
                case FOUNTAIN -> { double a = rng.nextDouble() * Math.PI * 2, hz = r * 0.15 * rng.nextDouble(); y = 0.1; vx = Math.cos(a) * hz; vz = Math.sin(a) * hz; vy = s * (0.8 + 0.4 * rng.nextDouble()); }
                case PILLAR -> { int col = i % 4; double a = col * Math.PI / 2 + Math.PI / 4; x = Math.cos(a) * r; z = Math.sin(a) * r; y = rng.nextDouble() * h; vy = s * 0.2; delay = (int) (y / Math.max(0.01, h) * 6); colorT = y / Math.max(0.01, h); }
                case ARC -> { double a = yaw + Math.PI / 2 + Math.toRadians(-60 + 120 * t); double ax = Math.cos(a), az = Math.sin(a); x = ax * r; z = az * r; y = h * 0.6 + t * 0.3; vx = -az * s; vz = ax * s; delay = (int) (t * 4); }
                case RAYS -> { int rays = 8; int ray = i % rays; double along = (i / rays) / Math.max(1.0, n / (double) rays); double a = ray * Math.PI * 2 / rays; x = Math.cos(a) * (0.2 + along * r); z = Math.sin(a) * (0.2 + along * r); y = 0.1 + along * h * 0.5; vx = Math.cos(a) * s * 0.1; vz = Math.sin(a) * s * 0.1; delay = (int) (along * 8); colorT = along; }
                case GLYPH -> { int[] c = glyphCells.get(i % glyphCells.size()); double cell = r / 3.5; x = (c[0] - 3) * cell; z = (c[1] - 3) * cell; y = 0.05 + (i / glyphCells.size()) * 0.04; vy = s * 0.15; delay = (int) ((c[1] * 7 + c[0]) * 0.25); }
                case ORBIT -> { double a = u * Math.PI * 2; x = Math.cos(a) * r; z = Math.sin(a) * r; y = h * 0.5 + Math.sin(a * 2) * 0.15; vx = -Math.sin(a) * s; vz = Math.cos(a) * s; delay = i % 3; }
                case RIBBON -> { double dist = t * r * 2; double lat = Math.sin(t * d.turns * Math.PI * 2) * 0.35; x = -fx * dist + rx * lat; z = -fz * dist + rz * lat; y = h * 0.5 + Math.cos(t * d.turns * Math.PI) * 0.1; delay = (int) (t * 6); }
                case CONFETTI -> { double a = rng.nextDouble() * Math.PI * 2, hz = s * (0.3 + 0.7 * rng.nextDouble()); y = h; vx = Math.cos(a) * hz * r * 0.5; vz = Math.sin(a) * hz * r * 0.5; vy = s * (0.6 + 0.6 * rng.nextDouble()); colorT = rng.nextDouble(); }
                case DRIFT -> { double a = rng.nextDouble() * Math.PI * 2, rr = Math.sqrt(rng.nextDouble()) * r; x = Math.cos(a) * rr; z = Math.sin(a) * rr; y = rng.nextDouble() * h; vx = rng.signed() * s * 0.2; vy = rng.signed() * s * 0.2; vz = rng.signed() * s * 0.2; delay = rng.nextInt(20); colorT = rng.nextDouble(); }
                case VORTEX -> { double a = t * d.turns * Math.PI * 2; double rr = r * (1 - t); x = Math.cos(a) * rr; z = Math.sin(a) * rr; y = t * h; vx = (-Math.cos(a) * 0.3 - Math.sin(a)) * s; vz = (-Math.sin(a) * 0.3 + Math.cos(a)) * s; vy = s * 0.1; delay = (int) (t * 10); }
                case STREAK -> { double dist = t * r * 2; x = -fx * dist + rx * rng.signed() * 0.15; z = -fz * dist + rz * rng.signed() * 0.15; y = h * 0.4 + rng.signed() * 0.1; vx = -fx * s; vz = -fz * s; }
                case STARFALL -> { double a = rng.nextDouble() * Math.PI * 2, rr = Math.sqrt(rng.nextDouble()) * r * 1.5; x = Math.cos(a) * rr; z = Math.sin(a) * rr; y = h + rng.nextDouble(); vx = 0.02 * Math.cos(a + 1); vz = 0.02 * Math.sin(a + 1); vy = -s; delay = rng.nextInt(15); }
                case MOSAIC -> { int gx = i % side, gz = i / side; double span = side <= 1 ? 0 : 1.0 / (side - 1); x = (gx * span - 0.5) * 2 * r; z = (gz * span - 0.5) * 2 * r; y = 0.05; colorT = (gx + gz) % 2; delay = gx + gz; vy = s * 0.05; }
                case FRAGMENTS -> { double a = rng.nextDouble() * Math.PI * 2; y = h * 0.5; vx = Math.cos(a) * s; vz = Math.sin(a) * s; vy = s * 0.5 * rng.nextDouble(); sizeMul = 1.2 + 0.8 * rng.nextDouble(); }
                case CROSS -> {
                    int arm = i % 4; double along = (i / 4 + 1) / Math.max(1.0, Math.ceil(n / 4.0));
                    double ang = arm * Math.PI / 2 + (d.turns % 2 == 0 ? Math.PI / 4 : 0);
                    double lx = Math.cos(ang) * along * r, ly = Math.sin(ang) * along * r;
                    x = rx * lx + fx * 0.6; z = rz * lx + fz * 0.6; y = h * 0.5 + ly;
                    vx = rx * Math.cos(ang) * s * 0.2; vz = rz * Math.cos(ang) * s * 0.2; vy = Math.sin(ang) * s * 0.2; colorT = along;
                }
            }
            x += rng.signed() * j; y += rng.signed() * j * 0.5; z += rng.signed() * j;
            if (d.randomColor) colorT = rng.nextDouble();
            boolean secondary = d.kind2 != null && rng.chance(d.secondaryRatio);
            out.add(new Spawn(x, y, z, vx, vy, vz, delay, colorT, sizeMul, secondary));
        }
        return out;
    }
}
