package dev.ancientvisuals.core.particle;

/** Counts our live particles (by lifetime) and refuses spawns above the limit, so effects never flood the client. */
public final class ParticleBudget {
    private static final int WINDOW = 512;
    private final int[] expiring = new int[WINDOW];
    private long tick;
    private int live;
    private long spawned, dropped;

    public int live() { return live; }
    public long spawnedTotal() { return spawned; }
    public long droppedTotal() { return dropped; }

    public int reserve(int want, int lifetimeTicks, int max) {
        int allowed = Math.max(0, Math.min(want, max - live));
        dropped += want - allowed;
        if (allowed > 0) {
            live += allowed; spawned += allowed;
            int t = Math.max(1, Math.min(WINDOW - 1, lifetimeTicks + 1));
            expiring[(int) ((tick + t) % WINDOW)] += allowed;
        }
        return allowed;
    }
    public void release(int n) { live = Math.max(0, live - n); }
    public void tick() {
        tick++;
        int idx = (int) (tick % WINDOW);
        live = Math.max(0, live - expiring[idx]);
        expiring[idx] = 0;
    }
    public void clear() { java.util.Arrays.fill(expiring, 0); live = 0; }
}
