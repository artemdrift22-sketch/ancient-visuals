package dev.ancientvisuals.core.particle;

/** One planned particle relative to the effect origin (blocks / blocks per tick). */
public record Spawn(double x, double y, double z, double vx, double vy, double vz, int delay, double colorT, double sizeMul, boolean secondary) {}
