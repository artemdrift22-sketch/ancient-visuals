package dev.ancientvisuals.core.particle;

import dev.ancientvisuals.core.util.Easing;

/** Everything a sink needs to spawn and animate one particle. */
public final class ParticleRequest {
    public ParticleKind kind;
    public double x, y, z, vx, vy, vz;
    public int colorStart, colorEnd;
    public float size = 1, alphaStart = 1, alphaEnd = 1, gravity, drag = 0.96f, angularVelocity;
    public Easing alphaCurve = Easing.LINEAR;
    public int lifetime = 20;
    public boolean collides;
}
