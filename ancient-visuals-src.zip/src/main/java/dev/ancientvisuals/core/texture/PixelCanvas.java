package dev.ancientvisuals.core.texture;

import dev.ancientvisuals.core.util.Colors;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** ARGB pixel editor model for the Texture Lab with undo/redo. */
public final class PixelCanvas {
    public static final int MAX_SIDE = 1024, UNDO_LIMIT = 50;
    private record Snap(int w, int h, int[] px) {}
    private int w, h;
    private int[] px;
    private final Deque<Snap> undo = new ArrayDeque<>(), redo = new ArrayDeque<>();

    public PixelCanvas(int w, int h) {
        if (w < 1 || h < 1 || w > MAX_SIDE || h > MAX_SIDE) throw new IllegalArgumentException("canvas size " + w + "x" + h);
        this.w = w; this.h = h; this.px = new int[w * h];
    }
    public PixelCanvas(int w, int h, int[] pixels) { this(w, h); System.arraycopy(pixels, 0, px, 0, w * h); }

    public int width() { return w; }
    public int height() { return h; }
    public int[] pixels() { return px; }
    public PixelCanvas copy() { return new PixelCanvas(w, h, px); }
    public boolean in(int x, int y) { return x >= 0 && y >= 0 && x < w && y < h; }
    public int get(int x, int y) { return in(x, y) ? px[y * w + x] : 0; }
    public void set(int x, int y, int c) { if (in(x, y)) px[y * w + x] = c; }

    public void checkpoint() { undo.push(new Snap(w, h, px.clone())); while (undo.size() > UNDO_LIMIT) undo.removeLast(); redo.clear(); }
    public boolean undo() { if (undo.isEmpty()) return false; redo.push(new Snap(w, h, px.clone())); restore(undo.pop()); return true; }
    public boolean redo() { if (redo.isEmpty()) return false; undo.push(new Snap(w, h, px.clone())); restore(redo.pop()); return true; }
    public int undoDepth() { return undo.size(); }
    private void restore(Snap s) { w = s.w; h = s.h; px = s.px; }

    public void brush(int cx, int cy, int radius, int color) {
        int r = Math.max(0, radius);
        for (int y = cy - r; y <= cy + r; y++) for (int x = cx - r; x <= cx + r; x++) if ((x - cx) * (x - cx) + (y - cy) * (y - cy) <= r * r + r) set(x, y, color);
    }
    public void erase(int cx, int cy, int radius) { brush(cx, cy, radius, 0); }

    public void line(int x0, int y0, int x1, int y1, int color, int radius) {
        int dx = Math.abs(x1 - x0), dy = -Math.abs(y1 - y0), sx = x0 < x1 ? 1 : -1, sy = y0 < y1 ? 1 : -1, err = dx + dy;
        for (int guard = 0; guard < 4 * MAX_SIDE; guard++) {
            brush(x0, y0, radius, color);
            if (x0 == x1 && y0 == y1) break;
            int e2 = 2 * err;
            if (e2 >= dy) { err += dy; x0 += sx; }
            if (e2 <= dx) { err += dx; y0 += sy; }
        }
    }

    public void rect(int x0, int y0, int x1, int y1, int color, boolean filled) {
        int ax = Math.min(x0, x1), bx = Math.max(x0, x1), ay = Math.min(y0, y1), by = Math.max(y0, y1);
        for (int y = ay; y <= by; y++) for (int x = ax; x <= bx; x++) if (filled || x == ax || x == bx || y == ay || y == by) set(x, y, color);
    }

    /** Iterative flood fill (no recursion, safe for 1024x1024). */
    public int fill(int sx, int sy, int color, int tolerance) {
        if (!in(sx, sy)) return 0;
        int target = get(sx, sy);
        if (target == color) return 0;
        boolean[] seen = new boolean[w * h];
        int[] stack = new int[w * h];
        int sp = 0, filled = 0;
        stack[sp++] = sy * w + sx; seen[sy * w + sx] = true;
        while (sp > 0) {
            int i = stack[--sp];
            px[i] = color; filled++;
            int x = i % w, y = i / w;
            int[] nb = { x > 0 ? i - 1 : -1, x < w - 1 ? i + 1 : -1, y > 0 ? i - w : -1, y < h - 1 ? i + w : -1 };
            for (int n : nb) if (n >= 0 && !seen[n] && close(px[n], target, tolerance)) { seen[n] = true; stack[sp++] = n; }
        }
        return filled;
    }

    static boolean close(int a, int b, int tol) {
        return Math.abs(Colors.a(a) - Colors.a(b)) <= tol && Math.abs(Colors.r(a) - Colors.r(b)) <= tol && Math.abs(Colors.g(a) - Colors.g(b)) <= tol && Math.abs(Colors.b(a) - Colors.b(b)) <= tol;
    }

    public void mirrorHorizontal() { for (int y = 0; y < h; y++) for (int x = 0; x < w / 2; x++) { int a = y * w + x, b = y * w + (w - 1 - x); int t = px[a]; px[a] = px[b]; px[b] = t; } }
    public void mirrorVertical() { for (int y = 0; y < h / 2; y++) for (int x = 0; x < w; x++) { int a = y * w + x, b = (h - 1 - y) * w + x; int t = px[a]; px[a] = px[b]; px[b] = t; } }
    public void rotate90() {
        int[] out = new int[w * h];
        for (int y = 0; y < h; y++) for (int x = 0; x < w; x++) out[x * h + (h - 1 - y)] = px[y * w + x];
        int t = w; w = h; h = t; px = out;
    }
    public int replaceColor(int from, int to, int tolerance) { int n = 0; for (int i = 0; i < px.length; i++) if (close(px[i], from, tolerance)) { px[i] = to; n++; } return n; }

    public void adjustHsv(float dh, float ds, float dv) {
        for (int i = 0; i < px.length; i++) {
            int c = px[i]; if (Colors.a(c) == 0) continue;
            float[] hsv = Colors.toHsv(c);
            px[i] = Colors.fromHsv(hsv[0] + dh, hsv[1] + ds, hsv[2] + dv, Colors.a(c));
        }
    }
    public void tint(int color, double strength) { for (int i = 0; i < px.length; i++) if (Colors.a(px[i]) > 0) px[i] = Colors.withAlpha(Colors.lerp(px[i] | 0xFF000000, color | 0xFF000000, strength), Colors.a(px[i])); }
    public void contrast(double f) {
        for (int i = 0; i < px.length; i++) {
            int c = px[i];
            px[i] = Colors.argb(Colors.a(c), (int) Math.round((Colors.r(c) - 128) * f + 128), (int) Math.round((Colors.g(c) - 128) * f + 128), (int) Math.round((Colors.b(c) - 128) * f + 128));
        }
    }
    public void grayscale() { for (int i = 0; i < px.length; i++) px[i] = Colors.grayscale(px[i]); }
    public void multiplyAlpha(double f) { for (int i = 0; i < px.length; i++) px[i] = Colors.mulAlpha(px[i], f); }

    /** Most frequent opaque colours, at most {@code max}. */
    public List<Integer> palette(int max) {
        Map<Integer, Integer> freq = new HashMap<>();
        for (int c : px) if (Colors.a(c) > 0) freq.merge(c, 1, Integer::sum);
        List<Map.Entry<Integer, Integer>> e = new ArrayList<>(freq.entrySet());
        e.sort((a, b) -> b.getValue() - a.getValue() != 0 ? b.getValue() - a.getValue() : Integer.compare(a.getKey(), b.getKey()));
        List<Integer> out = new ArrayList<>();
        for (int i = 0; i < e.size() && i < max; i++) out.add(e.get(i).getKey());
        return out;
    }

    public void resize(int nw, int nh) {
        if (nw < 1 || nh < 1 || nw > MAX_SIDE || nh > MAX_SIDE) throw new IllegalArgumentException("size");
        int[] out = new int[nw * nh];
        for (int y = 0; y < nh; y++) for (int x = 0; x < nw; x++) out[y * nw + x] = px[(y * h / nh) * w + (x * w / nw)];
        w = nw; h = nh; px = out;
    }
    public void clear() { Arrays.fill(px, 0); }
}
