package dev.ancientvisuals.core.texture;

import dev.ancientvisuals.core.json.Json;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Builds resource packs from generated assets. Only writes inside the chosen folder. */
public final class PackWriter {
    public static final int PACK_FORMAT = 34; // Minecraft 1.21 / 1.21.1
    private static final Pattern PATH = Pattern.compile("[a-z0-9_.\\-/]+");
    private final Map<String, byte[]> entries = new LinkedHashMap<>();
    private final String description;

    public PackWriter(String description) { this.description = description == null ? "Ancient Visuals pack" : description; }

    public static boolean validPath(String p) { return p != null && !p.isEmpty() && PATH.matcher(p).matches() && !p.contains("..") && !p.startsWith("/") && !p.contains("//"); }

    public PackWriter put(String path, byte[] data) {
        if (!validPath(path)) throw new IllegalArgumentException("invalid resource path: " + path);
        entries.put(path, data);
        return this;
    }
    public int size() { return entries.size(); }

    public byte[] mcmeta() {
        Map<String, Object> pack = new LinkedHashMap<>();
        pack.put("pack_format", PACK_FORMAT);
        pack.put("description", description);
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("pack", pack);
        return Json.write(root, true).getBytes(StandardCharsets.UTF_8);
    }

    public static String safeFolderName(String name) {
        String s = name == null ? "pack" : name.replaceAll("[^A-Za-z0-9 _\\-]", "").trim();
        if (s.isEmpty()) s = "pack";
        return s.length() > 48 ? s.substring(0, 48) : s;
    }

    public Path writeFolder(Path resourcePacksDir, String folderName) throws IOException {
        Path root = resourcePacksDir.resolve(safeFolderName(folderName)).normalize();
        if (!root.startsWith(resourcePacksDir.normalize())) throw new IOException("bad folder");
        Files.createDirectories(root);
        Files.write(root.resolve("pack.mcmeta"), mcmeta());
        for (Map.Entry<String, byte[]> e : entries.entrySet()) {
            Path f = root.resolve(e.getKey()).normalize();
            if (!f.startsWith(root)) throw new IOException("bad path " + e.getKey());
            Files.createDirectories(f.getParent());
            Files.write(f, e.getValue());
        }
        return root;
    }

    public void writeZip(OutputStream os) throws IOException {
        try (ZipOutputStream z = new ZipOutputStream(os)) {
            z.putNextEntry(new ZipEntry("pack.mcmeta")); z.write(mcmeta()); z.closeEntry();
            for (Map.Entry<String, byte[]> e : entries.entrySet()) { z.putNextEntry(new ZipEntry(e.getKey())); z.write(e.getValue()); z.closeEntry(); }
        }
    }
}
