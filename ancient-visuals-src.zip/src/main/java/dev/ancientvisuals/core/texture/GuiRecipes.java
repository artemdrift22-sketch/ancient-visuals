package dev.ancientvisuals.core.texture;

import dev.ancientvisuals.core.theme.OrnamentStyle;
import dev.ancientvisuals.core.theme.Palette;
import dev.ancientvisuals.core.theme.Themes;
import dev.ancientvisuals.core.util.Colors;

import java.util.List;

/**
 * GUI texture pack recipes. Each recipe gradient-maps the luminance of the vanilla GUI textures onto a themed colour ramp,
 * so slot borders, shadows and highlights keep their structure (readability) while the look changes.
 */
public final class GuiRecipes {
    public record Recipe(String id, String name, String paletteId, int[] ramp, double panelAlpha, OrnamentStyle ornament, double ornamentStrength, double contrast) {
        public int map(int argb, int x, int y) {
            int a = Colors.a(argb);
            if (a == 0) return 0;
            double l = (Colors.r(argb) * 0.299 + Colors.g(argb) * 0.587 + Colors.b(argb) * 0.114) / 255.0;
            l = Math.max(0, Math.min(1, (l - 0.5) * contrast + 0.5));
            double pos = l * (ramp.length - 1);
            int i = Math.min(ramp.length - 2, (int) pos);
            int c = Colors.lerp(ramp[i], ramp[i + 1], pos - i);
            boolean panel = (argb & 0xFFFFFF) == 0xC6C6C6;
            if (panel && ornament != OrnamentStyle.NONE && ornamentStrength > 0 && pattern(x, y)) c = Colors.lerp(c, ramp[ramp.length - 1], ornamentStrength);
            if (panel && panelAlpha < 1) a = (int) Math.round(a * panelAlpha);
            return Colors.withAlpha(c, a);
        }
        boolean pattern(int x, int y) {
            return switch (ornament) {
                case MEANDER -> { int px = x % 8, py = y % 8; yield (py == 0 && px < 7) || (px == 6 && py < 6) || (py == 5 && px >= 2 && px <= 6) || (px == 2 && py >= 2 && py <= 5) || (py == 2 && px >= 2 && px <= 4); }
                case WAVES -> Math.floorMod(y - (int) Math.round(Math.sin(x * 0.7) * 1.5), 6) == 0;
                case DOTS, RIVETS -> x % 6 == 0 && y % 6 == 0;
                case MOSAIC -> ((x / 3) + (y / 3)) % 2 == 0;
                case COLUMNS -> x % 10 == 0 || x % 10 == 1;
                case LAUREL -> Math.floorMod(x + y, 7) == 0 && y % 2 == 0;
                case RAYS -> Math.floorMod(x - y, 9) == 0;
                case SCROLL -> (x * x + y * 3) % 11 == 0;
                default -> false;
            };
        }
    }

    private static int[] ramp(String paletteId) {
        Palette p = Themes.palette(paletteId);
        return new int[] { Colors.darken(p.background(), 0.55), p.background(), p.surfaceAlt(), p.surface(), Colors.lighten(p.surface(), 0.35) };
    }
    private static Recipe r(String id, String name, String pal, double alpha, OrnamentStyle o, double os, double contrast) { return new Recipe(id, name, pal, ramp(pal), alpha, o, os, contrast); }

    public static final List<Recipe> ALL = List.of(
        r("olympus_marble_inventory", "Olympus Marble Inventory", "athena_marble", 1.0, OrnamentStyle.MEANDER, 0.12, 1.0),
        r("azure_transparent", "Azure Transparent", "olympus_azure", 0.78, OrnamentStyle.NONE, 0, 1.05),
        r("athena_tactical", "Athena Tactical", "arena_clarity", 1.0, OrnamentStyle.NONE, 0, 1.25),
        r("poseidon_waves", "Poseidon Waves", "poseidon_tides", 1.0, OrnamentStyle.WAVES, 0.14, 1.0),
        r("apollo_sunlit", "Apollo Sunlit", "apollo_radiance", 1.0, OrnamentStyle.RAYS, 0.10, 1.0),
        r("classic_vanilla_plus", "Classic Vanilla+", "transparent_vanilla", 1.0, OrnamentStyle.NONE, 0, 1.1),
        r("pixel_meander", "Pixel Meander", "marble_cobalt", 1.0, OrnamentStyle.MEANDER, 0.22, 1.0),
        r("marble_minimal", "Marble Minimal", "classical_white", 1.0, OrnamentStyle.NONE, 0, 0.95),
        r("divine_relics", "Divine Relics", "divine_gold", 1.0, OrnamentStyle.LAUREL, 0.15, 1.05),
        r("arena_clarity", "Arena Clarity", "arena_clarity", 1.0, OrnamentStyle.NONE, 0, 1.35),
        r("soft_transparent", "Soft Transparent", "azure_minimal", 0.7, OrnamentStyle.NONE, 0, 0.9),
        r("cobalt_contrast", "Cobalt Contrast", "zeus_storm", 1.0, OrnamentStyle.NONE, 0, 1.4),
        r("inventory_ornamental", "Inventory Ornamental", "aegean_mosaic", 1.0, OrnamentStyle.MOSAIC, 0.12, 1.0),
        r("dark_classical", "Dark Classical", "hades_obsidian", 1.0, OrnamentStyle.COLUMNS, 0.10, 1.1),
        r("high_visibility", "High Visibility", "arena_clarity", 1.0, OrnamentStyle.NONE, 0, 1.6),
        r("custom_gui_pack", "Custom GUI Pack", "user_custom", 1.0, OrnamentStyle.DOTS, 0.08, 1.0)
    );

    /** Vanilla container textures that recipes recolour (still plain textures in 1.21.1). */
    public static final List<String> TARGETS = List.of(
        "textures/gui/container/inventory.png", "textures/gui/container/generic_54.png", "textures/gui/container/crafting_table.png",
        "textures/gui/container/furnace.png", "textures/gui/container/blast_furnace.png", "textures/gui/container/smoker.png",
        "textures/gui/container/shulker_box.png", "textures/gui/container/dispenser.png", "textures/gui/container/hopper.png",
        "textures/gui/container/anvil.png", "textures/gui/container/enchanting_table.png", "textures/gui/container/brewing_stand.png",
        "textures/gui/container/beacon.png", "textures/gui/container/grindstone.png", "textures/gui/container/smithing.png",
        "textures/gui/container/stonecutter.png", "textures/gui/container/loom.png", "textures/gui/container/cartography_table.png",
        "textures/gui/container/villager.png", "textures/gui/container/horse.png", "textures/gui/container/crafter.png");

    public static Recipe get(String id) { for (Recipe r : ALL) if (r.id().equals(id)) return r; return null; }

    public static PixelCanvas apply(Recipe r, PixelCanvas src) {
        PixelCanvas out = src.copy();
        for (int y = 0; y < out.height(); y++) for (int x = 0; x < out.width(); x++) out.set(x, y, r.map(src.get(x, y), x, y));
        return out;
    }
}
