package dev.ancientvisuals.core.texture;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Safe PNG import/export (size limited, never executes anything). */
public final class PngIO {
    public static final int MAX_BYTES = 4 * 1024 * 1024;
    private PngIO() {}

    public static PixelCanvas read(byte[] data) throws IOException {
        if (data == null || data.length == 0) throw new IOException("empty file");
        if (data.length > MAX_BYTES) throw new IOException("file is larger than 4 MB");
        if (data.length < 8 || (data[0] & 0xFF) != 0x89 || data[1] != 'P' || data[2] != 'N' || data[3] != 'G') throw new IOException("not a PNG file");
        BufferedImage img = ImageIO.read(new ByteArrayInputStream(data));
        if (img == null) throw new IOException("unreadable PNG");
        if (img.getWidth() > PixelCanvas.MAX_SIDE || img.getHeight() > PixelCanvas.MAX_SIDE) throw new IOException("image larger than 1024x1024");
        PixelCanvas c = new PixelCanvas(img.getWidth(), img.getHeight());
        for (int y = 0; y < img.getHeight(); y++) for (int x = 0; x < img.getWidth(); x++) c.set(x, y, img.getRGB(x, y));
        return c;
    }
    public static PixelCanvas read(Path p) throws IOException {
        if (Files.size(p) > MAX_BYTES) throw new IOException("file is larger than 4 MB");
        return read(Files.readAllBytes(p));
    }
    public static byte[] encode(PixelCanvas c) throws IOException {
        BufferedImage img = new BufferedImage(c.width(), c.height(), BufferedImage.TYPE_INT_ARGB);
        for (int y = 0; y < c.height(); y++) for (int x = 0; x < c.width(); x++) img.setRGB(x, y, c.get(x, y));
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        if (!ImageIO.write(img, "png", out)) throw new IOException("no PNG writer");
        return out.toByteArray();
    }
    public static void write(PixelCanvas c, Path p) throws IOException { Files.createDirectories(p.toAbsolutePath().getParent()); Files.write(p, encode(c)); }
}
