package dev.ancientvisuals.core.texture;

import dev.ancientvisuals.core.theme.CornerStyle;
import dev.ancientvisuals.core.theme.OrnamentStyle;

import java.util.ArrayList;
import java.util.List;

/** Visual skin for HUD element containers. */
public record HudSkin(String id, String name, Bg bg, CornerStyle corner, int radius, OrnamentStyle ornament, int background, int border, int accent,
                      int text, int label, boolean shadow, int padding, Bar bar) {
    public enum Bg { NONE, PLATE, STRIP, BADGE, GLASS_LITE }
    public enum Bar { FLAT, SEGMENTED, GRADIENT, OUTLINE, BEADS }

    public static final List<HudSkin> ALL = List.of(
        new HudSkin("olympus_azure", "Olympus Azure", Bg.PLATE, CornerStyle.CHAMFER, 3, OrnamentStyle.MEANDER, 0xB0142A55, 0xFF2F6FD6, 0xFFD4A537, 0xFFF4F1EA, 0xFF9DB7E8, true, 4, Bar.GRADIENT),
        new HudSkin("athena_precision", "Athena Precision", Bg.STRIP, CornerStyle.SQUARE, 0, OrnamentStyle.NONE, 0x90101820, 0xFFF4F1EA, 0xFF6FA8FF, 0xFFFFFFFF, 0xFFB9C6D6, true, 3, Bar.SEGMENTED),
        new HudSkin("poseidon_flow", "Poseidon Flow", Bg.PLATE, CornerStyle.ROUNDED, 4, OrnamentStyle.WAVES, 0xA0062A3A, 0xFF2BA3C9, 0xFF8FE3F2, 0xFFE8FBFF, 0xFF8CC7D6, true, 4, Bar.GRADIENT),
        new HudSkin("apollo_radiance", "Apollo Radiance", Bg.BADGE, CornerStyle.PILL, 6, OrnamentStyle.RAYS, 0xA03A2A08, 0xFFE0A21B, 0xFFFFE08A, 0xFFFFF7E0, 0xFFE8D29A, true, 4, Bar.GRADIENT),
        new HudSkin("marble_classic", "Marble Classic", Bg.PLATE, CornerStyle.STEPPED, 2, OrnamentStyle.COLUMNS, 0xD0EDE9E0, 0xFFB9B9B4, 0xFF1D3F8F, 0xFF1A1E26, 0xFF5A6070, false, 4, Bar.FLAT),
        new HudSkin("arena_minimal", "Arena Minimal", Bg.NONE, CornerStyle.SQUARE, 0, OrnamentStyle.NONE, 0x00000000, 0x00000000, 0xFF55C2FF, 0xFFFFFFFF, 0xFFC8D0DA, true, 1, Bar.FLAT),
        new HudSkin("vanilla_refined", "Vanilla Refined", Bg.PLATE, CornerStyle.SQUARE, 0, OrnamentStyle.NONE, 0x80000000, 0x00000000, 0xFFFFFF55, 0xFFFFFFFF, 0xFFAAAAAA, true, 3, Bar.FLAT),
        new HudSkin("transparent_combat", "Transparent Combat", Bg.GLASS_LITE, CornerStyle.ROUNDED, 3, OrnamentStyle.NONE, 0x50101418, 0x40FFFFFF, 0xFFFF5A5A, 0xFFFFFFFF, 0xFFCFD6DE, true, 3, Bar.OUTLINE),
        new HudSkin("mythic_relics", "Mythic Relics", Bg.BADGE, CornerStyle.NOTCHED, 3, OrnamentStyle.LAUREL, 0xB0221A0E, 0xFFD4A537, 0xFF8FD3A0, 0xFFF6EAD0, 0xFFC9B48A, true, 4, Bar.BEADS),
        new HudSkin("high_contrast", "High Contrast", Bg.PLATE, CornerStyle.SQUARE, 0, OrnamentStyle.NONE, 0xF0000000, 0xFFFFFFFF, 0xFFFFE600, 0xFFFFFFFF, 0xFFFFFFFF, false, 4, Bar.OUTLINE),
        new HudSkin("pixel_meander", "Pixel Meander", Bg.STRIP, CornerStyle.SQUARE, 0, OrnamentStyle.MEANDER, 0xB01D3F8F, 0xFFF4F1EA, 0xFFD4A537, 0xFFFFFFFF, 0xFFBFD0F0, true, 3, Bar.SEGMENTED),
        new HudSkin("divine_geometry", "Divine Geometry", Bg.PLATE, CornerStyle.CHAMFER, 4, OrnamentStyle.MOSAIC, 0xA0161230, 0xFF8A5BFF, 0xFFD4A537, 0xFFF0ECFF, 0xFFB5A8E0, true, 4, Bar.BEADS),
        new HudSkin("cobalt_compact", "Cobalt Compact", Bg.STRIP, CornerStyle.TAB, 2, OrnamentStyle.NONE, 0xC0102654, 0xFF2F6FD6, 0xFF7FB0FF, 0xFFFFFFFF, 0xFF9FB6E0, false, 2, Bar.FLAT),
        new HudSkin("classical_white", "Classical White", Bg.PLATE, CornerStyle.ROUNDED, 3, OrnamentStyle.DOTS, 0xE0F7F5EF, 0xFFD8D2C4, 0xFF2F6FD6, 0xFF20242C, 0xFF6A7080, false, 4, Bar.GRADIENT),
        new HudSkin("user_hud", "User HUD", Bg.PLATE, CornerStyle.ROUNDED, 3, OrnamentStyle.NONE, 0xA0101828, 0xFF2F6FD6, 0xFFD4A537, 0xFFFFFFFF, 0xFFB0B8C8, true, 4, Bar.FLAT)
    );

    public static HudSkin get(String id) { for (HudSkin s : ALL) if (s.id().equals(id)) return s; return ALL.get(0); }
    public static List<String> ids() { List<String> l = new ArrayList<>(); for (HudSkin s : ALL) l.add(s.id()); return l; }
}
