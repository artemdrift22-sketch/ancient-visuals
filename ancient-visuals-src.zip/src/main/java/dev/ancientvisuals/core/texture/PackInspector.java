package dev.ancientvisuals.core.texture;

import dev.ancientvisuals.core.json.Json;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Reads resource packs (zip or folder) without extracting them and reports problems. */
public final class PackInspector {
    public static final int MAX_ENTRIES = 20000;
    public static final long MAX_TOTAL = 512L * 1024 * 1024;
    public static final int MAX_MCMETA = 64 * 1024;

    public static final class Report {
        public String name, description = "", sha256 = "";
        public int packFormat = -1;
        public boolean zip;
        public long totalBytes;
        public final Map<String, Integer> counts = new TreeMap<>();
        public final TreeSet<String> assets = new TreeSet<>();
        public final List<String> warnings = new ArrayList<>(), errors = new ArrayList<>();
        public boolean ok() { return errors.isEmpty(); }
        public boolean formatMismatch() { return packFormat > 0 && packFormat != PackWriter.PACK_FORMAT; }
    }

    private PackInspector() {}

    public static boolean unsafeEntry(String n) { return n.contains("..") || n.startsWith("/") || n.startsWith("\\") || n.contains(":") || n.contains("\\"); }

    public static String category(String path) {
        String p = path.toLowerCase();
        if (!p.startsWith("assets/")) return p.startsWith("data/") ? "data" : "other";
        if (p.contains("/textures/gui/")) return "gui";
        if (p.contains("/textures/item/")) return "items";
        if (p.contains("/textures/block/")) return "blocks";
        if (p.contains("/textures/entity/")) return "entities";
        if (p.contains("/textures/particle/")) return "particles";
        if (p.contains("/textures/environment/")) return "sky";
        if (p.contains("/textures/")) return "textures";
        if (p.contains("/models/")) return "models";
        if (p.contains("/sounds")) return "sounds";
        if (p.contains("/lang/")) return "lang";
        if (p.contains("/shaders/")) return "shaders";
        if (p.contains("/font/")) return "fonts";
        return "other";
    }

    public static Report inspectZip(String name, InputStream in) throws IOException {
        Report r = new Report(); r.name = name; r.zip = true;
        MessageDigest md;
        try { md = MessageDigest.getInstance("SHA-256"); } catch (Exception e) { throw new IOException(e); }
        int count = 0;
        byte[] buf = new byte[16384];
        try (ZipInputStream z = new ZipInputStream(new java.security.DigestInputStream(in, md))) {
            ZipEntry e;
            while ((e = z.getNextEntry()) != null) {
                if (++count > MAX_ENTRIES) { r.errors.add("too many entries (> " + MAX_ENTRIES + ")"); break; }
                String n = e.getName();
                if (unsafeEntry(n)) { r.errors.add("unsafe entry path: " + n); continue; }
                if (e.isDirectory()) continue;
                long size = 0; byte[] meta = null;
                boolean isMeta = n.equals("pack.mcmeta");
                java.io.ByteArrayOutputStream mo = isMeta ? new java.io.ByteArrayOutputStream() : null;
                int k;
                while ((k = z.read(buf)) > 0) {
                    size += k; r.totalBytes += k;
                    if (r.totalBytes > MAX_TOTAL) { r.errors.add("pack is larger than 512 MB uncompressed"); return finish(r, md); }
                    if (mo != null && mo.size() < MAX_MCMETA) mo.write(buf, 0, Math.min(k, MAX_MCMETA - mo.size()));
                }
                if (mo != null) meta = mo.toByteArray();
                if (isMeta) readMeta(r, meta); else record(r, n);
            }
        }
        return finish(r, md);
    }

    private static Report finish(Report r, MessageDigest md) {
        r.sha256 = HexFormat.of().formatHex(md.digest());
        if (r.packFormat < 0 && r.errors.isEmpty()) r.errors.add("pack.mcmeta is missing or invalid");
        if (r.formatMismatch()) r.warnings.add("pack_format " + r.packFormat + " (Minecraft 1.21.1 expects " + PackWriter.PACK_FORMAT + ")");
        if (r.assets.isEmpty() && r.errors.isEmpty()) r.warnings.add("pack contains no assets");
        if (r.counts.getOrDefault("shaders", 0) > 0) r.warnings.add("core shaders override may conflict with shader mods");
        return r;
    }

    public static Report inspectFolder(Path dir) throws IOException {
        Report r = new Report(); r.name = dir.getFileName().toString(); r.zip = false;
        Path meta = dir.resolve("pack.mcmeta");
        if (Files.isRegularFile(meta) && Files.size(meta) <= MAX_MCMETA) readMeta(r, Files.readAllBytes(meta));
        int[] count = { 0 };
        try (Stream<Path> s = Files.walk(dir, 16)) {
            s.filter(Files::isRegularFile).limit(MAX_ENTRIES + 1L).forEach(p -> {
                if (++count[0] > MAX_ENTRIES) return;
                String rel = dir.relativize(p).toString().replace('\\', '/');
                try { r.totalBytes += Files.size(p); } catch (IOException ignored) {}
                if (!rel.equals("pack.mcmeta")) record(r, rel);
            });
        }
        if (count[0] > MAX_ENTRIES) r.errors.add("too many files (> " + MAX_ENTRIES + ")");
        r.sha256 = "folder";
        if (r.packFormat < 0) r.errors.add("pack.mcmeta is missing or invalid");
        if (r.formatMismatch()) r.warnings.add("pack_format " + r.packFormat + " (Minecraft 1.21.1 expects " + PackWriter.PACK_FORMAT + ")");
        return r;
    }

    static void record(Report r, String n) { if (n.startsWith("assets/")) r.assets.add(n); r.counts.merge(category(n), 1, Integer::sum); }

    static void readMeta(Report r, byte[] meta) {
        try {
            Map<String, Object> root = Json.parseObject(new String(meta, StandardCharsets.UTF_8));
            Map<String, Object> pack = Json.obj(root, "pack");
            if (pack == null) { r.errors.add("pack.mcmeta has no 'pack' object"); return; }
            r.packFormat = Json.integer(pack, "pack_format", -1);
            Object d = pack.get("description");
            r.description = d instanceof String s ? s : d == null ? "" : "(formatted text)";
        } catch (RuntimeException e) { r.errors.add("pack.mcmeta is not valid JSON"); }
    }

    /** Asset path -> names of packs that provide it (only paths provided by 2+ packs). Order = priority. */
    public static Map<String, List<String>> conflicts(List<Report> reports) {
        Map<String, List<String>> all = new TreeMap<>();
        for (Report r : reports) for (String a : r.assets) all.computeIfAbsent(a, k -> new ArrayList<>()).add(r.name);
        Map<String, List<String>> out = new LinkedHashMap<>();
        for (Map.Entry<String, List<String>> e : all.entrySet()) if (e.getValue().size() > 1) out.put(e.getKey(), e.getValue());
        return out;
    }
}
