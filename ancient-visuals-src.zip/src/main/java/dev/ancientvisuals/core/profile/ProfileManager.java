package dev.ancientvisuals.core.profile;

import dev.ancientvisuals.core.diag.Diagnostics;
import dev.ancientvisuals.core.io.ImportValidator;
import dev.ancientvisuals.core.json.Json;
import dev.ancientvisuals.core.module.Module;
import dev.ancientvisuals.core.module.ModuleRegistry;
import dev.ancientvisuals.core.setting.ActionSetting;
import dev.ancientvisuals.core.setting.Setting;
import dev.ancientvisuals.core.setting.SettingEvents;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

/** Named snapshots of all module states + extra sections. */
public final class ProfileManager {
    private final ModuleRegistry registry;
    private final Map<String, SectionCodec> sections = new LinkedHashMap<>();
    private final Map<String, Profile> profiles = new LinkedHashMap<>();
    private String active;
    private String defaultId = "olympus_default";

    public ProfileManager(ModuleRegistry registry) { this.registry = registry; }

    public void addSection(String name, SectionCodec codec) { sections.put(name, codec); }
    public List<Profile> all() { return new ArrayList<>(profiles.values()); }
    public Profile get(String id) { return profiles.get(id); }
    public Profile active() { return profiles.get(active); }
    public String activeId() { return active; }
    public String defaultId() { return defaultId; }

    // ------------------------------------------------------------ capture / apply
    public Map<String, Object> capture() {
        Map<String, Object> mods = new LinkedHashMap<>();
        for (Module m : registry.all()) {
            Map<String, Object> md = new LinkedHashMap<>();
            md.put("enabled", m.isEnabled());
            Map<String, Object> st = new LinkedHashMap<>();
            for (Setting<?> s : m.settings()) if (!(s instanceof ActionSetting)) st.put(s.id(), s.toJson());
            st.put("toggle_key", m.toggleKey().toJson());
            md.put("settings", st);
            mods.put(m.id(), md);
        }
        Map<String, Object> sec = new LinkedHashMap<>();
        for (Map.Entry<String, SectionCodec> e : sections.entrySet()) {
            try { sec.put(e.getKey(), e.getValue().save()); } catch (RuntimeException ex) { Diagnostics.error("profile", "section save " + e.getKey(), ex); }
        }
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("modules", mods);
        data.put("sections", sec);
        return data;
    }

    /** Applies data on top of defaults. Invalid values are skipped with a warning and never wipe other settings. */
    public List<String> apply(Map<String, Object> data) {
        List<String> warnings = new ArrayList<>();
        SettingEvents.mute(() -> {
            Map<String, Object> mods = Json.obj(data, "modules");
            for (Module m : registry.all()) {
                for (Setting<?> s : m.settings()) s.reset();
                m.toggleKey().reset();
                Map<String, Object> md = mods == null ? null : Json.obj(mods, m.id());
                boolean en = md == null ? m.enabledByDefault() : Json.bool(md, "enabled", m.enabledByDefault());
                Map<String, Object> st = Json.obj(md, "settings");
                if (st != null) for (Map.Entry<String, Object> e : st.entrySet()) {
                    Setting<?> s = m.setting(e.getKey());
                    if (s == null) { warnings.add("unknown setting " + m.id() + "." + e.getKey()); continue; }
                    boolean ok = e.getValue() instanceof String str && !(s.toJson() instanceof String) ? s.parse(str) : s.fromJson(e.getValue());
                    if (!ok) warnings.add("invalid value for " + m.id() + "." + e.getKey());
                }
                ModuleRegistry.setSilently(m, en && !(registry.safeMode() && m.heavy()));
            }
            if (mods != null) for (String k : mods.keySet()) if (registry.get(k) == null) warnings.add("unknown module " + k);
            Map<String, Object> sec = Json.obj(data, "sections");
            for (Map.Entry<String, SectionCodec> e : sections.entrySet()) {
                try {
                    Object v = sec == null ? null : sec.get(e.getKey());
                    if (v == null) e.getValue().reset(); else e.getValue().load(v);
                } catch (RuntimeException ex) { warnings.add("section " + e.getKey() + " failed: " + ex.getMessage()); e.getValue().reset(); }
            }
        });
        for (String w : warnings) Diagnostics.warn("profile", w);
        return warnings;
    }

    /** Builds data for a preset by applying its overrides to defaults (restores the live state afterwards). */
    public Map<String, Object> buildPreset(ProfilePresets.Preset p) {
        Map<String, Object> live = capture();
        apply(new LinkedHashMap<>());
        Map<String, Map<String, Object>> ov = ProfilePresets.parse(p.overrides());
        SettingEvents.mute(() -> {
            for (Map.Entry<String, Map<String, Object>> e : ov.entrySet()) {
                Module m = registry.get(e.getKey());
                if (m == null) { Diagnostics.warn("profile", "preset " + p.id() + ": unknown module " + e.getKey()); continue; }
                Object en = e.getValue().get("enabled");
                if (en instanceof Boolean b) ModuleRegistry.setSilently(m, b);
                Map<String, Object> st = Json.obj(e.getValue(), "settings");
                if (st != null) for (Map.Entry<String, Object> se : st.entrySet()) {
                    Setting<?> s = m.setting(se.getKey());
                    if (s == null || !s.parse(String.valueOf(se.getValue()))) Diagnostics.warn("profile", "preset " + p.id() + ": bad " + e.getKey() + "." + se.getKey());
                }
            }
        });
        Map<String, Object> result = capture();
        apply(live);
        return result;
    }

    /** Loads profiles from the config root; missing built-ins are generated. */
    public void load(Map<String, Object> root) {
        profiles.clear();
        Map<String, Object> ps = Json.obj(root, "profiles");
        if (ps != null) for (Map.Entry<String, Object> e : ps.entrySet()) {
            if (!(e.getValue() instanceof Map)) continue;
            @SuppressWarnings("unchecked") Map<String, Object> pm = (Map<String, Object>) e.getValue();
            boolean builtin = ProfilePresets.get(e.getKey()) != null;
            profiles.put(e.getKey(), new Profile(e.getKey(), Json.str(pm, "name", e.getKey()), builtin, Json.obj(pm, "data")));
        }
        for (ProfilePresets.Preset p : ProfilePresets.ALL) if (!profiles.containsKey(p.id())) profiles.put(p.id(), new Profile(p.id(), p.name(), true, buildPreset(p)));
        defaultId = Json.str(root, "defaultProfile", "olympus_default");
        if (!profiles.containsKey(defaultId)) defaultId = "olympus_default";
        String want = Json.str(root, "activeProfile", defaultId);
        active = profiles.containsKey(want) ? want : defaultId;
        apply(profiles.get(active).data);
    }

    public Map<String, Object> save() {
        Profile a = active();
        if (a != null) a.data = capture();
        Map<String, Object> ps = new LinkedHashMap<>();
        for (Profile p : profiles.values()) {
            Map<String, Object> pm = new LinkedHashMap<>();
            pm.put("name", p.name);
            pm.put("data", p.data);
            ps.put(p.id, pm);
        }
        Map<String, Object> root = new LinkedHashMap<>();
        root.put("activeProfile", active);
        root.put("defaultProfile", defaultId);
        root.put("profiles", ps);
        return root;
    }

    // ------------------------------------------------------------ operations
    public List<String> switchTo(String id) {
        Profile target = profiles.get(id);
        if (target == null) throw new IllegalArgumentException("no profile " + id);
        Profile cur = active();
        if (cur != null) cur.data = capture();
        active = id;
        Diagnostics.info("profile", "switched to " + target.name);
        return apply(target.data);
    }

    public Profile create(String name) { return put(uniqueId(name), name, capture()); }
    public Profile duplicate(String id) {
        Profile src = profiles.get(id);
        if (src == null) return null;
        Map<String, Object> data = id.equals(active) ? capture() : Json.deepCopy(src.data);
        String n = src.name + " (copy)";
        return put(uniqueId(n), n, data);
    }
    public boolean rename(String id, String name) {
        Profile p = profiles.get(id);
        if (p == null || name == null || name.isBlank() || name.length() > 64) return false;
        p.name = name.trim();
        return true;
    }
    /** Built-in profiles cannot be deleted (they can be restored instead); the active one switches to default first. */
    public boolean delete(String id) {
        Profile p = profiles.get(id);
        if (p == null || p.builtin) return false;
        if (id.equals(active)) switchTo(defaultId.equals(id) ? "olympus_default" : defaultId);
        if (id.equals(defaultId)) defaultId = "olympus_default";
        profiles.remove(id);
        return true;
    }
    public boolean setDefault(String id) { if (!profiles.containsKey(id)) return false; defaultId = id; return true; }
    /** Restores a built-in profile to its shipped preset. */
    public boolean restoreBuiltin(String id) {
        ProfilePresets.Preset pr = ProfilePresets.get(id);
        if (pr == null) return false;
        Profile p = profiles.get(id);
        p.data = buildPreset(pr);
        if (id.equals(active)) apply(p.data);
        return true;
    }

    /** Human-readable list of differences between two profiles ("module.setting: a -> b"). */
    public List<String> compare(String a, String b) {
        Map<String, Object> da = a.equals(active) ? capture() : profiles.get(a).data;
        Map<String, Object> db = b.equals(active) ? capture() : profiles.get(b).data;
        Map<String, String> fa = new LinkedHashMap<>(), fb = new LinkedHashMap<>();
        flatten("", Json.obj(da, "modules"), fa);
        flatten("", Json.obj(db, "modules"), fb);
        List<String> out = new ArrayList<>();
        for (Map.Entry<String, String> e : fa.entrySet()) {
            String other = fb.get(e.getKey());
            if (!Objects.equals(e.getValue(), other)) out.add(e.getKey().replace(".settings.", ".") + ": " + e.getValue() + " -> " + (other == null ? "(default)" : other));
        }
        for (Map.Entry<String, String> e : fb.entrySet()) if (!fa.containsKey(e.getKey())) out.add(e.getKey().replace(".settings.", ".") + ": (default) -> " + e.getValue());
        return out;
    }
    /** Differences between the active profile's saved data and the live state. */
    public List<String> unsavedChanges() {
        Map<String, String> fa = new LinkedHashMap<>(), fb = new LinkedHashMap<>();
        flatten("", Json.obj(active().data, "modules"), fa);
        flatten("", Json.obj(capture(), "modules"), fb);
        List<String> out = new ArrayList<>();
        for (Map.Entry<String, String> e : fb.entrySet()) if (!Objects.equals(fa.get(e.getKey()), e.getValue())) out.add(e.getKey().replace(".settings.", ".") + " = " + e.getValue());
        return out;
    }

    private static void flatten(String prefix, Map<String, Object> m, Map<String, String> out) {
        if (m == null) return;
        for (Map.Entry<String, Object> e : m.entrySet()) {
            String k = prefix.isEmpty() ? e.getKey() : prefix + "." + e.getKey();
            if (e.getValue() instanceof Map) { @SuppressWarnings("unchecked") Map<String, Object> sub = (Map<String, Object>) e.getValue(); flatten(k, sub, out); }
            else out.put(k, Json.write(e.getValue(), false));
        }
    }

    public String exportProfile(String id) {
        Profile p = profiles.get(id);
        Map<String, Object> data = id.equals(active) ? capture() : p.data;
        return Json.write(ImportValidator.envelope("ancientvisuals.profile", p.name, data), true);
    }

    public ImportValidator.Result importProfile(String text) {
        ImportValidator.Result r = ImportValidator.parse(text, "ancientvisuals.profile");
        if (!r.ok()) return r;
        Map<String, Object> data = Json.obj(r.data, "data");
        if (Json.obj(data, "modules") == null) { r.errors.add("profile has no 'modules'"); return r; }
        Map<String, Object> mods = Json.obj(data, "modules");
        for (String k : mods.keySet()) if (registry.get(k) == null) r.warnings.add("unknown module ignored: " + k);
        String name = Json.str(r.data, "name", "Imported");
        put(uniqueId(name), name.isBlank() ? "Imported" : name, Json.deepCopy(data));
        return r;
    }

    private Profile put(String id, String name, Map<String, Object> data) { Profile p = new Profile(id, name, false, data); profiles.put(id, p); return p; }

    String uniqueId(String name) {
        String base = name == null ? "profile" : name.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]+", "_").replaceAll("^_+|_+$", "");
        if (base.isEmpty()) base = "profile";
        if (base.length() > 40) base = base.substring(0, 40);
        String id = base;
        for (int i = 2; profiles.containsKey(id); i++) id = base + "_" + i;
        return id;
    }
}
