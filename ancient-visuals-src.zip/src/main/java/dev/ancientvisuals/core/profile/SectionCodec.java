package dev.ancientvisuals.core.profile;

/** Non-module state stored inside a profile (HUD layout, favourites, particle overrides...). */
public interface SectionCodec {
    Object save();
    void load(Object data);
    void reset();
}
