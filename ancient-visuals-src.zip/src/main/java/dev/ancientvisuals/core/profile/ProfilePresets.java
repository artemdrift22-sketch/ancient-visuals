package dev.ancientvisuals.core.profile;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The 12 built-in profiles as override lists on top of defaults.
 * DSL: "+module" enables, "-module" disables, "module.setting=value" sets a value.
 */
public final class ProfilePresets {
    private ProfilePresets() {}

    public record Preset(String id, String name, String description, List<String> overrides) {}

    public static final List<Preset> ALL = List.of(
        new Preset("olympus_default", "Olympus Default", "Balanced azure-marble look, moderate particles.", List.of()),
        new Preset("athena_clarity", "Athena Clarity", "Clean readable UI, precise crosshair, fewer effects.", List.of(
            "theme.shell=athena", "theme.palette=athena_marble", "crosshair.style=PRECISION_BRACKETS", "-trails",
            "particles.intensity=0.6", "+hud_armor", "+hud_potions", "hud.skin=athena_precision")),
        new Preset("arena_minimal", "Arena Minimal", "Minimal clutter for PvP practice. Visual only - no gameplay automation.", List.of(
            "theme.shell=arena", "theme.palette=arena_clarity", "-trails", "-companion", "-ambient_particles", "particles.intensity=0.4",
            "+hud_cps", "+hud_keystrokes", "+hud_armor", "crosshair.style=TINY_DOT", "hit_fx.hitmarker=true", "hud.skin=arena_minimal")),
        new Preset("survival_journey", "Survival Journey", "Exploration info: biome, time, armour, hunger.", List.of(
            "+hud_biome", "+hud_world_time", "+hud_armor", "+hud_compass", "+hud_warnings", "+ambient_particles", "world_fog.preset=MYTHIC_FOREST")),
        new Preset("boss_encounter", "Boss Encounter", "Target info, warnings and effect timers up front.", List.of(
            "+hud_target", "+hud_warnings", "+hud_potions", "+hud_totems", "particles.intensity=0.7", "-companion")),
        new Preset("creative_showcase", "Creative Showcase", "Everything pretty: companion, trails, rich particles.", List.of(
            "+companion", "+trails", "+ambient_particles", "particles.intensity=1.0", "particles.quality=HIGH", "theme.shell=divine_artifact")),
        new Preset("screenshot_mode", "Screenshot Mode", "Hides HUD overlays and the custom crosshair.", List.of(
            "hud.hide_all=true", "-crosshair", "-trails", "world_fog.preset=APOLLO_SKY")),
        new Preset("low_performance", "Low Performance", "For weak PCs: minimum particles, no companion, adaptive quality.", List.of(
            "particles.quality=LOW", "particles.intensity=0.3", "-trails", "-companion", "-ambient_particles", "performance.adaptive=true",
            "theme.animations=false")),
        new Preset("balanced", "Balanced", "Target profile for i3-10100F / GTX 1660 Super class hardware.", List.of(
            "particles.quality=BALANCED", "performance.adaptive=true")),
        new Preset("high_visual", "High Visual Quality", "More particles, trails and companion; for strong PCs.", List.of(
            "particles.quality=HIGH", "particles.intensity=1.0", "+trails", "+companion", "+ambient_particles")),
        new Preset("transparent_vanilla", "Transparent Vanilla+", "Close to vanilla, light transparent panels.", List.of(
            "theme.shell=transparent_classic", "theme.palette=transparent_vanilla", "hud.skin=transparent_combat", "-trails", "crosshair.style=CLASSIC_PLUS")),
        new Preset("user_profile", "User Profile", "Your own starting point.", List.of())
    );

    public static Preset get(String id) { for (Preset p : ALL) if (p.id().equals(id)) return p; return null; }

    /** Parses the DSL into {module -> {"enabled": bool, "settings": {id: string}}}. */
    public static Map<String, Map<String, Object>> parse(List<String> overrides) {
        Map<String, Map<String, Object>> out = new LinkedHashMap<>();
        for (String o : overrides) {
            String s = o.trim();
            if (s.startsWith("+") || s.startsWith("-")) {
                out.computeIfAbsent(s.substring(1), k -> new LinkedHashMap<>()).put("enabled", s.startsWith("+"));
            } else {
                int dot = s.indexOf('.'), eq = s.indexOf('=');
                if (dot <= 0 || eq <= dot) throw new IllegalArgumentException("bad preset entry: " + o);
                String mod = s.substring(0, dot), set = s.substring(dot + 1, eq), val = s.substring(eq + 1);
                @SuppressWarnings("unchecked")
                Map<String, Object> settings = (Map<String, Object>) out.computeIfAbsent(mod, k -> new LinkedHashMap<>()).computeIfAbsent("settings", k -> new LinkedHashMap<String, Object>());
                settings.put(set, val);
            }
        }
        return out;
    }
}
