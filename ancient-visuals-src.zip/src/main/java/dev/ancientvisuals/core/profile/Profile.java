package dev.ancientvisuals.core.profile;

import java.util.LinkedHashMap;
import java.util.Map;

public final class Profile {
    public final String id;
    public String name;
    public final boolean builtin;
    public Map<String, Object> data;
    public Profile(String id, String name, boolean builtin, Map<String, Object> data) {
        this.id = id; this.name = name; this.builtin = builtin; this.data = data == null ? new LinkedHashMap<>() : data;
    }
}
