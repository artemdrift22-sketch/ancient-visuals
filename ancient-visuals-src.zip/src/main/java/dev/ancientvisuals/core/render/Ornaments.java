package dev.ancientvisuals.core.render;

import dev.ancientvisuals.core.theme.OrnamentStyle;

import java.util.ArrayList;
import java.util.List;

/** Procedural ornament bands drawn inside components (headers, dividers) - never as frames around everything. */
public final class Ornaments {
    private Ornaments() {}

    private static final String[] MEANDER = {
        "#####.",
        "....#.",
        "###.#.",
        "#...#.",
        "#####." };
    private static final String[] SCROLL = {
        ".###..",
        "#...#.",
        "#.#.#.",
        "#..#..",
        ".#...." };

    public static List<Rect> band(OrnamentStyle style, int x, int y, int w, int h) {
        List<Rect> out = new ArrayList<>();
        if (w <= 0 || h <= 0 || style == OrnamentStyle.NONE) return out;
        switch (style) {
            case MEANDER -> bitmap(MEANDER, x, y, w, h, out);
            case SCROLL -> bitmap(SCROLL, x, y, w, h, out);
            case LAUREL -> {
                int mid = y + h / 2;
                out.add(new Rect(x, mid, w, 1, 0));
                for (int px = x + 1; px + 3 <= x + w; px += 4) {
                    out.add(new Rect(px, mid - 2, 2, 1, 1));
                    out.add(new Rect(px + 1, mid - 1, 1, 1, 1));
                    out.add(new Rect(px + 2, mid + 2, 2, 1, 1));
                    out.add(new Rect(px + 2, mid + 1, 1, 1, 1));
                }
            }
            case WAVES -> {
                double amp = Math.max(1, (h - 2) / 2.0);
                int mid = y + h / 2;
                for (int px = 0; px < w; px += 2) {
                    int dy = (int) Math.round(Math.sin(px / 6.0 * Math.PI) * amp);
                    out.add(new Rect(x + px, mid + dy, Math.min(2, w - px), 1, (px / 12) % 2));
                }
            }
            case RAYS -> {
                for (int px = 0, i = 0; px < w; px += 4, i++) {
                    int len = Math.max(1, (int) Math.round(h * (0.35 + 0.65 * Math.abs(Math.sin(i * 0.7)))));
                    out.add(new Rect(x + px, y + h - len, 1, len, i % 3 == 0 ? 1 : 0));
                }
            }
            case MOSAIC -> {
                int t = Math.max(2, h / 2);
                for (int ty = 0; ty + t <= h; ty += t + 1)
                    for (int tx = 0, i = 0; tx + t <= w; tx += t + 1, i++) out.add(new Rect(x + tx, y + ty, t, t, (i + ty) % 3 == 0 ? 1 : 0));
            }
            case COLUMNS -> {
                out.add(new Rect(x, y, w, 1, 1));
                out.add(new Rect(x, y + h - 1, w, 1, 1));
                for (int px = 1; px < w; px += 3) out.add(new Rect(x + px, y + 2, 1, Math.max(1, h - 4), 0));
            }
            case RIVETS -> { for (int px = 2; px + 2 <= w; px += 12) out.add(new Rect(x + px, y + h / 2 - 1, 2, 2, 1)); out.add(new Rect(x, y + h / 2, w, 1, 0)); }
            case DOTS -> { for (int px = 0; px < w; px += 4) out.add(new Rect(x + px, y + h / 2, 1, 1, px % 16 == 0 ? 1 : 0)); }
            default -> { }
        }
        return out;
    }

    private static void bitmap(String[] bm, int x, int y, int w, int h, List<Rect> out) {
        int u = Math.max(1, h / bm.length);
        int pw = bm[0].length() * u;
        int oy = y + (h - bm.length * u) / 2;
        for (int row = 0; row < bm.length; row++) {
            int px = 0;
            while (px < w) {
                int col = (px / u) % bm[0].length();
                if (bm[row].charAt(col) == '#') {
                    int start = px;
                    while (px < w && bm[row].charAt((px / u) % bm[0].length()) == '#') px += u;
                    out.add(new Rect(x + start, oy + row * u, Math.min(px, w) - start, u, 0));
                } else px += u;
            }
        }
        if (pw <= 0) return;
    }
}
