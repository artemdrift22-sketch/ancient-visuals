package dev.ancientvisuals.core.render;

import dev.ancientvisuals.core.theme.CornerStyle;

import java.util.ArrayList;
import java.util.List;

/** Rasterises panel shapes into few horizontal rects (rows with equal insets are merged). */
public final class ShapeRaster {
    private ShapeRaster() {}

    static int inset(CornerStyle style, int d, int r) {
        if (d >= r || r <= 0) return 0;
        switch (style) {
            case ROUNDED: case PILL: case TAB: { double dy = r - d - 0.5; return (int) Math.round(r - Math.sqrt(Math.max(0, r * r - dy * dy))); }
            case CHAMFER: return r - d;
            case NOTCHED: return r;
            case STEPPED: return ((r - d + 1) / 2) * 2 - ((r - d + 1) / 2 > 0 ? 1 : 0);
            default: return 0;
        }
    }

    public static List<Rect> fill(int x, int y, int w, int h, CornerStyle style, int radius) {
        List<Rect> out = new ArrayList<>();
        if (w <= 0 || h <= 0) return out;
        int r = style == CornerStyle.PILL ? h / 2 : Math.min(radius, Math.min(w, h) / 2);
        if (style == CornerStyle.SQUARE || r <= 0) { out.add(new Rect(x, y, w, h)); return out; }
        int runStart = 0, runL = -1, runR = -1;
        for (int row = 0; row <= h; row++) {
            int l = -2, rr = -2;
            if (row < h) {
                int d = Math.min(row, h - 1 - row);
                int in = inset(style, d, r);
                l = in;
                rr = style == CornerStyle.TAB ? 0 : in;
                if (l * 2 >= w) l = rr = 0;
            }
            if (row == h || l != runL || rr != runR) {
                if (runL >= 0 && row > runStart) out.add(new Rect(x + runL, y + runStart, w - runL - runR, row - runStart));
                runStart = row; runL = l; runR = rr;
            }
        }
        return out;
    }

    /** Outline of the shape, thickness t, as rects. */
    public static List<Rect> outline(int x, int y, int w, int h, CornerStyle style, int radius, int t) {
        List<Rect> out = new ArrayList<>();
        if (w <= 0 || h <= 0) return out;
        int r = style == CornerStyle.PILL ? h / 2 : Math.min(radius, Math.min(w, h) / 2);
        for (int row = 0; row < h; row++) {
            int d = Math.min(row, h - 1 - row);
            int l = inset(style, d, r), rr = style == CornerStyle.TAB ? 0 : inset(style, d, r);
            if (style == CornerStyle.SQUARE || r <= 0) { l = 0; rr = 0; }
            if (d < t) { out.add(new Rect(x + l, y + row, w - l - rr, 1)); continue; }
            int nl = row < h / 2 ? inset(style, d - 1, r) : inset(style, d - 1, r);
            int span = Math.max(t, Math.abs(nl - l) + (l == nl ? 0 : 1));
            if (style == CornerStyle.SQUARE || r <= 0) span = t;
            out.add(new Rect(x + l, y + row, Math.min(span, w), 1));
            out.add(new Rect(x + w - rr - Math.min(span, w), y + row, Math.min(span, w), 1));
        }
        return merge(out);
    }

    /** Merges vertically adjacent rects with equal x/w. */
    static List<Rect> merge(List<Rect> in) {
        List<Rect> out = new ArrayList<>();
        for (Rect r : in) {
            boolean merged = false;
            for (int i = out.size() - 1; i >= Math.max(0, out.size() - 4); i--) {
                Rect o = out.get(i);
                if (o.x() == r.x() && o.w() == r.w() && o.y() + o.h() == r.y()) { out.set(i, new Rect(o.x(), o.y(), o.w(), o.h() + r.h(), o.tone())); merged = true; break; }
            }
            if (!merged) out.add(r);
        }
        return out;
    }
}
