package dev.ancientvisuals.core.render;

/** Axis aligned rectangle; tone 0 = ornament colour, 1 = accent colour. */
public record Rect(int x, int y, int w, int h, int tone) {
    public Rect(int x, int y, int w, int h) { this(x, y, w, h, 0); }
    public boolean contains(double px, double py) { return px >= x && py >= y && px < x + w && py < y + h; }
    public int right() { return x + w; }
    public int bottom() { return y + h; }
    public Rect inset(int d) { return new Rect(x + d, y + d, Math.max(0, w - 2 * d), Math.max(0, h - 2 * d), tone); }
    public boolean intersects(Rect o) { return x < o.x + o.w && o.x < x + w && y < o.y + o.h && o.y < y + h; }
}
