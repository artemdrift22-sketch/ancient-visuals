package dev.ancientvisuals.core.module;

import dev.ancientvisuals.core.diag.Diagnostics;
import dev.ancientvisuals.core.setting.Setting;
import dev.ancientvisuals.core.util.Fuzzy;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Consumer;

public final class ModuleRegistry {
    public static final int ERROR_LIMIT = 5;
    private static final List<Consumer<Module>> TOGGLE_LISTENERS = new CopyOnWriteArrayList<>();
    private final Map<String, Module> modules = new LinkedHashMap<>();
    private boolean safeMode;

    public record SearchHit(Module module, Setting<?> setting, int score) {}

    public <M extends Module> M register(M m) {
        if (modules.containsKey(m.id())) throw new IllegalStateException("duplicate module " + m.id());
        modules.put(m.id(), m);
        return m;
    }
    public Module get(String id) { return modules.get(id); }
    public List<Module> all() { return new ArrayList<>(modules.values()); }
    public List<Module> byCategory(Category c) { List<Module> l = new ArrayList<>(); for (Module m : modules.values()) if (m.category() == c) l.add(m); return l; }
    public List<Module> enabled() { List<Module> l = new ArrayList<>(); for (Module m : modules.values()) if (m.isEnabled()) l.add(m); return l; }

    public static void onToggle(Consumer<Module> l) { TOGGLE_LISTENERS.add(l); }
    static void fireToggle(Module m) { for (Consumer<Module> l : TOGGLE_LISTENERS) { try { l.accept(m); } catch (RuntimeException ignored) { } } }

    /** Runs r, catching everything. Errors are counted and the module auto-disables after ERROR_LIMIT. */
    public static boolean guard(Module m, String phase, Runnable r) {
        try { r.run(); return true; }
        catch (Throwable t) {
            if (t instanceof VirtualMachineError vme) throw vme;
            if (m != null) m.recordError(phase, t); else Diagnostics.error("core", phase, t);
            return false;
        }
    }

    /** Fuzzy search over module names/descriptions/tags and setting names. */
    public List<SearchHit> search(String query) {
        List<SearchHit> hits = new ArrayList<>();
        if (query == null || query.isBlank()) return hits;
        for (Module m : modules.values()) {
            int s = Math.max(Fuzzy.score(query, m.name()) + 50, Math.max(Fuzzy.score(query, m.description()) - 300, Fuzzy.score(query, String.join(" ", m.tags())) - 100));
            if (Fuzzy.score(query, m.name()) < 0 && Fuzzy.score(query, m.description()) < 0 && Fuzzy.score(query, String.join(" ", m.tags())) < 0) s = -1;
            if (s > 0) hits.add(new SearchHit(m, null, s));
            for (Setting<?> st : m.settings()) {
                int ss = Fuzzy.score(query, st.name());
                if (ss > 0) hits.add(new SearchHit(m, st, ss - 20));
            }
        }
        hits.sort(Comparator.comparingInt(SearchHit::score).reversed());
        return hits.size() > 60 ? new ArrayList<>(hits.subList(0, 60)) : hits;
    }

    public boolean safeMode() { return safeMode; }
    /** Safe mode switches off every heavy module; it does not alter saved profile data. */
    public void setSafeMode(boolean on) {
        safeMode = on;
        if (on) for (Module m : modules.values()) if (m.heavy()) m.setEnabledSilently(false);
        Diagnostics.info("core", "safe mode " + (on ? "ON" : "OFF"));
    }
    public void reenableErrored() { for (Module m : modules.values()) if (m.disabledReason() != null) { m.clearErrors(); m.setEnabled(true); } }
    public static void setSilently(Module m, boolean on) { m.setEnabledSilently(on); }
}
