package dev.ancientvisuals.core.module;

public enum Category {
    GUI("Interface", "\u2302"),
    HUD("HUD", "\u25A3"),
    PARTICLES("Particles", "\u2734"),
    MOVEMENT("Movement", "\u27A4"),
    COMBAT("Combat Visuals", "\u2694"),
    WORLD("World", "\u2600"),
    MODEL("Model & Hand", "\u270B"),
    COMPANIONS("Companions", "\u2766"),
    RESOURCES("Resources", "\u2756"),
    PERFORMANCE("Performance", "\u26A1"),
    SYSTEM("System", "\u2699");

    public final String title;
    public final String glyph;
    Category(String title, String glyph) { this.title = title; this.glyph = glyph; }
    public String langKey() { return "av.category." + name().toLowerCase(); }
}
