package dev.ancientvisuals.core.module;

import dev.ancientvisuals.core.diag.Diagnostics;
import dev.ancientvisuals.core.setting.KeySetting;
import dev.ancientvisuals.core.setting.Setting;
import dev.ancientvisuals.core.setting.SettingEvents;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** A visual feature. All lifecycle calls go through {@link ModuleRegistry#guard} so one failing module cannot crash the game. */
public abstract class Module {
    private final String id;
    private final String name;
    private final String description;
    private final Category category;
    private final boolean enabledByDefault;
    private boolean enabled;
    private final List<Setting<?>> settings = new ArrayList<>();
    private final KeySetting toggleKey;
    private final List<String> tags = new ArrayList<>();
    int errorCount;
    String disabledReason;

    protected Module(String id, String name, String description, Category category, boolean enabledByDefault) {
        if (id == null || !id.matches("[a-z0-9_]+")) throw new IllegalArgumentException("bad module id: " + id);
        this.id = id; this.name = name; this.description = description; this.category = category;
        this.enabledByDefault = enabledByDefault; this.enabled = enabledByDefault;
        this.toggleKey = new KeySetting("toggle_key", "Toggle key", KeySetting.NONE).desc("Key that toggles this module while no screen is open.");
    }

    public final String id() { return id; }
    public final String name() { return name; }
    public final String description() { return description; }
    public final Category category() { return category; }
    public final boolean enabledByDefault() { return enabledByDefault; }
    public final boolean isEnabled() { return enabled; }
    public final List<Setting<?>> settings() { return Collections.unmodifiableList(settings); }
    public final KeySetting toggleKey() { return toggleKey; }
    public final List<String> tags() { return tags; }
    public final int errorCount() { return errorCount; }
    public final String disabledReason() { return disabledReason; }
    /** Modules that cannot be turned off (e.g. the theme engine). */
    public boolean alwaysOn() { return false; }
    /** Heavy modules are switched off by safe mode. */
    public boolean heavy() { return false; }

    protected final <S extends Setting<?>> S add(S s) {
        for (Setting<?> o : settings) if (o.id().equals(s.id())) throw new IllegalStateException("duplicate setting " + id + "." + s.id());
        settings.add(s);
        return s;
    }
    protected final void tag(String... t) { Collections.addAll(tags, t); }

    public final Setting<?> setting(String sid) {
        if ("toggle_key".equals(sid)) return toggleKey;
        for (Setting<?> s : settings) if (s.id().equals(sid)) return s;
        return null;
    }

    public final void setEnabled(boolean on) {
        if (alwaysOn()) on = true;
        if (on == enabled) return;
        enabled = on;
        if (on) disabledReason = null;
        ModuleRegistry.guard(this, on ? "enable" : "disable", on ? this::onEnable : this::onDisable);
        ModuleRegistry.fireToggle(this);
    }
    public final void toggle() { setEnabled(!enabled); }

    /** Used by profile loading: changes state without firing global events twice. */
    final void setEnabledSilently(boolean on) { if (alwaysOn()) on = true; if (on != enabled) { enabled = on; ModuleRegistry.guard(this, on ? "enable" : "disable", on ? this::onEnable : this::onDisable); } }

    public void resetToDefaults() {
        SettingEvents.mute(() -> { for (Setting<?> s : settings) s.reset(); toggleKey.reset(); });
        setEnabled(enabledByDefault);
    }

    protected void onEnable() {}
    protected void onDisable() {}

    /** Disables after repeated errors; called by the registry guard. */
    final void recordError(String phase, Throwable t) {
        errorCount++;
        Diagnostics.error("module:" + id, phase + " failed (" + errorCount + ")", t);
        if (errorCount >= ModuleRegistry.ERROR_LIMIT && enabled && !alwaysOn()) {
            enabled = false;
            disabledReason = phase + ": " + (t == null ? "error" : t.getClass().getSimpleName());
            Diagnostics.warn("module:" + id, "auto-disabled after " + errorCount + " errors");
        }
    }
    public final void clearErrors() { errorCount = 0; disabledReason = null; }
}
