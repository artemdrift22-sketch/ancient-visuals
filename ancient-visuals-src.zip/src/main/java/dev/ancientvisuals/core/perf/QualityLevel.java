package dev.ancientvisuals.core.perf;

public enum QualityLevel {
    LOW(0.35, 150, 6, 1), BALANCED(0.65, 450, 12, 2), HIGH(1.0, 900, 20, 3), ULTRA(1.35, 1600, 32, 4);
    public final double particleMultiplier;
    public final int maxParticles;
    public final int trailSegments;
    public final int modelDetail;
    QualityLevel(double m, int max, int trail, int detail) { particleMultiplier = m; maxParticles = max; trailSegments = trail; modelDetail = detail; }
    public QualityLevel lower() { return values()[Math.max(0, ordinal() - 1)]; }
    public QualityLevel higher() { return values()[Math.min(values().length - 1, ordinal() + 1)]; }
}
