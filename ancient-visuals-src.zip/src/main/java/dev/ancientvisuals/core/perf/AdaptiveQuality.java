package dev.ancientvisuals.core.perf;

/** Steps visual quality down when FPS stays under target, and back up (to the user's max) when there is headroom. */
public final class AdaptiveQuality {
    private QualityLevel current;
    private long belowSince = -1, aboveSince = -1;
    public static final long DOWN_AFTER_MS = 3000, UP_AFTER_MS = 10000;

    public AdaptiveQuality(QualityLevel start) { current = start; }
    public QualityLevel current() { return current; }
    public void reset(QualityLevel q) { current = q; belowSince = aboveSince = -1; }

    public QualityLevel update(int fps, int target, QualityLevel userMax, long nowMs) {
        if (current.ordinal() > userMax.ordinal()) current = userMax;
        if (fps <= 0) return current;
        if (fps < target) {
            aboveSince = -1;
            if (belowSince < 0) belowSince = nowMs;
            if (nowMs - belowSince >= DOWN_AFTER_MS && current != QualityLevel.LOW) { current = current.lower(); belowSince = nowMs; }
        } else if (fps > target + 25) {
            belowSince = -1;
            if (aboveSince < 0) aboveSince = nowMs;
            if (nowMs - aboveSince >= UP_AFTER_MS && current.ordinal() < userMax.ordinal()) { current = current.higher(); aboveSince = nowMs; }
        } else { belowSince = -1; aboveSince = -1; }
        return current;
    }
}
