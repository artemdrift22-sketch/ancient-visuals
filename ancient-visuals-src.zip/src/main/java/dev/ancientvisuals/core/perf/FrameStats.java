package dev.ancientvisuals.core.perf;

import dev.ancientvisuals.core.util.RingBuffer;

/** Real frame-time measurements taken from successive HUD render calls. */
public final class FrameStats {
    private final RingBuffer frameMs = new RingBuffer(240);
    private long lastNanos;
    public void frame(long nowNanos) {
        if (lastNanos != 0) { double ms = (nowNanos - lastNanos) / 1e6; if (ms > 0 && ms < 2000) frameMs.add(ms); }
        lastNanos = nowNanos;
    }
    public RingBuffer samples() { return frameMs; }
    public int fps() { double avg = averageMs(); return avg <= 0 ? 0 : (int) Math.round(1000 / avg); }
    public double averageMs() { int n = Math.min(60, frameMs.size()); if (n == 0) return 0; double s = 0; for (int i = frameMs.size() - n; i < frameMs.size(); i++) s += frameMs.get(i); return s / n; }
    public double lastMs() { return frameMs.last(); }
    public double p99Ms() { return frameMs.percentile(0.99); }
    /** "1% low" FPS derived from the 99th percentile frame time. */
    public int onePercentLow() { double p = p99Ms(); return p <= 0 ? 0 : (int) Math.round(1000 / p); }
}
