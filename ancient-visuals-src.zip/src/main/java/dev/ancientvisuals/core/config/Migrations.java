package dev.ancientvisuals.core.config;

import dev.ancientvisuals.core.json.Json;

import java.util.LinkedHashMap;
import java.util.Map;

/** Step-wise schema migrations. Each step receives a deep copy, so a failed step never corrupts the original. */
public final class Migrations {
    public static final int CURRENT = 3;
    private Migrations() {}

    public static final class MigrationException extends Exception { public MigrationException(String m) { super(m); } }

    public static Map<String, Object> migrate(Map<String, Object> root) throws MigrationException {
        int v = Json.integer(root, "schema", 1);
        if (v > CURRENT) throw new MigrationException("config schema " + v + " is newer than supported " + CURRENT);
        Map<String, Object> cur = Json.deepCopy(root);
        while (v < CURRENT) {
            switch (v) {
                case 1 -> cur = v1to2(cur);
                case 2 -> cur = v2to3(cur);
                default -> throw new MigrationException("no migration from " + v);
            }
            v++;
            cur.put("schema", (long) v);
        }
        return cur;
    }

    /** v1 stored the HUD under "hudLayout"; v2 calls it "hud". */
    static Map<String, Object> v1to2(Map<String, Object> m) {
        if (m.containsKey("hudLayout") && !m.containsKey("hud")) m.put("hud", m.remove("hudLayout"));
        return m;
    }

    /** v2 had a single flat profile; v3 keeps named profiles. */
    static Map<String, Object> v2to3(Map<String, Object> m) {
        if (m.containsKey("profiles")) return m;
        Map<String, Object> data = new LinkedHashMap<>();
        if (m.containsKey("modules")) data.put("modules", m.remove("modules"));
        Map<String, Object> sections = new LinkedHashMap<>();
        if (m.containsKey("hud")) sections.put("hud", m.remove("hud"));
        data.put("sections", sections);
        Map<String, Object> prof = new LinkedHashMap<>();
        prof.put("name", "Olympus Default");
        prof.put("data", data);
        Map<String, Object> profiles = new LinkedHashMap<>();
        profiles.put("olympus_default", prof);
        m.put("profiles", profiles);
        m.put("activeProfile", "olympus_default");
        return m;
    }
}
