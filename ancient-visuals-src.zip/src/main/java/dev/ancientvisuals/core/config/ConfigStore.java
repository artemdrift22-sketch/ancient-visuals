package dev.ancientvisuals.core.config;

import dev.ancientvisuals.core.diag.Diagnostics;
import dev.ancientvisuals.core.json.Json;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.function.Supplier;

/**
 * Atomic JSON config storage with rolling backups, migrations and corruption quarantine.
 * A broken file is moved aside (never silently overwritten) and the newest valid backup is tried.
 */
public final class ConfigStore {
    public static final int BACKUPS = 5;
    private final Path dir;
    private final Path file;
    private Supplier<Map<String, Object>> snapshot;
    private boolean dirty;
    private long lastChange;
    private long debounceMs = 1500;
    private String lastLoadMessage = "";

    public enum Status { OK, CREATED, MIGRATED, RESTORED_BACKUP, FAILED }
    public record LoadResult(Status status, Map<String, Object> data, String message) {}

    public ConfigStore(Path dir) { this.dir = dir; this.file = dir.resolve("config.json"); }
    public Path dir() { return dir; }
    public Path file() { return file; }
    public String lastLoadMessage() { return lastLoadMessage; }
    public void setSnapshot(Supplier<Map<String, Object>> s) { snapshot = s; }
    public void setDebounceMs(long ms) { debounceMs = ms; }

    public LoadResult load() {
        if (!Files.exists(file)) { lastLoadMessage = "no config, using defaults"; return new LoadResult(Status.CREATED, null, lastLoadMessage); }
        try {
            Map<String, Object> root = read(file);
            int v = Json.integer(root, "schema", 1);
            Map<String, Object> migrated = Migrations.migrate(root);
            if (v != Migrations.CURRENT) {
                backupCopy("pre-migration-v" + v);
                lastLoadMessage = "migrated config from schema " + v + " to " + Migrations.CURRENT;
                Diagnostics.info("config", lastLoadMessage);
                return new LoadResult(Status.MIGRATED, migrated, lastLoadMessage);
            }
            lastLoadMessage = "config loaded";
            return new LoadResult(Status.OK, migrated, lastLoadMessage);
        } catch (Exception e) {
            Path q = quarantine();
            Diagnostics.error("config", "config unreadable, moved to " + (q == null ? "?" : q.getFileName()), e);
            for (int i = 1; i <= BACKUPS; i++) {
                Path b = backupPath(i);
                if (!Files.exists(b)) continue;
                try {
                    Map<String, Object> data = Migrations.migrate(read(b));
                    lastLoadMessage = "config was damaged; restored backup #" + i + " (damaged copy kept)";
                    Diagnostics.warn("config", lastLoadMessage);
                    return new LoadResult(Status.RESTORED_BACKUP, data, lastLoadMessage);
                } catch (Exception ignored) { }
            }
            lastLoadMessage = "config was damaged and no backup was usable; defaults are used, damaged copy kept";
            return new LoadResult(Status.FAILED, null, lastLoadMessage);
        }
    }

    private static Map<String, Object> read(Path p) throws IOException {
        if (Files.size(p) > Json.MAX_LENGTH) throw new IOException("config too large");
        return Json.parseObject(Files.readString(p, StandardCharsets.UTF_8));
    }

    private Path backupPath(int i) { return dir.resolve("config.json.bak" + i); }

    private Path quarantine() {
        try {
            Path q = dir.resolve("config.corrupt-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")) + ".json");
            Files.move(file, q, StandardCopyOption.REPLACE_EXISTING);
            return q;
        } catch (IOException e) { return null; }
    }

    private void backupCopy(String tag) {
        try { Files.copy(file, dir.resolve("config." + tag + ".json"), StandardCopyOption.REPLACE_EXISTING); } catch (IOException ignored) { }
    }

    /** Writes atomically (temp file + move) and rotates backups. */
    public synchronized boolean save(Map<String, Object> data) {
        try {
            Files.createDirectories(dir);
            data.put("schema", (long) Migrations.CURRENT);
            String text = Json.write(data, true);
            Json.parse(text); // self check before touching the real file
            if (Files.exists(file)) {
                for (int i = BACKUPS; i > 1; i--) if (Files.exists(backupPath(i - 1))) Files.move(backupPath(i - 1), backupPath(i), StandardCopyOption.REPLACE_EXISTING);
                Files.copy(file, backupPath(1), StandardCopyOption.REPLACE_EXISTING);
            }
            Path tmp = dir.resolve("config.json.tmp");
            Files.writeString(tmp, text, StandardCharsets.UTF_8);
            try { Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE); }
            catch (AtomicMoveNotSupportedException e) { Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING); }
            dirty = false;
            return true;
        } catch (Exception e) {
            Diagnostics.error("config", "save failed", e);
            return false;
        }
    }

    public void markDirty(long nowMs) { dirty = true; lastChange = nowMs; }
    public boolean isDirty() { return dirty; }
    /** Debounced autosave; call every tick. */
    public void tick(long nowMs) { if (dirty && nowMs - lastChange >= debounceMs && snapshot != null) save(snapshot.get()); }
    public void flush() { if (snapshot != null) save(snapshot.get()); }
}
