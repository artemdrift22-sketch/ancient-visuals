package dev.ancientvisuals.client;

import dev.ancientvisuals.client.fx.McParticleSink;
import dev.ancientvisuals.client.module.CrosshairModule;
import dev.ancientvisuals.client.module.SimpleModules.*;
import dev.ancientvisuals.client.module.ThemeModule;
import dev.ancientvisuals.client.module.ViewModelModule;
import dev.ancientvisuals.core.config.ConfigStore;
import dev.ancientvisuals.core.hud.HudLayout;
import dev.ancientvisuals.core.module.ModuleRegistry;
import dev.ancientvisuals.core.particle.EffectPlayer;
import dev.ancientvisuals.core.perf.AdaptiveQuality;
import dev.ancientvisuals.core.perf.FrameStats;
import dev.ancientvisuals.core.perf.QualityLevel;
import dev.ancientvisuals.core.profile.ProfileManager;
import dev.ancientvisuals.core.search.ActionRegistry;
import dev.ancientvisuals.core.theme.Palette;
import dev.ancientvisuals.core.theme.ResolvedTheme;
import dev.ancientvisuals.core.theme.Themes;
import dev.ancientvisuals.core.util.ClickCounter;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** Static service holder for the client side. */
public final class AV {
    private AV() {}
    public static final String MOD_ID = "ancientvisuals";
    public static final Logger LOG = LoggerFactory.getLogger("AncientVisuals");
    public static final ModuleRegistry modules = new ModuleRegistry();
    public static final HudLayout layout = new HudLayout();
    public static ProfileManager profiles;
    public static ConfigStore config;
    public static final EffectPlayer effects = new EffectPlayer();
    public static final McParticleSink sink = new McParticleSink();
    public static final FrameStats frames = new FrameStats();
    public static final AdaptiveQuality adaptive = new AdaptiveQuality(QualityLevel.HIGH);
    public static final ClickCounter leftCps = new ClickCounter(), rightCps = new ClickCounter();
    public static final ActionRegistry actions = new ActionRegistry();
    public static final UiState ui = new UiState();
    public static Palette customPalette = Themes.palette("user_custom");
    /** Names of mixin hooks that have fired at least once (shown in the Compatibility Center). */
    public static final Set<String> hooks = ConcurrentHashMap.newKeySet();
    public static final long sessionStart = System.currentTimeMillis();

    public static ThemeModule theme;
    public static Accessibility access;
    public static ClickGui clickGui;
    public static UiAudio audio;
    public static CrosshairModule crosshair;
    public static ViewModelModule viewmodel;
    public static Swing swing;
    public static MovementFx movement;
    public static Trails trails;
    public static HitFx hitFx;
    public static TotemFx totem;
    public static WorldFog world;
    public static Companion companion;
    public static Particles particles;
    public static Ambient ambient;
    public static Performance performance;
    public static Developer developer;
    public static Hud hud;
    public static Emotes emotes;

    private static ResolvedTheme cachedTheme;
    private static long cachedAt;
    public static ResolvedTheme theme() {
        long now = System.nanoTime();
        if (cachedTheme == null || now - cachedAt > 50_000_000L) { cachedTheme = theme.resolve(); cachedAt = now; }
        return cachedTheme;
    }
    public static void invalidateTheme() { cachedTheme = null; }
    public static void dirty() { invalidateTheme(); if (config != null) config.markDirty(System.currentTimeMillis()); }
    public static Map<String, Object> snapshot() { Map<String, Object> m = new LinkedHashMap<>(profiles.save()); m.put("ui", ui.save()); m.put("custom_palette", customPalette.toJson()); return m; }
    public static void open(Screen s) { MinecraftClient.getInstance().setScreen(s); }
    public static boolean reducedMotion() { return access != null && access.isEnabled() && access.reducedMotion.on(); }
    public static boolean reduceFlashing() { return access != null && access.isEnabled() && access.reduceFlashing.on(); }
    public static void hook(String name) { hooks.add(name); }
}
