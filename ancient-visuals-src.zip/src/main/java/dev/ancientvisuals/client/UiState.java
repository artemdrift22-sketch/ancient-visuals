package dev.ancientvisuals.client;

import dev.ancientvisuals.core.theme.Palette;
import dev.ancientvisuals.core.theme.Themes;

import java.util.*;

/** Global (not per-profile) interface state: favourites, recent modules, window position, saved HUD layouts, custom palette. */
public final class UiState {
    public final LinkedHashSet<String> favorites = new LinkedHashSet<>();
    public final LinkedList<String> recent = new LinkedList<>();
    public int guiX = Integer.MIN_VALUE, guiY = Integer.MIN_VALUE;
    public String category = "";
    public final Map<String, String> layouts = new LinkedHashMap<>();
    public final LinkedList<String> history = new LinkedList<>();

    public void touch(String moduleId) { recent.remove(moduleId); recent.addFirst(moduleId); while (recent.size() > 12) recent.removeLast(); }
    public void logChange(String what) { history.addFirst(what); while (history.size() > 40) history.removeLast(); }
    public boolean favorite(String id) { return favorites.contains(id); }
    public void toggleFavorite(String id) { if (!favorites.remove(id)) favorites.add(id); }

    public Map<String, Object> save() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("favorites", new ArrayList<>(favorites));
        m.put("recent", new ArrayList<>(recent));
        m.put("guiX", guiX); m.put("guiY", guiY);
        m.put("category", category);
        m.put("layouts", new LinkedHashMap<>(layouts));
        if (AV.customPalette != null) m.put("customPalette", AV.customPalette.toJson());
        return m;
    }

    @SuppressWarnings("unchecked")
    public void load(Object o) {
        if (!(o instanceof Map<?, ?> m)) return;
        favorites.clear(); recent.clear(); layouts.clear();
        if (m.get("favorites") instanceof List<?> l) for (Object x : l) favorites.add(String.valueOf(x));
        if (m.get("recent") instanceof List<?> l) for (Object x : l) recent.add(String.valueOf(x));
        if (m.get("guiX") instanceof Number n) guiX = n.intValue();
        if (m.get("guiY") instanceof Number n) guiY = n.intValue();
        if (m.get("category") instanceof String s) category = s;
        if (m.get("layouts") instanceof Map<?, ?> lm) for (Map.Entry<?, ?> e : lm.entrySet()) layouts.put(String.valueOf(e.getKey()), String.valueOf(e.getValue()));
        if (m.get("customPalette") instanceof Map<?, ?> p) {
            Palette fb = Themes.palette("user_custom");
            AV.customPalette = Palette.fromJson((Map<String, Object>) p, fb);
        }
    }
}
