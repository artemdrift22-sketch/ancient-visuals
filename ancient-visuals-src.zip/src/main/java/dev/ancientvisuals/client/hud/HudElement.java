package dev.ancientvisuals.client.hud;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.client.L;
import dev.ancientvisuals.core.hud.Anchor;
import dev.ancientvisuals.core.hud.HudBox;
import dev.ancientvisuals.core.module.Category;
import dev.ancientvisuals.core.module.Module;
import dev.ancientvisuals.core.setting.BoolSetting;

import java.util.function.Function;

/** A movable HUD element. Every element is a module in the HUD category with its own layout box. */
public abstract class HudElement extends Module {
    public final HudBox box;
    public final BoolSetting background = add(new BoolSetting("background", "Background", true));

    protected HudElement(String id, String name, String desc, boolean def, Anchor a, double ox, double oy) {
        super(id, name, desc, Category.HUD, def);
        box = AV.layout.register(id, a, ox, oy);
        tag("hud");
    }

    public abstract void render(HudCtx c);

    /** Whether the element has something to show right now (preview always shows). */
    public boolean visible(HudCtx c) { return true; }

    /** Simple text element: "Label value". */
    public static class Text extends HudElement {
        private final String label;
        private final Function<HudCtx, String> value;
        public final BoolSetting showLabel = add(new BoolSetting("show_label", "Show label", true));

        public Text(String id, String name, String desc, boolean def, Anchor a, double ox, double oy, String label, Function<HudCtx, String> value) {
            super(id, name, desc, def, a, ox, oy);
            this.label = label; this.value = value;
        }

        @Override public void render(HudCtx c) {
            String v;
            try { v = value.apply(c); } catch (RuntimeException e) { v = "-"; }
            c.row(showLabel.on() ? L.t("av.hud." + id() + ".label", label) : "", v);
        }
    }
}
