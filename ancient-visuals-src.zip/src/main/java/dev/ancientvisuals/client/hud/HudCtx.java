package dev.ancientvisuals.client.hud;

import dev.ancientvisuals.client.gui.Draw;
import dev.ancientvisuals.core.texture.HudSkin;
import dev.ancientvisuals.core.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;

import java.util.Locale;

/** Per-frame drawing context handed to HUD elements. Elements draw at local (0,0) and report their size. */
public final class HudCtx {
    public final DrawContext dc;
    public final TextRenderer tr;
    public final MinecraftClient mc;
    public final HudSkin skin;
    public final boolean preview;
    public final float td;
    public double opacity = 1;
    public boolean shadow;
    public int w, h;

    public HudCtx(DrawContext dc, MinecraftClient mc, HudSkin skin, boolean preview, float td, boolean shadow) {
        this.dc = dc; this.mc = mc; this.tr = mc.textRenderer; this.skin = skin; this.preview = preview; this.td = td; this.shadow = shadow;
    }

    public int pad() { return Math.max(0, skin.padding()); }
    public int c(int argb) { return Colors.mulAlpha(argb, opacity); }
    public int width(String s) { return tr.getWidth(s); }

    public int text(String s, int x, int y, int color) {
        if (s == null || s.isEmpty()) return 0;
        int col = c(color);
        if (Colors.a(col) >= 8) dc.drawText(tr, s, x, y, col, shadow || skin.shadow());
        return tr.getWidth(s);
    }

    public void size(int w, int h) { this.w = Math.max(this.w, w); this.h = Math.max(this.h, h); }

    public void bar(int x, int y, int w, int h, double f, int color) {
        Draw.bar(dc, skin.bar(), x, y, w, h, f, c(color), c(Colors.withAlpha(skin.border(), Math.max(70, Colors.a(skin.border()) / 2))));
    }

    public void item(ItemStack s, int x, int y) {
        if (s == null || s.isEmpty()) return;
        dc.drawItem(s, x, y);
        dc.drawItemInSlot(tr, s, x, y);
    }

    /** Draws a single "label value" row with padding and sets the element size. */
    public void row(String label, String value) {
        int p = pad(), x = p;
        if (label != null && !label.isEmpty()) x += text(label + " ", x, p, skin.label());
        x += text(value == null ? "-" : value, x, p, skin.text());
        size(x + p, 8 + 2 * p);
    }

    public static String f1(Number n) { return String.format(Locale.ROOT, "%.1f", n.doubleValue()); }
    public static String f0(Number n) { return String.format(Locale.ROOT, "%.0f", n.doubleValue()); }
    public static String time(long seconds) {
        long h = seconds / 3600, m = (seconds / 60) % 60, s = seconds % 60;
        return h > 0 ? String.format(Locale.ROOT, "%d:%02d:%02d", h, m, s) : String.format(Locale.ROOT, "%d:%02d", m, s);
    }
}
