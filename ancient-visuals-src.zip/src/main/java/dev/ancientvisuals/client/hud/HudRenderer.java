package dev.ancientvisuals.client.hud;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.client.gui.Draw;
import dev.ancientvisuals.core.hud.HudBox;
import dev.ancientvisuals.core.texture.HudSkin;
import dev.ancientvisuals.core.module.ModuleRegistry;
import dev.ancientvisuals.core.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

/** Draws every enabled HUD element using the shared layout. The HUD editor reuses {@link #drawAll}. */
public final class HudRenderer {
    private HudRenderer() {}

    public static final List<HudElement> elements = new ArrayList<>();

    public static void registerAll() {
        if (!elements.isEmpty()) return;
        for (HudElement e : HudElements.create()) { AV.modules.register(e); elements.add(e); }
    }

    public static HudElement byId(String id) { for (HudElement e : elements) if (e.id().equals(id)) return e; return null; }

    public static void render(DrawContext dc, RenderTickCounter tc) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.options.hudHidden) return;
        if (mc.currentScreen instanceof dev.ancientvisuals.client.gui.HudEditorScreen) return;
        if (AV.hud == null || !AV.hud.isEnabled() || AV.hud.hideAll.on()) return;
        if (AV.hud.hideInDebug.on() && mc.getDebugHud().shouldShowDebugHud()) return;
        AV.hook("hud");
        HudElements.lowHealthVignette(dc, mc);
        drawAll(dc, mc, tc.getTickDelta(false), false, e -> e.isEnabled());
    }

    /** Global HUD scale applied by scaling the matrices; returns the virtual screen size {sw, sh}. */
    public static double scale() { return AV.hud == null ? 1 : Math.max(0.25, AV.hud.globalScale.d()); }

    public static double[] virtualSize(DrawContext dc) {
        double g = scale();
        return new double[]{dc.getScaledWindowWidth() / g, dc.getScaledWindowHeight() / g};
    }

    public static void drawAll(DrawContext dc, MinecraftClient mc, float td, boolean preview, Predicate<HudElement> filter) {
        double g = scale();
        double[] vs = virtualSize(dc);
        HudSkin skin = HudSkin.get(AV.hud.skin.get());
        boolean shadow = AV.hud.textShadow.on();
        dc.getMatrices().push();
        dc.getMatrices().scale((float) g, (float) g, 1f);
        for (HudElement e : elements) {
            if (!filter.test(e)) continue;
            drawOne(dc, mc, e, skin, preview, td, shadow, vs[0], vs[1]);
        }
        dc.getMatrices().pop();
    }

    static void drawOne(DrawContext dc, MinecraftClient mc, HudElement e, HudSkin skin, boolean preview, float td, boolean shadow, double sw, double sh) {
        HudCtx c = new HudCtx(dc, mc, skin, preview, td, shadow);
        boolean vis;
        try { vis = e.visible(c); } catch (Throwable t) { vis = false; }
        if (!vis) return;
        HudBox box = e.box;
        int margin = AV.hud.safeArea.i();
        box.clamp(sw, sh, margin);
        double x = box.x(sw), y = box.y(sh);
        dc.getMatrices().push();
        dc.getMatrices().translate((float) Math.round(x), (float) Math.round(y), 0f);
        dc.getMatrices().scale((float) box.scale, (float) box.scale, 1f);
        c.opacity = box.opacity;
        c.w = 0; c.h = 0;
        if (e.background.on()) background(dc, skin, box.width, box.height, box.opacity);
        ModuleRegistry.guard(e, "render", () -> e.render(c));
        if (c.w > 0 && c.h > 0) { box.width = c.w; box.height = c.h; }
        dc.getMatrices().pop();
    }

    static void background(DrawContext dc, HudSkin s, int w, int h, double opacity) {
        if (w <= 0 || h <= 0) return;
        int bg = Colors.mulAlpha(s.background(), opacity), border = Colors.mulAlpha(s.border(), opacity), acc = Colors.mulAlpha(s.accent(), opacity);
        switch (s.bg()) {
            case NONE -> { }
            case PLATE -> {
                Draw.shape(dc, 0, 0, w, h, s.corner(), s.radius(), bg);
                if (Colors.a(border) > 0) Draw.outline(dc, 0, 0, w, h, s.corner(), s.radius(), 1, border);
                if (h >= 14 && w >= 24) Draw.ornament(dc, s.ornament(), 3, h - 3, w - 6, 2, acc, 0.6);
            }
            case STRIP -> { Draw.shape(dc, 0, 0, w, h, s.corner(), s.radius(), bg); dc.fill(0, 0, 2, h, acc); }
            case BADGE -> { Draw.shape(dc, 0, 0, w, h, s.corner(), s.radius(), bg); dc.fill(2, h - 1, w - 2, h, acc); }
            case GLASS_LITE -> {
                Draw.shape(dc, 0, 0, w, h, s.corner(), s.radius(), Colors.mulAlpha(bg, 0.6));
                dc.fill(1, 0, w - 1, 1, Colors.withAlpha(0xFFFFFFFF, (int) (60 * opacity)));
            }
        }
    }
}
