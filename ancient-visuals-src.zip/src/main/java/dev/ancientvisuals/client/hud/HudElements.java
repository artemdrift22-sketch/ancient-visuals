package dev.ancientvisuals.client.hud;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.client.L;
import dev.ancientvisuals.client.fx.FxEvents;
import dev.ancientvisuals.client.gui.Draw;
import dev.ancientvisuals.core.hud.Anchor;
import dev.ancientvisuals.core.module.Category;
import dev.ancientvisuals.core.module.Module;
import dev.ancientvisuals.core.setting.BoolSetting;
import dev.ancientvisuals.core.setting.ColorSetting;
import dev.ancientvisuals.core.setting.DoubleSetting;
import dev.ancientvisuals.core.setting.IntSetting;
import dev.ancientvisuals.core.setting.TextSetting;
import dev.ancientvisuals.core.theme.OrnamentStyle;
import dev.ancientvisuals.core.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.texture.Sprite;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;

/** All HUD elements. Values come only from data the vanilla client already has. */
public final class HudElements {
    private HudElements() {}

    static final int RED = 0xFFE5534B, GOLD = 0xFFD4A537, GREEN = 0xFF6CC56C, AZURE = 0xFF4DA3FF, ORANGE = 0xFFF0A040;
    private static final DateTimeFormatter HM = DateTimeFormatter.ofPattern("HH:mm");

    private static ClientPlayerEntity p(HudCtx c) { return c.mc.player; }

    public static List<HudElement> create() {
        List<HudElement> l = new ArrayList<>();
        // ---------- text / info ----------
        l.add(new HudElement.Text("hud_fps", "FPS", "Frames per second.", true, Anchor.TOP_LEFT, 4, 4, "FPS", c -> String.valueOf(c.mc.getCurrentFps())));
        l.add(new HudElement.Text("hud_frametime", "Frame Time", "Average and 99th percentile frame time.", false, Anchor.TOP_LEFT, 4, 18, "MS",
                c -> HudCtx.f1(AV.frames.averageMs()) + " / p99 " + HudCtx.f1(AV.frames.p99Ms())));
        l.add(new HudElement.Text("hud_ping", "Ping", "Latency from the vanilla player list.", false, Anchor.TOP_LEFT, 4, 32, "Ping", HudElements::ping));
        l.add(new HudElement.Text("hud_cps", "CPS", "Clicks per second (left | right), counted locally.", false, Anchor.TOP_LEFT, 4, 46, "CPS",
                c -> AV.leftCps.cps(System.currentTimeMillis()) + " | " + AV.rightCps.cps(System.currentTimeMillis())));
        l.add(new Coords());
        l.add(new HudElement.Text("hud_direction", "Direction", "Facing direction and yaw.", false, Anchor.TOP_LEFT, 4, 74, "Facing",
                c -> p(c) == null ? "-" : cap(p(c).getHorizontalFacing().asString()) + " " + HudCtx.f1(MathHelper.wrapDegrees(p(c).getYaw())) + "°"));
        l.add(new HudElement.Text("hud_biome", "Biome", "Current biome.", false, Anchor.TOP_LEFT, 4, 88, "Biome", HudElements::biome));
        l.add(new HudElement.Text("hud_dimension", "Dimension", "Current dimension.", false, Anchor.TOP_LEFT, 4, 102, "Dim",
                c -> c.mc.world == null ? "-" : cap(c.mc.world.getRegistryKey().getValue().getPath().replace('_', ' '))));
        l.add(new HudElement.Text("hud_world_time", "World Time", "In-game time of day and day number.", false, Anchor.TOP_RIGHT, -4, 4, "Day", HudElements::worldTime));
        l.add(new HudElement.Text("hud_clock", "Clock", "Real-world time.", false, Anchor.TOP_RIGHT, -4, 18, "", c -> LocalTime.now().format(HM)));
        l.add(new HudElement.Text("hud_session", "Session Timer", "Time since the game started.", false, Anchor.TOP_RIGHT, -4, 32, "Session",
                c -> HudCtx.time((System.currentTimeMillis() - AV.sessionStart) / 1000)));
        l.add(new HudElement.Text("hud_speed", "Speed", "Horizontal speed in blocks per second.", false, Anchor.TOP_RIGHT, -4, 46, "Speed",
                c -> p(c) == null ? "-" : HudCtx.f1(Math.hypot(p(c).getX() - p(c).prevX, p(c).getZ() - p(c).prevZ) * 20) + " b/s"));
        l.add(new HudElement.Text("hud_server", "Server", "Server address or Singleplayer.", false, Anchor.TOP_RIGHT, -4, 60, "",
                c -> c.mc.isInSingleplayer() ? L.t("av.hud.singleplayer", "Singleplayer") : c.mc.getCurrentServerEntry() == null ? "-" : c.mc.getCurrentServerEntry().address));
        l.add(new HudElement.Text("hud_memory", "Memory", "Java heap usage.", false, Anchor.TOP_RIGHT, -4, 74, "Mem", c -> {
            Runtime r = Runtime.getRuntime(); long used = (r.totalMemory() - r.freeMemory()) >> 20, max = r.maxMemory() >> 20;
            return used + " / " + max + " MB"; }));
        l.add(new HudElement.Text("hud_entities", "Entity Count", "Entities loaded on the client.", false, Anchor.TOP_RIGHT, -4, 88, "Entities",
                c -> c.mc.world == null ? "-" : String.valueOf(c.mc.world.getRegularEntityCount())));
        l.add(new HudElement.Text("hud_particles", "Particle Budget", "Live Ancient Visuals particles and the current limit.", false, Anchor.TOP_RIGHT, -4, 102, "FX",
                c -> AV.sink.live() + " / " + AV.effects.limit()));
        l.add(new HudElement.Text("hud_performance", "Performance Status", "Particle quality level and adaptive mode.", false, Anchor.TOP_RIGHT, -4, 116, "Quality",
                c -> AV.effects.quality.name() + (AV.performance.isEnabled() && AV.performance.adaptive.on() ? " (auto)" : "")));
        l.add(new HudElement.Text("hud_profile", "Current Profile", "Active visual profile.", false, Anchor.BOTTOM_RIGHT, -4, -60, "Profile",
                c -> AV.profiles.active() == null ? "-" : AV.profiles.active().name));
        l.add(new HudElement.Text("hud_packs", "Resource Pack Status", "Number of enabled resource packs.", false, Anchor.BOTTOM_RIGHT, -4, -46, "Packs", c -> {
            int n = 0; for (String id : c.mc.getResourcePackManager().getEnabledIds()) if (!id.equals("vanilla") && !id.startsWith("fabric")) n++; return String.valueOf(n); }));
        l.add(new HudElement.Text("hud_held_name", "Held Item Name", "Name of the item in your main hand.", false, Anchor.BOTTOM_CENTER, 0, -62, "",
                c -> p(c) == null || p(c).getMainHandStack().isEmpty() ? (c.preview ? "Diamond Sword" : "") : p(c).getMainHandStack().getName().getString()));
        l.add(new Stats());
        l.add(new Label());
        l.add(new InfoStrip());
        l.add(new ActiveModules());
        // ---------- graphic ----------
        l.add(new Armor());
        l.add(new ArmorRow());
        l.add(new Potions());
        l.add(new PotionGrid());
        l.add(new Keystrokes());
        l.add(new Held());
        l.add(new Durability());
        l.add(new Target());
        l.add(new Totems());
        l.add(new Warnings());
        l.add(new Compass());
        l.add(new Health());
        l.add(new Hunger());
        l.add(new Air());
        l.add(new Xp());
        l.add(new Mount());
        l.add(new Divider());
        l.add(new Logo());
        l.add(new ThemeBadge());
        return l;
    }

    static String cap(String s) { return s == null || s.isEmpty() ? "" : Character.toUpperCase(s.charAt(0)) + s.substring(1); }

    static String ping(HudCtx c) {
        if (c.mc.isInSingleplayer()) return "SP";
        if (c.mc.getNetworkHandler() == null || p(c) == null) return "-";
        PlayerListEntry e = c.mc.getNetworkHandler().getPlayerListEntry(p(c).getUuid());
        return e == null ? "-" : e.getLatency() + " ms";
    }

    static String biome(HudCtx c) {
        if (c.mc.world == null || p(c) == null) return c.preview ? "Plains" : "-";
        return c.mc.world.getBiome(p(c).getBlockPos()).getKey().map(k -> {
            Identifier id = k.getValue();
            return Text.translatable("biome." + id.getNamespace() + "." + id.getPath()).getString();
        }).orElse("-");
    }

    static String worldTime(HudCtx c) {
        if (c.mc.world == null) return "-";
        long t = c.mc.world.getTimeOfDay();
        long day = t / 24000, tt = t % 24000;
        long h = (tt / 1000 + 6) % 24, m = (tt % 1000) * 60 / 1000;
        return day + "  " + String.format(Locale.ROOT, "%02d:%02d", h, m);
    }

    static int durColor(double f) { return f > 0.5 ? GREEN : f > 0.2 ? ORANGE : RED; }
    static double durFrac(ItemStack s) { return s.isDamageable() && s.getMaxDamage() > 0 ? (s.getMaxDamage() - s.getDamage()) / (double) s.getMaxDamage() : 1; }

    static List<ItemStack> armor(HudCtx c) {
        List<ItemStack> l = new ArrayList<>();
        if (p(c) == null) return l;
        var a = p(c).getInventory().armor;
        for (int i = a.size() - 1; i >= 0; i--) if (!a.get(i).isEmpty()) l.add(a.get(i));
        if (l.isEmpty() && c.preview) { l.add(new ItemStack(Items.DIAMOND_HELMET)); l.add(new ItemStack(Items.DIAMOND_CHESTPLATE)); l.add(new ItemStack(Items.DIAMOND_LEGGINGS)); l.add(new ItemStack(Items.DIAMOND_BOOTS)); }
        return l;
    }

    static String roman(int n) { return switch (n) { case 1 -> "I"; case 2 -> "II"; case 3 -> "III"; case 4 -> "IV"; case 5 -> "V"; default -> String.valueOf(n); }; }

    static String duration(StatusEffectInstance e) { return e.isInfinite() ? "∞" : HudCtx.time(e.getDuration() / 20); }

    static Collection<StatusEffectInstance> effects(HudCtx c) { return p(c) == null ? List.of() : p(c).getStatusEffects(); }

    // ===================================================================
    static final class Coords extends HudElement {
        final BoolSetting nether = add(new BoolSetting("nether", "Nether/Overworld conversion", false));
        final IntSetting decimals = add(new IntSetting("decimals", "Decimals", 0, 0, 2));
        Coords() { super("hud_coords", "Coordinates", "X / Y / Z position.", true, Anchor.TOP_LEFT, 4, 60); }
        @Override public void render(HudCtx c) {
            var p = p(c);
            String f = "%." + decimals.i() + "f";
            double x = p == null ? 0 : p.getX(), y = p == null ? 64 : p.getY(), z = p == null ? 0 : p.getZ();
            String s = String.format(Locale.ROOT, f + " " + f + " " + f, x, y, z);
            if (nether.on() && c.mc.world != null) {
                boolean inNether = c.mc.world.getRegistryKey().getValue().getPath().equals("the_nether");
                double k = inNether ? 8 : 0.125;
                s += String.format(Locale.ROOT, "  (" + f + " " + f + ")", x * k, z * k);
            }
            c.row("XYZ", s);
        }
    }

    static final class Stats extends HudElement {
        Stats() { super("hud_stats", "Session Statistics", "Hits, crits, kills, jumps and distance counted locally this session.", false, Anchor.CENTER_RIGHT, -4, 0); }
        @Override public void render(HudCtx c) {
            int p = c.pad(), y = p, w = 0;
            String[][] rows = {{"Hits", String.valueOf(FxEvents.hits)}, {"Crits", String.valueOf(FxEvents.crits)}, {"Kills", String.valueOf(FxEvents.kills)},
                    {"Jumps", String.valueOf(FxEvents.jumps)}, {"Distance", HudCtx.f0(FxEvents.distance) + " m"}, {"Totems", String.valueOf(FxEvents.totemsPopped)}};
            for (String[] r : rows) {
                int x = p + c.text(L.t("av.hud.stat." + r[0].toLowerCase(Locale.ROOT), r[0]) + " ", p, y, c.skin.label());
                x += c.text(r[1], x, y, c.skin.text());
                w = Math.max(w, x); y += 10;
            }
            c.size(w + p, y + p - 2);
        }
    }

    static final class Label extends HudElement {
        final TextSetting text = add(new TextSetting("text", "Text", "Ancient Visuals", 64));
        final ColorSetting color = add(new ColorSetting("color", "Colour", 0xFFF4F1EA));
        Label() { super("hud_label", "Custom Text Label", "Your own text.", false, Anchor.BOTTOM_LEFT, 4, -4); }
        @Override public void render(HudCtx c) { int p = c.pad(); int w = c.text(text.get(), p, p, color.argb()); c.size(w + 2 * p, 8 + 2 * p); }
    }

    static final class InfoStrip extends HudElement {
        InfoStrip() { super("hud_info_strip", "Minimal Info Strip", "FPS · ping · coordinates in one compact line.", false, Anchor.TOP_CENTER, 0, 2); }
        @Override public void render(HudCtx c) {
            var p = p(c);
            String s = c.mc.getCurrentFps() + " fps  ·  " + ping(c) + "  ·  " + (p == null ? "0 64 0" : (int) Math.floor(p.getX()) + " " + (int) Math.floor(p.getY()) + " " + (int) Math.floor(p.getZ()));
            c.row("", s);
        }
    }

    static final class ActiveModules extends HudElement {
        final IntSetting max = add(new IntSetting("max", "Max lines", 10, 1, 30));
        ActiveModules() { super("hud_modules", "Active Visual Modules", "List of enabled visual modules.", false, Anchor.TOP_RIGHT, -4, 140); }
        @Override public void render(HudCtx c) {
            int p = c.pad(), y = p, w = 0, n = 0;
            for (Module m : AV.modules.all()) {
                if (!m.isEnabled() || m.alwaysOn() || m.category() == Category.HUD || m.category() == Category.SYSTEM) continue;
                if (n++ >= max.i()) break;
                w = Math.max(w, c.text(L.module(m), p, y, n % 2 == 0 ? c.skin.text() : c.skin.accent()));
                y += 10;
            }
            if (n == 0) { w = c.text("-", p, y, c.skin.label()); y += 10; }
            c.size(w + 2 * p, y + p - 2);
        }
    }

    // ===================================================================
    static final class Armor extends HudElement {
        final BoolSetting horizontal = add(new BoolSetting("horizontal", "Horizontal", false));
        final BoolSetting percent = add(new BoolSetting("percent", "Show percent", true));
        Armor() { super("hud_armor", "Armor Status", "Equipped armor with durability.", true, Anchor.BOTTOM_RIGHT, -4, -80); }
        @Override public boolean visible(HudCtx c) { return c.preview || !armor(c).isEmpty(); }
        @Override public void render(HudCtx c) {
            int p = c.pad(), x = p, y = p, w = 0, h = 0;
            for (ItemStack s : armor(c)) {
                c.item(s, x, y);
                int tw = 0;
                if (s.isDamageable()) {
                    double f = durFrac(s);
                    String t = percent.on() ? Math.round(f * 100) + "%" : String.valueOf(s.getMaxDamage() - s.getDamage());
                    tw = c.text(t, horizontal.on() ? x : x + 18, horizontal.on() ? y + 18 : y + 4, durColor(f));
                }
                if (horizontal.on()) { x += Math.max(18, tw + 2); w = x; h = 30; }
                else { y += 17; w = Math.max(w, 18 + tw + 2); h = y; }
            }
            c.size(w + p, h + p);
        }
    }

    static final class ArmorRow extends HudElement {
        ArmorRow() { super("hud_armor_row", "Compact Armor Row", "Small armor icons with durability bars.", false, Anchor.BOTTOM_CENTER, 100, -40); }
        @Override public void render(HudCtx c) {
            int p = c.pad(), x = p;
            for (ItemStack s : armor(c)) {
                c.item(s, x, p);
                if (s.isDamageable()) c.bar(x + 1, p + 17, 14, 2, durFrac(s), durColor(durFrac(s)));
                x += 17;
            }
            c.size(Math.max(20, x + p), 20 + 2 * p);
        }
    }

    static List<StatusEffectInstance> sortedEffects(HudCtx c) {
        List<StatusEffectInstance> l = new ArrayList<>(effects(c));
        l.sort((a, b) -> Integer.compare(b.getDuration(), a.getDuration()));
        return l;
    }

    static void icon(HudCtx c, StatusEffectInstance e, int x, int y, int size) {
        Sprite s = c.mc.getStatusEffectSpriteManager().getSprite(e.getEffectType());
        c.dc.drawSprite(x, y, 0, size, size, s);
    }

    static final class Potions extends HudElement {
        final BoolSetting icons = add(new BoolSetting("icons", "Icons", true));
        final IntSetting warnAt = add(new IntSetting("warn_at", "Warn below (s)", 10, 0, 60).suffix("s"));
        Potions() { super("hud_potions", "Potion HUD", "Active effects with level and remaining time.", true, Anchor.CENTER_LEFT, 4, 0); }
        @Override public boolean visible(HudCtx c) { return c.preview || !effects(c).isEmpty(); }
        @Override public void render(HudCtx c) {
            int p = c.pad(), y = p, w = 0;
            var list = sortedEffects(c);
            if (list.isEmpty()) { c.row("", L.t("av.hud.no_effects", "Speed II  1:30")); return; }
            for (StatusEffectInstance e : list) {
                int x = p;
                if (icons.on()) { icon(c, e, x, y, 12); x += 14; }
                String name = e.getEffectType().value().getName().getString() + (e.getAmplifier() > 0 ? " " + roman(e.getAmplifier() + 1) : "");
                x += c.text(name + " ", x, y + 2, c.skin.text());
                boolean warn = !e.isInfinite() && e.getDuration() < warnAt.i() * 20;
                x += c.text(duration(e), x, y + 2, warn ? RED : c.skin.label());
                w = Math.max(w, x); y += 14;
            }
            c.size(w + p, y + p - 2);
        }
    }

    static final class PotionGrid extends HudElement {
        final IntSetting columns = add(new IntSetting("columns", "Columns", 4, 1, 10));
        PotionGrid() { super("hud_potion_grid", "Potion Icon Grid", "Effect icons in a grid with short timers.", false, Anchor.TOP_CENTER, 0, 30); }
        @Override public boolean visible(HudCtx c) { return c.preview || !effects(c).isEmpty(); }
        @Override public void render(HudCtx c) {
            int p = c.pad(), i = 0, cols = columns.i();
            var list = sortedEffects(c);
            for (StatusEffectInstance e : list) {
                int x = p + (i % cols) * 24, y = p + (i / cols) * 28;
                icon(c, e, x + 3, y, 18);
                String t = e.isInfinite() ? "∞" : (e.getDuration() / 20 >= 60 ? (e.getDuration() / 1200) + "m" : (e.getDuration() / 20) + "s");
                c.text(t, x + 12 - c.width(t) / 2, y + 19, c.skin.label());
                i++;
            }
            int rows = Math.max(1, (list.size() + cols - 1) / cols);
            c.size(p * 2 + Math.max(1, Math.min(cols, list.size())) * 24, p * 2 + rows * 28);
        }
    }

    static final class Keystrokes extends HudElement {
        final BoolSetting mouse = add(new BoolSetting("mouse", "Mouse buttons", true));
        final BoolSetting space = add(new BoolSetting("space", "Space bar", true));
        Keystrokes() { super("hud_keystrokes", "Keystrokes", "WASD, mouse buttons and jump.", false, Anchor.BOTTOM_LEFT, 4, -40); }
        private void key(HudCtx c, int x, int y, int w, int h, String label, boolean down) {
            c.dc.fill(x, y, x + w, y + h, c.c(down ? Colors.withAlpha(c.skin.accent(), 200) : Colors.withAlpha(c.skin.background(), Math.max(90, Colors.a(c.skin.background())))));
            c.text(label, x + (w - c.width(label)) / 2, y + (h - 8) / 2, down ? 0xFF101418 : c.skin.text());
        }
        @Override public void render(HudCtx c) {
            var o = c.mc.options; int p = c.pad(), k = 18, g = 2;
            key(c, p + k + g, p, k, k, "W", o.forwardKey.isPressed());
            key(c, p, p + k + g, k, k, "A", o.leftKey.isPressed());
            key(c, p + k + g, p + k + g, k, k, "S", o.backKey.isPressed());
            key(c, p + 2 * (k + g), p + k + g, k, k, "D", o.rightKey.isPressed());
            int y = p + 2 * (k + g), w3 = 3 * k + 2 * g;
            if (mouse.on()) {
                long now = System.currentTimeMillis(); int hw = (w3 - g) / 2;
                key(c, p, y, hw, k, "LMB " + AV.leftCps.cps(now), o.attackKey.isPressed());
                key(c, p + hw + g, y, w3 - hw - g, k, "RMB " + AV.rightCps.cps(now), o.useKey.isPressed());
                y += k + g;
            }
            if (space.on()) { key(c, p, y, w3, 10, "―", o.jumpKey.isPressed()); y += 10 + g; }
            c.size(w3 + 2 * p, y - g + p);
        }
    }

    static final class Held extends HudElement {
        Held() { super("hud_held", "Held Item", "Main and off-hand items with counts.", false, Anchor.BOTTOM_CENTER, -110, -4); }
        @Override public void render(HudCtx c) {
            int p = c.pad();
            ItemStack m = p(c) == null ? ItemStack.EMPTY : p(c).getMainHandStack(), o = p(c) == null ? ItemStack.EMPTY : p(c).getOffHandStack();
            if (c.preview && m.isEmpty()) m = new ItemStack(Items.DIAMOND_SWORD);
            c.item(m, p, p); c.item(o, p + 18, p);
            c.size(2 * p + 34, 2 * p + 16);
        }
    }

    static final class Durability extends HudElement {
        Durability() { super("hud_durability", "Item Durability", "Durability of held items.", false, Anchor.BOTTOM_CENTER, 110, -4); }
        @Override public void render(HudCtx c) {
            int p = c.pad(), y = p, w = 0;
            ItemStack[] st = p(c) == null ? new ItemStack[0] : new ItemStack[]{p(c).getMainHandStack(), p(c).getOffHandStack()};
            for (ItemStack s : st) {
                if (!s.isDamageable()) continue;
                double f = durFrac(s);
                c.item(s, p, y);
                int x = p + 18 + c.text((s.getMaxDamage() - s.getDamage()) + "/" + s.getMaxDamage(), p + 18, y + 1, durColor(f));
                c.bar(p + 18, y + 11, 40, 3, f, durColor(f));
                w = Math.max(w, Math.max(x, p + 58)); y += 18;
            }
            if (y == p) { c.row("", c.preview ? "1561/1561" : "-"); return; }
            c.size(w + p, y + p - 2);
        }
    }

    static final class Target extends HudElement {
        final BoolSetting armorValue = add(new BoolSetting("armor", "Show armor value", true));
        final BoolSetting distance = add(new BoolSetting("distance", "Show distance", true));
        Target() { super("hud_target", "Target Info", "Entity under your crosshair (or the one you just hit, while visible).", false, Anchor.CENTER, 40, 20); }
        private Entity target(HudCtx c) {
            Entity e = c.mc.targetedEntity;
            if (e == null && FxEvents.lastTarget != null && System.currentTimeMillis() - FxEvents.lastAttackMs < 3000 && p(c) != null
                    && FxEvents.lastTarget.isAlive() && p(c).canSee(FxEvents.lastTarget)) e = FxEvents.lastTarget;
            return e;
        }
        @Override public boolean visible(HudCtx c) { return c.preview || target(c) != null; }
        @Override public void render(HudCtx c) {
            int p = c.pad();
            Entity e = target(c);
            String name = e == null ? "Zombie" : e.getDisplayName().getString();
            int w = c.text(name, p, p, c.skin.text());
            int y = p + 10;
            if (e == null || e instanceof LivingEntity) {
                float hp = e == null ? 14 : ((LivingEntity) e).getHealth(), max = e == null ? 20 : ((LivingEntity) e).getMaxHealth();
                c.bar(p, y, 80, 4, max <= 0 ? 0 : hp / max, RED);
                int x = p + 84 + c.text(HudCtx.f1(hp / 2f) + " ❤", p + 84, y - 2, c.skin.text());
                w = Math.max(w, x); y += 8;
                if (armorValue.on()) { int a = e == null ? 8 : ((LivingEntity) e).getArmor(); w = Math.max(w, p + c.text("Armor " + a, p, y, c.skin.label())); y += 10; }
            }
            if (distance.on() && p(c) != null && e != null) { w = Math.max(w, p + c.text(HudCtx.f1(p(c).distanceTo(e)) + " m", p, y, c.skin.label())); y += 10; }
            c.size(Math.max(w, 80 + p) + p, y + p);
        }
    }

    static final class Totems extends HudElement {
        Totems() { super("hud_totems", "Totem Counter", "Totems in your inventory and totems used this session.", false, Anchor.BOTTOM_RIGHT, -4, -20); }
        @Override public void render(HudCtx c) {
            int p = c.pad();
            int n = p(c) == null ? 0 : p(c).getInventory().count(Items.TOTEM_OF_UNDYING);
            c.item(new ItemStack(Items.TOTEM_OF_UNDYING), p, p);
            int x = p + 18 + c.text("x" + n, p + 18, p + 4, n == 0 ? RED : c.skin.text());
            x += c.text("  (" + FxEvents.totemsPopped + " used)", x, p + 4, c.skin.label());
            c.size(x + p, 16 + 2 * p);
        }
    }

    static final class Warnings extends HudElement {
        final DoubleSetting lowHealth = add(new DoubleSetting("low_health", "Low health (hearts)", 4, 0.5, 10, 0.5));
        final IntSetting potion = add(new IntSetting("potion_seconds", "Potion expiring (s)", 5, 0, 60).suffix("s"));
        final IntSetting armor = add(new IntSetting("armor_percent", "Armor low (%)", 10, 0, 50).suffix("%"));
        Warnings() { super("hud_warnings", "Warnings", "Low health, expiring potions and low armor durability.", true, Anchor.CENTER, 0, -40); }
        private List<String> warnings(HudCtx c) {
            List<String> l = new ArrayList<>();
            var p = p(c);
            if (p == null) return l;
            if (p.getHealth() > 0 && p.getHealth() <= lowHealth.d() * 2) l.add(L.t("av.warn.low_health", "Low health!"));
            for (StatusEffectInstance e : p.getStatusEffects())
                if (!e.isInfinite() && e.getDuration() < potion.i() * 20 && e.getEffectType().value().isBeneficial())
                    l.add(e.getEffectType().value().getName().getString() + " " + L.t("av.warn.expiring", "expiring"));
            for (ItemStack s : p.getInventory().armor)
                if (s.isDamageable() && durFrac(s) * 100 <= armor.i()) l.add(s.getName().getString() + " " + L.t("av.warn.armor", "almost broken"));
            return l;
        }
        @Override public boolean visible(HudCtx c) { return c.preview || !warnings(c).isEmpty(); }
        @Override public void render(HudCtx c) {
            List<String> l = warnings(c);
            if (l.isEmpty()) l = List.of(L.t("av.warn.low_health", "Low health!"));
            boolean blink = !AV.reduceFlashing() && (System.currentTimeMillis() / 400) % 2 == 0;
            int p = c.pad(), y = p, w = 0;
            for (String s : l) { w = Math.max(w, c.width(s)); }
            for (String s : l) { c.text(s, p + (w - c.width(s)) / 2, y, blink ? 0xFFFFD0C8 : RED); y += 10; }
            c.size(w + 2 * p, y + p - 2);
        }
    }

    static final class Compass extends HudElement {
        final IntSetting width = add(new IntSetting("width", "Width", 140, 60, 300));
        Compass() { super("hud_compass", "Compass", "Compass strip with cardinal directions.", false, Anchor.TOP_CENTER, 0, 14); }
        @Override public void render(HudCtx c) {
            int p = c.pad(), w = width.i(), cx = p + w / 2;
            double yaw = p(c) == null ? 180 : MathHelper.wrapDegrees(p(c).getYaw());
            double ppd = w / 150.0;
            for (int a = 0; a < 360; a += 15) {
                double d = MathHelper.wrapDegrees(a - yaw);
                if (Math.abs(d) > 75) continue;
                int x = (int) Math.round(cx + d * ppd);
                String lab = switch (a) { case 0 -> "S"; case 90 -> "W"; case 180 -> "N"; case 270 -> "E"; default -> null; };
                if (lab != null) c.text(lab, x - c.width(lab) / 2, p, lab.equals("N") ? RED : c.skin.text());
                else c.dc.fill(x, p + (a % 45 == 0 ? 2 : 4), x + 1, p + 8, c.c(c.skin.label()));
            }
            c.dc.fill(cx, p + 9, cx + 1, p + 12, c.c(c.skin.accent()));
            c.size(w + 2 * p, 12 + 2 * p);
        }
    }

    abstract static class BarHud extends HudElement {
        final IntSetting barWidth = add(new IntSetting("bar_width", "Bar width", 81, 30, 200));
        final BoolSetting numbers = add(new BoolSetting("numbers", "Numbers", true));
        BarHud(String id, String name, String desc, Anchor a, double ox, double oy) { super(id, name, desc, false, a, ox, oy); }
        abstract double value(HudCtx c);
        abstract double max(HudCtx c);
        abstract int color(HudCtx c);
        String text(HudCtx c) { return HudCtx.f0(value(c)) + "/" + HudCtx.f0(max(c)); }
        @Override public void render(HudCtx c) {
            int p = c.pad(), bw = barWidth.i();
            double m = max(c);
            c.bar(p, p + 2, bw, 5, m <= 0 ? 0 : value(c) / m, color(c));
            int w = bw;
            if (numbers.on()) w += 4 + c.text(text(c), p + bw + 4, p, c.skin.text());
            c.size(w + 2 * p, 9 + 2 * p);
        }
    }

    static final class Health extends BarHud {
        Health() { super("hud_health", "Health Bar", "Health and absorption as a bar (adds to the vanilla hearts).", Anchor.BOTTOM_CENTER, -60, -56); }
        double value(HudCtx c) { return p(c) == null ? 17 : p(c).getHealth(); }
        double max(HudCtx c) { return p(c) == null ? 20 : p(c).getMaxHealth(); }
        int color(HudCtx c) { return RED; }
        @Override String text(HudCtx c) { float ab = p(c) == null ? 0 : p(c).getAbsorptionAmount(); return super.text(c) + (ab > 0 ? " +" + HudCtx.f0(ab) : ""); }
    }

    static final class Hunger extends BarHud {
        Hunger() { super("hud_hunger", "Hunger Bar", "Food level and saturation.", Anchor.BOTTOM_CENTER, 60, -56); }
        double value(HudCtx c) { return p(c) == null ? 18 : p(c).getHungerManager().getFoodLevel(); }
        double max(HudCtx c) { return 20; }
        int color(HudCtx c) { return ORANGE; }
        @Override String text(HudCtx c) { return super.text(c) + (p(c) == null ? "" : " (" + HudCtx.f1(p(c).getHungerManager().getSaturationLevel()) + ")"); }
    }

    static final class Air extends BarHud {
        Air() { super("hud_air", "Air Bar", "Remaining air while underwater.", Anchor.BOTTOM_CENTER, 60, -68); }
        @Override public boolean visible(HudCtx c) { return c.preview || p(c) != null && (p(c).getAir() < p(c).getMaxAir() || p(c).isSubmergedInWater()); }
        double value(HudCtx c) { return p(c) == null ? 200 : Math.max(0, p(c).getAir()); }
        double max(HudCtx c) { return p(c) == null ? 300 : p(c).getMaxAir(); }
        int color(HudCtx c) { return AZURE; }
        @Override String text(HudCtx c) { return HudCtx.f0(value(c) / 20.0) + "s"; }
    }

    static final class Xp extends BarHud {
        Xp() { super("hud_xp", "XP Bar", "Level and progress to the next level.", Anchor.BOTTOM_CENTER, 0, -30); }
        double value(HudCtx c) { return p(c) == null ? 0.6 : p(c).experienceProgress; }
        double max(HudCtx c) { return 1; }
        int color(HudCtx c) { return GREEN; }
        @Override String text(HudCtx c) { return "Lv " + (p(c) == null ? 30 : p(c).experienceLevel) + "  " + Math.round(value(c) * 100) + "%"; }
    }

    static final class Mount extends BarHud {
        Mount() { super("hud_mount", "Mount Health", "Health of the entity you are riding.", Anchor.BOTTOM_CENTER, 60, -80); }
        private LivingEntity v(HudCtx c) { return p(c) != null && p(c).getVehicle() instanceof LivingEntity le ? le : null; }
        @Override public boolean visible(HudCtx c) { return c.preview || v(c) != null; }
        double value(HudCtx c) { return v(c) == null ? 22 : v(c).getHealth(); }
        double max(HudCtx c) { return v(c) == null ? 30 : v(c).getMaxHealth(); }
        int color(HudCtx c) { return GOLD; }
    }

    static final class Divider extends HudElement {
        final IntSetting width = add(new IntSetting("width", "Width", 120, 20, 400));
        final dev.ancientvisuals.core.setting.EnumSetting<OrnamentStyle> style = add(new dev.ancientvisuals.core.setting.EnumSetting<>("style", "Ornament", OrnamentStyle.MEANDER));
        Divider() { super("hud_divider", "Custom Divider", "Decorative ornament line.", false, Anchor.TOP_CENTER, 0, 60); background.set(false); }
        @Override public void render(HudCtx c) {
            int w = width.i();
            Draw.ornament(c.dc, style.get(), 0, 0, w, 7, c.c(c.skin.accent()), 1);
            c.size(w, 7);
        }
    }

    static final class Logo extends HudElement {
        final TextSetting title = add(new TextSetting("title", "Title", "ANCIENT VISUALS", 32));
        Logo() { super("hud_logo", "Custom Logo", "Olympus emblem with your title.", false, Anchor.TOP_LEFT, 4, 130); }
        @Override public void render(HudCtx c) {
            int p = c.pad(), gold = c.c(GOLD);
            // laurel-like emblem built from pixels
            for (int i = 0; i < 5; i++) { c.dc.fill(p + i, p + 8 - i * 2, p + i + 2, p + 9 - i * 2, gold); c.dc.fill(p + 14 - i, p + 8 - i * 2, p + 16 - i, p + 9 - i * 2, gold); }
            c.dc.fill(p + 7, p + 2, p + 9, p + 12, c.c(c.skin.accent()));
            int w = c.text(title.get(), p + 20, p + 2, c.skin.text());
            Draw.ornament(c.dc, OrnamentStyle.MEANDER, p + 20, p + 12, w, 5, gold, 0.9);
            c.size(p * 2 + 20 + w, p * 2 + 17);
        }
    }

    static final class ThemeBadge extends HudElement {
        ThemeBadge() { super("hud_theme", "HUD Theme Badge", "Shows the HUD skin; click it in the HUD editor to cycle skins.", false, Anchor.BOTTOM_LEFT, 4, -18); }
        @Override public void render(HudCtx c) { c.row("Skin", c.skin.name()); }
    }

    /** Vignette shown when health is low (HitFx option). */
    public static void lowHealthVignette(net.minecraft.client.gui.DrawContext dc, MinecraftClient mc) {
        var hf = AV.hitFx;
        if (hf == null || !hf.isEnabled() || !hf.lowHealthVignette.on() || mc.player == null) return;
        float hp = mc.player.getHealth(), max = mc.player.getMaxHealth();
        double th = hf.lowHealthAt.d() <= 1 ? hf.lowHealthAt.d() * max : hf.lowHealthAt.d();
        if (hp <= 0 || hp > th) return;
        double k = 1 - hp / Math.max(0.1, th);
        if (!AV.reduceFlashing()) k *= 0.75 + 0.25 * Math.sin(System.currentTimeMillis() / 250.0);
        int a = (int) Math.round(30 + 90 * k);
        int w = dc.getScaledWindowWidth(), h = dc.getScaledWindowHeight(), e = Math.max(20, h / 6);
        int col = Colors.argb(a, 200, 30, 30), none = Colors.argb(0, 200, 30, 30);
        dc.fillGradient(0, 0, w, e, col, none);
        dc.fillGradient(0, h - e, w, h, none, col);
    }
}
