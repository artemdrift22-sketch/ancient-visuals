package dev.ancientvisuals.client.hud;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.client.fx.FxEvents;
import dev.ancientvisuals.core.util.Colors;
import net.minecraft.client.gui.DrawContext;

/** Small diagonal hitmarker drawn around the crosshair after a confirmed local hit (visual only). */
public final class Hitmarker {
    private Hitmarker() {}

    public static void draw(DrawContext dc, int cx, int cy) {
        var h = AV.hitFx;
        if (h == null || !h.isEnabled() || !h.hitmarker.on() || FxEvents.hitmarkerTicks <= 0) return;
        float f = FxEvents.hitmarkerTicks / (float) Math.max(1, FxEvents.hitmarkerMax);
        if (AV.reduceFlashing()) f *= 0.6f;
        int base = h.hitmarkerColor.argb();
        int c = Colors.withAlpha(base, Math.max(0, Math.min(255, (int) (Colors.a(base) * f))));
        if (Colors.a(c) < 8) return;
        for (int i = 0; i < 4; i++) {
            int d = 3 + i;
            dc.fill(cx - d - 1, cy - d - 1, cx - d, cy - d, c);
            dc.fill(cx + d, cy - d - 1, cx + d + 1, cy - d, c);
            dc.fill(cx - d - 1, cy + d, cx - d, cy + d + 1, c);
            dc.fill(cx + d, cy + d, cx + d + 1, cy + d + 1, c);
        }
    }
}
