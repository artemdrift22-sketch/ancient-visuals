package dev.ancientvisuals.client;

import dev.ancientvisuals.client.fx.CompanionRenderer;
import dev.ancientvisuals.client.fx.Effects;
import dev.ancientvisuals.client.fx.FxEvents;
import dev.ancientvisuals.client.gui.*;
import dev.ancientvisuals.client.hud.HudRenderer;
import dev.ancientvisuals.client.module.CrosshairModule;
import dev.ancientvisuals.client.module.SimpleModules.*;
import dev.ancientvisuals.client.module.ThemeModule;
import dev.ancientvisuals.client.module.ViewModelModule;
import dev.ancientvisuals.core.config.ConfigStore;
import dev.ancientvisuals.core.diag.Diagnostics;
import dev.ancientvisuals.core.module.Module;
import dev.ancientvisuals.core.module.ModuleRegistry;
import dev.ancientvisuals.core.perf.QualityLevel;
import dev.ancientvisuals.core.profile.ProfileManager;
import dev.ancientvisuals.core.profile.ProfilePresets;
import dev.ancientvisuals.core.search.ActionRegistry;
import dev.ancientvisuals.core.setting.SettingEvents;
import dev.ancientvisuals.core.theme.Palette;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import org.lwjgl.glfw.GLFW;

import java.util.*;

/** Client entrypoint: registers modules, config, keybinds, events and quick actions. Client-side only. */
public final class AncientVisualsClient implements ClientModInitializer {
    public static KeyBinding guiKey, emoteKey;
    private static final Map<Integer, Boolean> keyState = new HashMap<>();

    @Override
    public void onInitializeClient() {
        Diagnostics.setSink(e -> {
            if (e.level() == Diagnostics.Level.ERROR) AV.LOG.error(e.toString());
            else if (e.level() == Diagnostics.Level.WARN) AV.LOG.warn(e.toString());
            else if (AV.developer != null && AV.developer.isEnabled() && AV.developer.logEvents.on()) AV.LOG.info(e.toString());
        });
        registerModules();
        HudRenderer.registerAll();

        AV.profiles = new ProfileManager(AV.modules);
        AV.profiles.addSection("hud", AV.layout);
        AV.profiles.addSection("effects", Effects.INSTANCE);
        AV.config = new ConfigStore(FabricLoader.getInstance().getConfigDir().resolve("ancientvisuals"));
        loadConfig();
        AV.config.setSnapshot(AV::snapshot);

        SettingEvents.listen(s -> AV.dirty());
        ModuleRegistry.onToggle(m -> { AV.dirty(); AV.ui.logChange(m.id() + (m.isEnabled() ? " on" : " off")); });

        guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.ancientvisuals.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "key.categories.ancientvisuals"));
        emoteKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.ancientvisuals.emotes", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B, "key.categories.ancientvisuals"));

        ClientTickEvents.END_CLIENT_TICK.register(AncientVisualsClient::tick);
        HudRenderCallback.EVENT.register((dc, tc) -> {
            AV.hook("hud");
            try { HudRenderer.render(dc, tc); } catch (RuntimeException e) { Diagnostics.error("hud", "render failed", e); }
        });
        WorldRenderEvents.LAST.register(ctx -> AV.frames.frame(System.nanoTime()));
        WorldRenderEvents.AFTER_ENTITIES.register(ctx -> {
            try { CompanionRenderer.render(ctx); } catch (RuntimeException e) { Diagnostics.error("companion", "render failed", e); }
        });
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
            if (world.isClient() && player instanceof ClientPlayerEntity cp) {
                try { FxEvents.onAttack(cp, entity); } catch (RuntimeException e) { Diagnostics.error("hit_fx", "attack hook failed", e); }
            }
            return ActionResult.PASS;
        });
        ClientLifecycleEvents.CLIENT_STOPPING.register(mc -> { if (AV.config != null) AV.config.flush(); });
        registerActions();
        AV.LOG.info("Ancient Visuals ready: {} modules, {} actions", AV.modules.all().size(), AV.actions.size());
    }

    private static void registerModules() {
        AV.theme = AV.modules.register(new ThemeModule());
        AV.access = AV.modules.register(new Accessibility());
        AV.clickGui = AV.modules.register(new ClickGui());
        AV.audio = AV.modules.register(new UiAudio());
        AV.hud = AV.modules.register(new Hud());
        AV.crosshair = AV.modules.register(new CrosshairModule());
        AV.viewmodel = AV.modules.register(new ViewModelModule());
        AV.swing = AV.modules.register(new Swing());
        AV.movement = AV.modules.register(new MovementFx());
        AV.trails = AV.modules.register(new Trails());
        AV.hitFx = AV.modules.register(new HitFx());
        AV.totem = AV.modules.register(new TotemFx());
        AV.world = AV.modules.register(new WorldFog());
        AV.companion = AV.modules.register(new Companion());
        AV.particles = AV.modules.register(new Particles());
        AV.ambient = AV.modules.register(new Ambient());
        AV.emotes = AV.modules.register(new Emotes());
        AV.performance = AV.modules.register(new Performance());
        AV.developer = AV.modules.register(new Developer());
    }

    private static void loadConfig() {
        try {
            ConfigStore.LoadResult r = AV.config.load();
            Map<String, Object> data = r.data();
            if (data != null) {
                SettingEvents.mute(() -> AV.profiles.load(data));
                AV.ui.load(data.get("ui"));
                if (data.get("custom_palette") instanceof Map<?, ?> cp) {
                    @SuppressWarnings("unchecked") Map<String, Object> m = (Map<String, Object>) cp;
                    AV.customPalette = Palette.fromJson(m, AV.customPalette);
                }
            }
            if (r.status() != ConfigStore.Status.OK) Diagnostics.info("config", r.status() + ": " + r.message());
        } catch (RuntimeException e) {
            Diagnostics.error("config", "config load failed, defaults used", e);
        }
        AV.invalidateTheme();
    }

    private static void tick(MinecraftClient mc) {
        long now = System.currentTimeMillis();
        try {
            while (guiKey.wasPressed()) if (mc.currentScreen == null) AV.open(new ClickGuiScreen(null));
            while (emoteKey.wasPressed()) if (mc.currentScreen == null && mc.player != null) AV.open(new EmoteWheelScreen(null));
            toggleKeys(mc);
            applyQuality(now);
            FxEvents.tick(mc);
            CompanionRenderer.tick(mc);
            if (mc.world != null) { AV.effects.tick(AV.sink); AV.sink.tick(); } else { AV.effects.clear(); AV.sink.clear(); }
        } catch (RuntimeException e) {
            Diagnostics.error("tick", "client tick failed", e);
        }
        if (AV.config != null) AV.config.tick(now);
    }

    private static void applyQuality(long now) {
        var pm = AV.particles;
        QualityLevel user = pm.quality.get();
        var perf = AV.performance;
        if (perf.isEnabled()) {
            QualityLevel cap = perf.maxQuality.get();
            if (user.ordinal() > cap.ordinal()) user = cap;
            if (perf.adaptive.on()) user = AV.adaptive.update(AV.frames.fps(), perf.targetFps.i(), user, now);
        }
        AV.effects.quality = user;
        AV.effects.userMax = pm.max.i();
        AV.effects.userMultiplier = pm.isEnabled() ? pm.intensity.d() : 0.0;
    }

    /** Per-module toggle keys (only while no screen is open). */
    private static void toggleKeys(MinecraftClient mc) {
        if (mc.currentScreen != null || mc.player == null) { keyState.clear(); return; }
        long win = mc.getWindow().getHandle();
        Map<Integer, Boolean> now = new HashMap<>();
        for (Module m : AV.modules.all()) {
            if (!m.toggleKey().bound() || m.alwaysOn()) continue;
            int k = m.toggleKey().key();
            boolean down = now.computeIfAbsent(k, key -> key >= 0 && InputUtil.isKeyPressed(win, key));
            if (down && !keyState.getOrDefault(k, false)) {
                m.toggle();
                UiSounds.play(m.isEnabled() ? UiSounds.Kind.TOGGLE_ON : UiSounds.Kind.TOGGLE_OFF);
                mc.player.sendMessage(Text.literal("✦ " + L.module(m) + ": " + (m.isEnabled() ? "ON" : "OFF")), true);
            }
        }
        keyState.clear();
        keyState.putAll(now);
    }

    private static void registerActions() {
        ActionRegistry a = AV.actions;
        a.register(new ActionRegistry.Action("tool.hud_editor", "HUD Editor", "tools", "hud layout editor move редактор худ", () -> AV.open(new HudEditorScreen(null))));
        a.register(new ActionRegistry.Action("tool.profiles", "Profiles", "tools", "profile preset профиль", () -> AV.open(new ProfilesScreen(null))));
        a.register(new ActionRegistry.Action("tool.particle_studio", "Particle Studio", "tools", "particles effects частицы эффекты", () -> AV.open(new ParticleStudioScreen(null))));
        a.register(new ActionRegistry.Action("tool.theme_editor", "Theme Editor", "tools", "theme palette colors тема цвета", () -> AV.open(new ThemeEditorScreen(null))));
        a.register(new ActionRegistry.Action("tool.resource_hub", "Resource Pack Hub", "tools", "resource pack ресурспак", () -> AV.open(new ResourceHubScreen(null))));
        a.register(new ActionRegistry.Action("tool.texture_lab", "Texture Lab", "tools", "texture paint editor текстура", () -> AV.open(new TextureLabScreen(null))));
        a.register(new ActionRegistry.Action("tool.compat", "Compatibility & Diagnostics", "tools", "diagnostics compatibility log диагностика", () -> AV.open(new DiagnosticsScreen(null))));
        a.register(new ActionRegistry.Action("tool.emotes", "Emote wheel", "tools", "emote эмоции", () -> AV.open(new EmoteWheelScreen(null))));
        a.register(new ActionRegistry.Action("sys.safe_mode", "Toggle safe mode", "system", "safe mode безопасный", () -> AV.modules.setSafeMode(!AV.modules.safeMode())));
        a.register(new ActionRegistry.Action("sys.reset_hud", "Reset HUD layout", "system", "reset hud layout сброс", () -> { AV.layout.reset(); AV.dirty(); }));
        a.register(new ActionRegistry.Action("sys.save_config", "Save configuration now", "system", "save config сохранить", () -> AV.config.flush()));
        for (ProfilePresets.Preset p : ProfilePresets.ALL) {
            a.register(new ActionRegistry.Action("preset." + p.id(), "Preset: " + p.name(), "profiles", "preset " + p.id() + " " + p.description(), () -> {
                AV.profiles.apply(AV.profiles.buildPreset(p));
                AV.dirty();
                UiSounds.play(UiSounds.Kind.PROFILE);
            }));
        }
    }
}
