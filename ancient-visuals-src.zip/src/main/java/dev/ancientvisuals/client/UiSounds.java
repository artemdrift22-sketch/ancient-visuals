package dev.ancientvisuals.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;

public final class UiSounds {
    private UiSounds() {}
    public enum Kind { CLICK, TOGGLE_ON, TOGGLE_OFF, OPEN, CLOSE, PROFILE, WARNING, ERROR, SUCCESS, RESET }

    private static SoundEvent ev(Object o) { return o instanceof RegistryEntry<?> e ? (SoundEvent) e.value() : (SoundEvent) o; }

    public static void play(Kind k) {
        var a = AV.audio;
        if (a == null || !a.isEnabled()) return;
        boolean allowed = switch (k) { case OPEN, CLOSE -> a.panels.on(); case WARNING, ERROR, SUCCESS, RESET, PROFILE -> a.notices.on(); default -> a.clicks.on(); };
        float vol = (float) a.volume.d();
        if (!allowed || vol <= 0.001f) return;
        Object s; float pitch; float v = vol;
        switch (k) {
            case CLICK -> { s = SoundEvents.UI_BUTTON_CLICK; pitch = 1.5f; v = vol * 0.45f; }
            case TOGGLE_ON -> { s = SoundEvents.BLOCK_NOTE_BLOCK_HAT; pitch = 1.7f; }
            case TOGGLE_OFF -> { s = SoundEvents.BLOCK_NOTE_BLOCK_HAT; pitch = 1.15f; }
            case OPEN -> { s = SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME; pitch = 1.35f; }
            case CLOSE -> { s = SoundEvents.BLOCK_AMETHYST_BLOCK_CHIME; pitch = 0.95f; v = vol * 0.8f; }
            case PROFILE -> { s = SoundEvents.BLOCK_NOTE_BLOCK_CHIME; pitch = 1.25f; }
            case WARNING -> { s = SoundEvents.BLOCK_NOTE_BLOCK_BASS; pitch = 0.8f; }
            case ERROR -> { s = SoundEvents.BLOCK_NOTE_BLOCK_DIDGERIDOO; pitch = 0.7f; }
            case SUCCESS -> { s = SoundEvents.ENTITY_EXPERIENCE_ORB_PICKUP; pitch = 1.25f; v = vol * 0.6f; }
            default -> { s = SoundEvents.BLOCK_NOTE_BLOCK_CHIME; pitch = 0.7f; }
        }
        try { MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(ev(s), pitch, v)); } catch (Throwable ignored) { }
    }

    public static void hit(float volume) {
        if (volume <= 0.001f) return;
        try { MinecraftClient.getInstance().getSoundManager().play(PositionedSoundInstance.master(ev(SoundEvents.BLOCK_NOTE_BLOCK_HAT), 1.9f, volume)); } catch (Throwable ignored) { }
    }
}
