package dev.ancientvisuals.client.gui;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.client.L;
import dev.ancientvisuals.client.UiSounds;
import dev.ancientvisuals.core.diag.Diagnostics;
import dev.ancientvisuals.core.module.Module;
import dev.ancientvisuals.core.setting.*;
import dev.ancientvisuals.core.theme.CornerStyle;
import dev.ancientvisuals.core.theme.Palette;
import dev.ancientvisuals.core.theme.ResolvedTheme;
import dev.ancientvisuals.core.theme.Shell;
import dev.ancientvisuals.core.util.Colors;
import dev.ancientvisuals.core.util.Fuzzy;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;
import java.util.function.Supplier;

/**
 * Immediate-mode base screen: every frame widgets register clickable regions; input is dispatched to the
 * topmost region. Handles UI scale, overlays (confirm, prompt, colour picker, menus, lists), tooltips,
 * toasts, text fields and key capture. Never pauses the game.
 */
public abstract class BaseScreen extends Screen {
    protected final Screen parent;
    protected ResolvedTheme t;
    protected Palette pal;
    protected int W, H, mx, my;
    protected float scale = 1f;
    private final List<Region> regions = new ArrayList<>();
    private int overlayBase = 0;
    protected Overlay overlay;
    private boolean drawingOverlay;
    private String tip;
    private String toast; private long toastUntil; private int toastColor;
    protected Field focus;
    private Region dragging;
    private long openedAt;
    protected KeySetting capturing;
    private final Map<Object, Field> fields = new HashMap<>();

    public interface Click { void click(int button); }
    public interface Drag { void drag(int x, int y); }
    public interface Scroll { void scroll(double amount); }
    protected record Region(int x, int y, int w, int h, Click click, Drag drag, Scroll scroll) {
        boolean in(int px, int py) { return px >= x && py >= y && px < x + w && py < y + h; }
    }
    public interface Overlay { void draw(DrawContext dc); default boolean dismissible() { return true; } default boolean key(int key) { return false; } }
    public record MenuItem(String label, Runnable run) {}

    public static final class Field {
        final StringBuilder sb = new StringBuilder();
        public final int max;
        public String placeholder = "";
        public Consumer<String> onChange, onEnter;
        public Field(String init, int max) { this.max = max; if (init != null) sb.append(init, 0, Math.min(init.length(), max)); }
        public String text() { return sb.toString(); }
        public void set(String s) { sb.setLength(0); if (s != null) sb.append(s, 0, Math.min(s.length(), max)); changed(); }
        void changed() { if (onChange != null) onChange.accept(text()); }
    }

    protected BaseScreen(String title, Screen parent) { super(Text.literal(title)); this.parent = parent; }

    @Override public boolean shouldPause() { return false; }
    @Override protected void init() { if (openedAt == 0) { openedAt = System.currentTimeMillis(); UiSounds.play(UiSounds.Kind.OPEN); } }
    @Override public void close() { UiSounds.play(UiSounds.Kind.CLOSE); onClosed(); AV.dirty(); if (client != null) client.setScreen(parent); }
    protected void onClosed() {}
    @Override public void renderBackground(DrawContext dc, int mouseX, int mouseY, float delta) { }

    protected float uiScale() { return AV.clickGui == null ? 1f : AV.clickGui.uiScale.f(); }
    protected double dim() { return AV.clickGui == null ? 0.45 : AV.clickGui.dim.d(); }
    protected abstract void draw(DrawContext dc, float delta);

    protected double openProgress() {
        if (AV.reducedMotion() || !t.animations()) return 1;
        double d = (System.currentTimeMillis() - openedAt) / (180.0 / Math.max(0.25, t.animSpeed()));
        return Math.max(0, Math.min(1, d));
    }

    @Override public void render(DrawContext dc, int mouseX, int mouseY, float delta) {
        t = AV.theme(); pal = t.palette();
        scale = Math.max(0.5f, uiScale());
        W = (int) (width / scale); H = (int) (height / scale);
        mx = (int) (mouseX / scale); my = (int) (mouseY / scale);
        regions.clear(); tip = null; drawingOverlay = false;
        int dimA = (int) Math.round(Math.max(0, Math.min(0.95, dim())) * 255);
        if (dimA > 0) dc.fill(0, 0, width, height, Colors.argb(dimA, 6, 10, 20));
        var m = dc.getMatrices();
        m.push();
        m.scale(scale, scale, 1f);
        double op = openProgress();
        if (op < 1) m.translate(0f, (float) ((1 - op) * 10), 0f);
        try { draw(dc, delta); } catch (Throwable e) { Diagnostics.error("gui", getClass().getSimpleName() + ": " + e, e); toast("GUI error: " + e.getClass().getSimpleName(), pal.error()); }
        m.pop();
        m.push();
        m.translate(0f, 0f, 400f);
        m.scale(scale, scale, 1f);
        overlayBase = regions.size();
        if (overlay != null) {
            drawingOverlay = true;
            dc.fill(0, 0, W, H, 0x66000000);
            try { overlay.draw(dc); } catch (Throwable e) { overlay = null; Diagnostics.error("gui", "overlay: " + e, e); }
            drawingOverlay = false;
        }
        if (tip != null && (AV.clickGui == null || AV.clickGui.tooltips.on())) drawTip(dc, tip);
        if (toast != null && System.currentTimeMillis() < toastUntil) {
            int w = textRenderer.getWidth(toast) + 16, x = W / 2 - w / 2, y = H - 28;
            Draw.shape(dc, x, y, w, 16, t.corner(), Math.min(4, t.radius()), Colors.withAlpha(pal.surface(), 240));
            dc.fill(x, y + 15, x + w, y + 16, toastColor);
            text(dc, toast, x + 8, y + 4, pal.text());
        }
        m.pop();
    }

    // ------------------------------------------------------------------ input
    @Override public boolean mouseClicked(double x, double y, int button) {
        int px = (int) (x / scale), py = (int) (y / scale);
        if (capturing != null) { capturing = null; return true; }
        focus = null;
        int from = overlay != null ? overlayBase : 0;
        int to = overlay != null ? regions.size() : overlayBase;
        for (int i = to - 1; i >= from; i--) {
            Region r = regions.get(i);
            if (!r.in(px, py) || (r.click == null && r.drag == null)) continue;
            if (r.drag != null && button == 0) { dragging = r; r.drag.drag(px, py); }
            if (r.click != null) { UiSounds.play(UiSounds.Kind.CLICK); r.click.click(button); }
            return true;
        }
        if (overlay != null) { if (overlay.dismissible()) overlay = null; return true; }
        return onEmptyClick(px, py, button);
    }

    @Override public boolean mouseReleased(double x, double y, int button) { dragging = null; onRelease((int) (x / scale), (int) (y / scale), button); return true; }

    @Override public boolean mouseDragged(double x, double y, int button, double dx, double dy) {
        int px = (int) (x / scale), py = (int) (y / scale);
        if (dragging != null) { dragging.drag.drag(px, py); return true; }
        return onDrag(px, py, button);
    }

    @Override public boolean mouseScrolled(double x, double y, double h, double v) {
        int px = (int) (x / scale), py = (int) (y / scale);
        int from = overlay != null ? overlayBase : 0, to = overlay != null ? regions.size() : overlayBase;
        for (int i = to - 1; i >= from; i--) { Region r = regions.get(i); if (r.scroll != null && r.in(px, py)) { r.scroll.scroll(v); return true; } }
        return overlay != null || onScroll(px, py, v);
    }

    @Override public boolean keyPressed(int key, int scan, int mods) {
        if (capturing != null) {
            KeySetting k = capturing; capturing = null;
            if (key == GLFW.GLFW_KEY_ESCAPE) return true;
            int code = key == GLFW.GLFW_KEY_BACKSPACE || key == GLFW.GLFW_KEY_DELETE ? KeySetting.NONE : key;
            String c = conflict(k, code);
            k.set(code);
            if (c != null) toast(L.t("av.gui.key_conflict", "Also used by: ") + c, pal.warning());
            return true;
        }
        if (focus != null) {
            Field f = focus;
            switch (key) {
                case GLFW.GLFW_KEY_BACKSPACE -> { if (f.sb.length() > 0) { if (hasControlDown()) f.sb.setLength(0); else f.sb.setLength(f.sb.length() - 1); f.changed(); } }
                case GLFW.GLFW_KEY_ENTER, GLFW.GLFW_KEY_KP_ENTER -> { if (f.onEnter != null) f.onEnter.accept(f.text()); focus = null; }
                case GLFW.GLFW_KEY_ESCAPE, GLFW.GLFW_KEY_TAB -> focus = null;
                case GLFW.GLFW_KEY_V -> { if (hasControlDown() && client != null) { String clip = client.keyboard.getClipboard(); for (char ch : clip.toCharArray()) if (ch >= 32 && f.sb.length() < f.max) f.sb.append(ch); f.changed(); } }
                case GLFW.GLFW_KEY_C -> { if (hasControlDown() && client != null) client.keyboard.setClipboard(f.text()); }
                default -> { }
            }
            return true;
        }
        if (overlay != null) {
            if (overlay.key(key)) return true;
            if (key == GLFW.GLFW_KEY_ESCAPE) { overlay = null; return true; }
            return true;
        }
        if (onKey(key, mods)) return true;
        if (key == GLFW.GLFW_KEY_ESCAPE) { close(); return true; }
        return false;
    }

    @Override public boolean charTyped(char chr, int mods) {
        if (focus != null && chr >= 32 && chr != 127 && focus.sb.length() < focus.max) { focus.sb.append(chr); focus.changed(); return true; }
        return onChar(chr);
    }

    protected boolean onEmptyClick(int x, int y, int button) { return false; }
    protected void onRelease(int x, int y, int button) { }
    protected boolean onDrag(int x, int y, int button) { return false; }
    protected boolean onScroll(int x, int y, double v) { return false; }
    protected boolean onKey(int key, int mods) { return false; }
    protected boolean onChar(char c) { return false; }

    // ------------------------------------------------------------------ primitives
    protected void region(int x, int y, int w, int h, Click c) { regions.add(new Region(x, y, w, h, c, null, null)); }
    protected void dragRegion(int x, int y, int w, int h, Drag d, Click c) { regions.add(new Region(x, y, w, h, c, d, null)); }
    protected void scrollRegion(int x, int y, int w, int h, Scroll s) { regions.add(new Region(x, y, w, h, null, null, s)); }
    protected boolean hover(int x, int y, int w, int h) {
        if (overlay != null && !drawingOverlay) return false;
        return mx >= x && my >= y && mx < x + w && my < y + h;
    }
    protected void tip(String s) { if (s != null && !s.isBlank()) tip = s; }
    public void toast(String s, int color) { toast = s; toastColor = color; toastUntil = System.currentTimeMillis() + 2600; }
    protected void ok(String s) { toast(s, pal == null ? 0xFF6CC56C : pal.success()); UiSounds.play(UiSounds.Kind.SUCCESS); }
    protected void fail(String s) { toast(s, pal == null ? 0xFFE5534B : pal.error()); UiSounds.play(UiSounds.Kind.ERROR); }

    protected int text(DrawContext dc, String s, int x, int y, int color) {
        if (s == null) return 0;
        dc.drawText(textRenderer, s, x, y, color, t.textShadow());
        return textRenderer.getWidth(s);
    }
    protected void textC(DrawContext dc, String s, int cx, int y, int color) { text(dc, s, cx - textRenderer.getWidth(s) / 2, y, color); }
    protected String trim(String s, int w) { if (s == null) return ""; if (textRenderer.getWidth(s) <= w) return s; return textRenderer.trimToWidth(s, Math.max(0, w - 6)) + "…"; }
    protected int tw(String s) { return textRenderer.getWidth(s); }
    protected String title(String s) { return t.shell().upperHeaders() ? s.toUpperCase(java.util.Locale.ROOT) : s; }

    protected void panel(DrawContext dc, int x, int y, int w, int h) {
        if (t.shell().shadow()) Draw.shape(dc, x + 2, y + 2, w, h, t.corner(), t.radius(), 0x40000000);
        Draw.shape(dc, x, y, w, h, t.corner(), t.radius(), t.alpha(pal.surface()));
        Draw.outline(dc, x, y, w, h, t.corner(), t.radius(), 1, t.highContrast() ? pal.text() : pal.border());
        if (t.ornamentIntensity() > 0.05 && w > 48) Draw.ornament(dc, t.ornament(), x + 8, y + 2, w - 16, 4, pal.ornament(), t.ornamentIntensity());
    }

    protected void header(DrawContext dc, String s, int x, int y, int w) {
        text(dc, title(s), x, y, pal.accent());
        int lx = x + tw(title(s)) + 4;
        if (lx < x + w) dc.fill(lx, y + 4, x + w, y + 5, Colors.withAlpha(pal.border(), 160));
    }

    protected boolean button(DrawContext dc, int x, int y, int w, int h, String label, Runnable r) {
        boolean hv = hover(x, y, w, h);
        int rad = Math.min(t.radius(), h / 2);
        Draw.shape(dc, x, y, w, h, t.corner(), rad, hv ? pal.hover() : pal.surfaceAlt());
        Draw.outline(dc, x, y, w, h, t.corner(), rad, 1, hv || t.highContrast() ? pal.accent() : pal.border());
        if (t.highContrast() && hv) Draw.outline(dc, x - 1, y - 1, w + 2, h + 2, t.corner(), rad, 1, pal.text());
        textC(dc, trim(label, w - 4), x + w / 2, y + (h - 8) / 2, pal.text());
        if (r != null) region(x, y, w, h, b -> r.run());
        return hv;
    }
    protected void danger(DrawContext dc, int x, int y, int w, int h, String label, String question, Runnable r) {
        button(dc, x, y, w, h, label, () -> confirm(question, r));
        dc.fill(x + 2, y + h - 2, x + w - 2, y + h - 1, pal.error());
    }
    protected boolean chip(DrawContext dc, int x, int y, String label, boolean active, Runnable r) {
        int w = tw(label) + 10, h = 12;
        boolean hv = hover(x, y, w, h);
        Draw.shape(dc, x, y, w, h, CornerStyle.PILL, 6, active ? pal.primary() : hv ? pal.hover() : pal.surfaceAlt());
        text(dc, label, x + 5, y + 2, active ? pal.background() | 0xFF000000 : pal.text());
        if (r != null) region(x, y, w, h, b -> r.run());
        return hv;
    }
    protected int chipW(String label) { return tw(label) + 14; }

    protected void toggleGfx(DrawContext dc, int x, int y, boolean on) {
        Shell.Toggle st = t.shell().toggle();
        int acc = pal.primary(), off = pal.disabled();
        switch (st) {
            case SWITCH -> { Draw.shape(dc, x, y, 18, 9, CornerStyle.PILL, 4, on ? acc : off); Draw.shape(dc, on ? x + 10 : x + 1, y + 1, 7, 7, CornerStyle.PILL, 3, pal.text()); }
            case CHECK -> { Draw.outline(dc, x + 9, y, 9, 9, CornerStyle.SQUARE, 0, 1, on ? acc : pal.border()); if (on) dc.fill(x + 11, y + 2, x + 16, y + 7, acc); }
            case GEM -> { Draw.shape(dc, x + 9, y, 9, 9, CornerStyle.CHAMFER, 4, on ? pal.accent() : off); if (on) dc.fill(x + 13, y + 2, x + 14, y + 3, 0xCCFFFFFF); }
            case PILL -> { Draw.shape(dc, x, y, 18, 9, CornerStyle.PILL, 4, on ? acc : off); dc.fill(x + 5, y + 4, x + 13, y + 5, on ? pal.text() : pal.textMuted()); }
            case TEXT -> { String s = on ? "ON" : "OFF"; text(dc, s, x + 18 - tw(s), y, on ? acc : pal.textMuted()); }
        }
    }

    protected void sliderGfx(DrawContext dc, int x, int y, int w, double f) {
        f = Math.max(0, Math.min(1, f));
        int fw = (int) Math.round(f * w), acc = pal.primary(), bg = pal.disabled();
        switch (t.shell().slider()) {
            case BAR -> { dc.fill(x, y, x + w, y + 4, bg); dc.fill(x, y, x + fw, y + 4, acc); dc.fill(x + fw - 1, y - 2, x + fw + 1, y + 6, pal.text()); }
            case NOTCHED -> { dc.fill(x, y + 1, x + w, y + 3, bg); dc.fill(x, y + 1, x + fw, y + 3, acc); for (int i = 0; i <= 10; i++) { int nx = x + i * (w - 1) / 10; dc.fill(nx, y - 1, nx + 1, y + 5, i * 0.1 <= f ? acc : pal.border()); } }
            case BEADS -> { int n = Math.max(4, w / 7); for (int i = 0; i < n; i++) { int bx = x + i * w / n; Draw.shape(dc, bx, y - 1, 5, 5, CornerStyle.PILL, 2, (i + 0.5) / n <= f ? acc : bg); } }
            case LINE -> { dc.fill(x, y + 2, x + w, y + 3, bg); dc.fill(x, y + 2, x + fw, y + 3, acc); Draw.shape(dc, x + fw - 3, y - 1, 6, 6, CornerStyle.PILL, 3, pal.accent()); }
            case BLOCKS -> { int n = Math.max(4, w / 6); for (int i = 0; i < n; i++) { int bx = x + i * w / n; dc.fill(bx, y - 1, bx + Math.max(2, w / n - 1), y + 5, (i + 0.5) / n <= f ? acc : bg); } }
        }
    }

    protected void slider(DrawContext dc, int x, int y, int w, int h, double f, String val, DoubleConsumer set, IntConsumer nudge, Runnable reset) {
        int vw = Math.max(30, tw(val) + 4), bw = Math.max(10, w - vw - 4);
        sliderGfx(dc, x, y + h / 2 - 2, bw, f);
        text(dc, val, x + bw + 4, y + (h - 8) / 2, pal.textMuted());
        dragRegion(x - 2, y, bw + 4, h, (px, py) -> set.accept((px - x) / (double) Math.max(1, bw)), b -> { if (b == 1 && reset != null) reset.run(); });
        scrollRegion(x, y, w, h, a -> nudge.accept(a > 0 ? 1 : -1));
    }

    protected void valueBox(DrawContext dc, int x, int y, int w, int h, String v, boolean hv) {
        Draw.shape(dc, x, y + 1, w, h - 2, t.corner(), Math.min(3, t.radius()), hv ? pal.hover() : pal.surfaceAlt());
        String s = trim(v, w - 16);
        textC(dc, s, x + w / 2, y + (h - 8) / 2, pal.text());
        text(dc, "‹", x + 3, y + (h - 8) / 2, pal.textMuted());
        text(dc, "›", x + w - 7, y + (h - 8) / 2, pal.textMuted());
    }

    protected void swatch(DrawContext dc, int x, int y, int w, int h, int argb) {
        for (int yy = 0; yy < h; yy += 3) for (int xx = 0; xx < w; xx += 3) dc.fill(x + xx, y + yy, x + Math.min(w, xx + 3), y + Math.min(h, yy + 3), ((xx + yy) / 3) % 2 == 0 ? 0xFF999999 : 0xFF666666);
        dc.fill(x, y, x + w, y + h, argb);
        Draw.outline(dc, x, y, w, h, CornerStyle.SQUARE, 0, 1, pal.border());
    }

    protected Field field(Object key, Supplier<String> init, int max) {
        return fields.computeIfAbsent(key, k -> new Field(init.get(), max));
    }

    protected void field(DrawContext dc, Field f, int x, int y, int w, int h) {
        boolean foc = focus == f;
        Draw.shape(dc, x, y, w, h, t.corner(), Math.min(2, t.radius()), Colors.withAlpha(pal.background(), 230));
        Draw.outline(dc, x, y, w, h, t.corner(), Math.min(2, t.radius()), 1, foc ? pal.accent() : pal.border());
        String s = f.text();
        boolean ph = s.isEmpty() && !foc;
        String shown = ph ? f.placeholder : s;
        while (shown.length() > 0 && tw(shown) > w - 10) shown = shown.substring(1);
        int ww = text(dc, shown, x + 4, y + (h - 8) / 2, ph ? pal.textMuted() : pal.text());
        if (foc && (System.currentTimeMillis() / 500) % 2 == 0) dc.fill(x + 5 + ww, y + 2, x + 6 + ww, y + h - 2, pal.accent());
        region(x, y, w, h, b -> { focus = f; if (b == 1) f.set(""); });
    }

    // ------------------------------------------------------------------ settings
    protected int rowH() { return Math.max(13, t.rowHeight()); }

    /** Draws one setting row and returns its height. Right click resets to default. */
    protected int settingRow(DrawContext dc, Module m, Setting<?> s, int x, int y, int w) {
        int h = rowH();
        boolean hv = hover(x, y, w, h);
        if (hv) {
            dc.fill(x, y, x + w, y + h, Colors.withAlpha(pal.hover(), 110));
            String d = L.t("av.setting." + m.id() + "." + s.id() + ".desc", s.description());
            tip(d.isBlank() ? null : d);
        }
        String name = L.setting(m, s);
        int ty = y + (h - 8) / 2;
        if (!s.isDefault() && !(s instanceof ActionSetting)) dc.fill(x, y + 2, x + 2, y + h - 2, pal.accent());
        int cx = x + w / 2, cw = w / 2 - 4;
        if (s instanceof ActionSetting as) {
            Runnable run = () -> { as.run(); ok(name); };
            if (as.dangerous()) danger(dc, x + 4, y + 1, w - 8, h - 2, name, L.t("av.gui.confirm", "Are you sure?") + " " + name, run);
            else button(dc, x + 4, y + 1, w - 8, h - 2, name, run);
            return h;
        }
        text(dc, trim(name, w / 2 - 6), x + 5, ty, pal.text());
        if (s instanceof BoolSetting b) {
            toggleGfx(dc, x + w - 22, y + (h - 9) / 2, b.on());
            region(x, y, w, h, bt -> { if (bt == 1) b.reset(); else { b.toggle(); UiSounds.play(b.on() ? UiSounds.Kind.TOGGLE_ON : UiSounds.Kind.TOGGLE_OFF); } });
        } else if (s instanceof IntSetting is) {
            slider(dc, cx, y, cw, h, is.fraction(), is.displayValue(), is::setFraction, is::nudge, is::reset);
        } else if (s instanceof DoubleSetting ds) {
            slider(dc, cx, y, cw, h, ds.fraction(), ds.displayValue(), ds::setFraction, ds::nudge, ds::reset);
        } else if (s instanceof EnumSetting<?> es) {
            valueBox(dc, cx, y, cw, h, es.displayValue(), hv);
            region(cx, y, cw, h, bt -> { if (bt == 2) es.reset(); else es.cycle(bt == 1 || mx < cx + cw / 3 ? -1 : 1); });
            scrollRegion(cx, y, cw, h, a -> es.cycle(a > 0 ? -1 : 1));
        } else if (s instanceof ChoiceSetting cs) {
            valueBox(dc, cx, y, cw, h, cs.displayValue(), hv);
            region(cx, y, cw, h, bt -> { if (bt == 1) cs.reset(); else choose(name, cs); });
            scrollRegion(cx, y, cw, h, a -> cs.cycle(a > 0 ? -1 : 1));
        } else if (s instanceof ColorSetting col) {
            swatch(dc, x + w - 34, y + 2, 30, h - 4, col.argb());
            text(dc, col.displayValue(), x + w - 40 - tw(col.displayValue()), ty, pal.textMuted());
            region(cx, y, cw, h, bt -> { if (bt == 1) col.reset(); else colorPicker(col.argb(), col.allowsAlpha(), c -> col.set(c)); });
        } else if (s instanceof GradientSetting gs) {
            int n = gs.stops(), sw = Math.max(8, Math.min(20, cw / Math.max(1, n)));
            for (int i = 0; i < n; i++) {
                final int idx = i; int sx = x + w - 4 - (n - i) * (sw + 2);
                swatch(dc, sx, y + 2, sw, h - 4, gs.stop(i));
                region(sx, y, sw, h, bt -> { if (bt == 1) gs.reset(); else colorPicker(gs.stop(idx), true, c -> gs.setStop(idx, c)); });
            }
        } else if (s instanceof KeySetting ks) {
            valueBox(dc, cx, y, cw, h, capturing == ks ? L.t("av.gui.press_key", "Press a key…") : keyName(ks.key()), hv || capturing == ks);
            region(cx, y, cw, h, bt -> { if (bt == 1) ks.set(KeySetting.NONE); else capturing = ks; });
        } else if (s instanceof TextSetting ts) {
            Field f = field(ts, ts::get, ts.maxLength());
            f.onChange = v -> ts.set(v);
            if (focus != f && !f.text().equals(ts.get())) { f.sb.setLength(0); f.sb.append(ts.get()); }
            field(dc, f, cx, y + 1, cw, h - 2);
        } else {
            text(dc, s.displayValue(), cx, ty, pal.textMuted());
        }
        return h;
    }

    public static String keyName(int code) {
        if (code < 0) return "—";
        try { return InputUtil.Type.KEYSYM.createFromCode(code).getLocalizedText().getString(); } catch (Throwable e) { return "#" + code; }
    }

    protected String conflict(KeySetting ks, int code) {
        if (code < 0) return null;
        for (Module m : AV.modules.all()) {
            if (m.toggleKey() != ks && m.toggleKey().key() == code) return L.module(m);
            for (Setting<?> s : m.settings()) if (s instanceof KeySetting k && k != ks && k.key() == code) return L.module(m) + " / " + L.setting(m, s);
        }
        if (client != null) for (KeyBinding kb : client.options.allKeys) if (kb.matchesKey(code, -1)) return Text.translatable(kb.getTranslationKey()).getString();
        return null;
    }

    // ------------------------------------------------------------------ overlays
    private void drawTip(DrawContext dc, String s) {
        List<String> lines = wrap(s, 200);
        int w = 0; for (String l : lines) w = Math.max(w, tw(l));
        int h = lines.size() * 10 + 6, x = Math.min(mx + 10, W - w - 12), y = Math.min(my + 12, H - h - 4);
        Draw.shape(dc, x, y, w + 10, h, t.corner(), Math.min(3, t.radius()), Colors.withAlpha(pal.background(), 245));
        Draw.outline(dc, x, y, w + 10, h, t.corner(), Math.min(3, t.radius()), 1, pal.accent());
        for (int i = 0; i < lines.size(); i++) text(dc, lines.get(i), x + 5, y + 4 + i * 10, pal.text());
    }

    protected List<String> wrap(String s, int w) {
        List<String> out = new ArrayList<>();
        for (String para : s.split("\n")) {
            StringBuilder line = new StringBuilder();
            for (String word : para.split(" ")) {
                if (line.length() > 0 && tw(line + " " + word) > w) { out.add(line.toString()); line.setLength(0); }
                if (line.length() > 0) line.append(' ');
                line.append(word);
            }
            out.add(line.toString());
        }
        return out;
    }

    protected int[] centerBox(int w, int h) { return new int[]{W / 2 - w / 2, H / 2 - h / 2, w, h}; }

    public void confirm(String question, Runnable yes) {
        UiSounds.play(UiSounds.Kind.WARNING);
        overlay = new Overlay() {
            public void draw(DrawContext dc) {
                List<String> lines = wrap(question, 220);
                int[] b = centerBox(240, 40 + lines.size() * 10);
                panel(dc, b[0], b[1], b[2], b[3]);
                for (int i = 0; i < lines.size(); i++) textC(dc, lines.get(i), b[0] + b[2] / 2, b[1] + 10 + i * 10, pal.text());
                int by = b[1] + b[3] - 18;
                button(dc, b[0] + 20, by, 90, 14, L.t("av.gui.yes", "Yes"), () -> { overlay = null; try { yes.run(); } catch (Throwable e) { fail(String.valueOf(e.getMessage())); } });
                button(dc, b[0] + b[2] - 110, by, 90, 14, L.t("av.gui.cancel", "Cancel"), () -> overlay = null);
            }
            public boolean dismissible() { return false; }
            public boolean key(int k) { if (k == GLFW.GLFW_KEY_ENTER) { overlay = null; yes.run(); return true; } return false; }
        };
    }

    public void prompt(String title, String init, int max, Consumer<String> ok) {
        Field f = new Field(init, max);
        Runnable submit = () -> { overlay = null; String v = f.text().trim(); if (!v.isEmpty()) ok.accept(v); };
        f.onEnter = v -> submit.run();
        focus = f;
        overlay = new Overlay() {
            public void draw(DrawContext dc) {
                int[] b = centerBox(240, 62);
                panel(dc, b[0], b[1], b[2], b[3]);
                text(dc, title, b[0] + 10, b[1] + 8, pal.accent());
                field(dc, f, b[0] + 10, b[1] + 22, b[2] - 20, 14);
                button(dc, b[0] + 10, b[1] + 42, 100, 14, "OK", submit);
                button(dc, b[0] + b[2] - 110, b[1] + 42, 100, 14, L.t("av.gui.cancel", "Cancel"), () -> overlay = null);
            }
            public boolean dismissible() { return false; }
        };
    }

    public void menu(int x, int y, List<MenuItem> items) {
        overlay = new Overlay() {
            public void draw(DrawContext dc) {
                int w = 80; for (MenuItem i : items) w = Math.max(w, tw(i.label()) + 16);
                int h = items.size() * 13 + 6, px = Math.min(x, W - w - 2), py = Math.min(y, H - h - 2);
                panel(dc, px, py, w, h);
                for (int i = 0; i < items.size(); i++) {
                    MenuItem it = items.get(i); int iy = py + 3 + i * 13;
                    if (hover(px, iy, w, 13)) dc.fill(px + 2, iy, px + w - 2, iy + 13, pal.hover());
                    text(dc, it.label(), px + 8, iy + 3, pal.text());
                    region(px, iy, w, 13, b -> { overlay = null; it.run().run(); });
                }
            }
        };
    }

    /** Searchable list picker for choice settings (effects, skins, palettes ...). */
    public void choose(String title, ChoiceSetting cs) {
        List<String> opts = cs.options();
        pick(title, opts, id -> { cs.set(id); return labelOf(cs, id); }, cs::set, cs.get());
    }

    private static String labelOf(ChoiceSetting cs, String id) { String old = cs.get(); return id; }

    public void pick(String title, List<String> ids, java.util.function.Function<String, String> label, Consumer<String> onPick, String current) {
        Field f = new Field("", 40);
        f.placeholder = L.t("av.gui.search", "Search…");
        focus = f;
        int[] scroll = {0};
        overlay = new Overlay() {
            public void draw(DrawContext dc) {
                int[] b = centerBox(220, Math.min(H - 40, 260));
                panel(dc, b[0], b[1], b[2], b[3]);
                text(dc, title, b[0] + 8, b[1] + 8, pal.accent());
                field(dc, f, b[0] + 8, b[1] + 20, b[2] - 16, 14);
                List<String> list = new ArrayList<>();
                String q = f.text().trim();
                for (String id : ids) if (q.isEmpty() || Fuzzy.score(q, id + " " + display(id)) > 0) list.add(id);
                int ly = b[1] + 38, rows = (b[3] - 46) / 12;
                scroll[0] = Math.max(0, Math.min(scroll[0], list.size() - rows));
                for (int i = 0; i < rows && i + scroll[0] < list.size(); i++) {
                    String id = list.get(i + scroll[0]); int iy = ly + i * 12;
                    boolean cur = id.equals(current);
                    if (hover(b[0] + 4, iy, b[2] - 8, 12)) dc.fill(b[0] + 4, iy, b[0] + b[2] - 4, iy + 12, pal.hover());
                    text(dc, trim(display(id), b[2] - 20), b[0] + 10, iy + 2, cur ? pal.accent() : pal.text());
                    region(b[0] + 4, iy, b[2] - 8, 12, bt -> { overlay = null; focus = null; onPick.accept(id); });
                }
                scrollRegion(b[0], b[1], b[2], b[3], a -> scroll[0] -= (int) Math.signum(a) * 3);
            }
            String display(String id) { try { String l = label.apply(id); return l == null || l.equals(id) ? pretty(id) : l; } catch (Throwable e) { return id; } }
        };
    }

    public static String pretty(String id) {
        if (id == null) return "";
        StringBuilder sb = new StringBuilder();
        for (String p : id.split("_")) { if (p.isEmpty()) continue; if (sb.length() > 0) sb.append(' '); sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)); }
        return sb.toString();
    }

    public void colorPicker(int argb, boolean alpha, IntConsumer onChange) {
        float[] hsv = Colors.toHsv(argb);
        float[] st = {hsv[0], hsv[1], hsv[2], Colors.a(argb)};
        Field hex = new Field(Colors.toHex(argb), 9);
        Runnable push = () -> { int c = Colors.fromHsv(st[0], st[1], st[2], alpha ? (int) st[3] : 255); onChange.accept(c); hex.sb.setLength(0); hex.sb.append(Colors.toHex(c)); };
        hex.onEnter = v -> { try { int c = Colors.parseHex(v); float[] h2 = Colors.toHsv(c); st[0] = h2[0]; st[1] = h2[1]; st[2] = h2[2]; st[3] = Colors.a(c); onChange.accept(c); } catch (RuntimeException e) { fail("#RRGGBB / #AARRGGBB"); } };
        overlay = new Overlay() {
            public void draw(DrawContext dc) {
                int[] b = centerBox(190, 170);
                int x = b[0], y = b[1];
                panel(dc, x, y, b[2], b[3]);
                int sx = x + 10, sy = y + 12, S = 100, cell = 4;
                for (int i = 0; i < S; i += cell) for (int j = 0; j < S; j += cell)
                    dc.fill(sx + i, sy + j, sx + i + cell, sy + j + cell, Colors.fromHsv(st[0], i / (float) S, 1 - j / (float) S, 255));
                int kx = sx + (int) (st[1] * S), ky = sy + (int) ((1 - st[2]) * S);
                Draw.outline(dc, kx - 2, ky - 2, 5, 5, CornerStyle.SQUARE, 0, 1, 0xFFFFFFFF);
                dragRegion(sx, sy, S, S, (px, py) -> { st[1] = clamp01((px - sx) / (float) S); st[2] = clamp01(1 - (py - sy) / (float) S); push.run(); }, null);
                int hx = sx + S + 8;
                for (int j = 0; j < S; j += 2) dc.fill(hx, sy + j, hx + 10, sy + j + 2, Colors.fromHsv(j * 360f / S, 1, 1, 255));
                int hy = sy + (int) (st[0] / 360f * S); dc.fill(hx - 1, hy, hx + 11, hy + 1, 0xFFFFFFFF);
                dragRegion(hx, sy, 10, S, (px, py) -> { st[0] = clamp01((py - sy) / (float) S) * 359.9f; push.run(); }, null);
                if (alpha) {
                    int ax = hx + 16;
                    for (int j = 0; j < S; j += 2) dc.fill(ax, sy + j, ax + 10, sy + j + 2, Colors.withAlpha(Colors.fromHsv(st[0], st[1], st[2], 255), 255 - j * 255 / S));
                    int ay = sy + (int) ((1 - st[3] / 255f) * S); dc.fill(ax - 1, ay, ax + 11, ay + 1, 0xFFFFFFFF);
                    dragRegion(ax, sy, 10, S, (px, py) -> { st[3] = Math.round(clamp01(1 - (py - sy) / (float) S) * 255); push.run(); }, null);
                }
                int cur = Colors.fromHsv(st[0], st[1], st[2], alpha ? (int) st[3] : 255);
                swatch(dc, x + b[2] - 30, sy, 20, 20, cur);
                field(dc, hex, sx, sy + S + 6, 90, 14);
                int px = sx, py = sy + S + 24;
                int[] presets = {pal.primary(), pal.secondary(), pal.accent(), pal.text(), pal.surface(), pal.ornament(), 0xFFD4A537, 0xFF2F6FD6, 0xFFF4F1EA, 0xFFE5534B};
                for (int c : presets) { final int pc = c; swatch(dc, px, py, 12, 12, c); region(px, py, 12, 12, bt -> { float[] h2 = Colors.toHsv(pc); st[0] = h2[0]; st[1] = h2[1]; st[2] = h2[2]; st[3] = Colors.a(pc); push.run(); }); px += 15; }
                button(dc, x + b[2] - 60, sy + S + 6, 50, 14, "OK", () -> overlay = null);
            }
        };
    }

    static float clamp01(float f) { return Math.max(0, Math.min(1, f)); }

    /** Scrollable read-only text overlay with an OK button. */
    public void info(String title, java.util.List<String> lines) {
        int[] sc = {0};
        overlay = new Overlay() {
            public void draw(DrawContext dc) {
                int[] b = centerBox(Math.min(W - 20, 340), Math.min(H - 20, 230));
                panel(dc, b[0], b[1], b[2], b[3]);
                text(dc, title, b[0] + 10, b[1] + 8, pal.accent());
                java.util.List<String> all = new java.util.ArrayList<>();
                for (String l : lines) all.addAll(wrap(l, b[2] - 20));
                if (all.isEmpty()) all.add(L.t("av.gui.nothing", "Nothing here"));
                int rows = Math.max(1, (b[3] - 46) / 10);
                sc[0] = Math.max(0, Math.min(sc[0], all.size() - rows));
                for (int i = 0; i < rows && i + sc[0] < all.size(); i++) text(dc, all.get(i + sc[0]), b[0] + 10, b[1] + 22 + i * 10, pal.text());
                scrollRegion(b[0], b[1], b[2], b[3], a -> sc[0] -= (int) Math.signum(a) * 3);
                button(dc, b[0] + b[2] - 70, b[1] + b[3] - 18, 60, 13, "OK", () -> overlay = null);
            }
        };
    }
}
