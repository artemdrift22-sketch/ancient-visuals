package dev.ancientvisuals.client.gui;

import dev.ancientvisuals.client.L;
import dev.ancientvisuals.core.diag.Diagnostics;
import dev.ancientvisuals.core.texture.PackWriter;
import dev.ancientvisuals.core.texture.PixelCanvas;
import dev.ancientvisuals.core.texture.PngIO;
import dev.ancientvisuals.core.util.Colors;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Path;
import java.util.List;

/** Texture Lab: load a vanilla texture, paint/fill/line/rect, colour ops, undo/redo, save into a local resource pack. */
public final class TextureLabScreen extends BaseScreen {
    private static final String[] TOOLS = {"Pencil", "Eraser", "Fill", "Picker", "Line", "Rect"};
    private static PixelCanvas canvas = new PixelCanvas(16, 16);
    private static String path = "textures/item/custom.png";
    private static final PackWriter CUSTOM = new PackWriter("Ancient Visuals · Texture Lab");
    private static int color = 0xFF2F6FD6;
    private int tool, brush, sx = -1, sy = -1, hx = -1, hy = -1;
    private boolean stroking, grid = true;
    private final Field pathField = new Field("item/diamond_sword", 96);

    public TextureLabScreen(Screen parent) {
        super("Texture Lab", parent);
        pathField.placeholder = "item/diamond_sword";
        pathField.onEnter = s -> load();
    }

    private static String norm(String s) {
        s = s.trim().toLowerCase(java.util.Locale.ROOT);
        if (s.startsWith("minecraft:")) s = s.substring(10);
        if (!s.startsWith("textures/")) s = "textures/" + s;
        if (!s.endsWith(".png")) s += ".png";
        return s;
    }

    private void load() {
        String p = norm(pathField.text());
        if (!PackWriter.validPath("assets/minecraft/" + p)) { fail(L.t("av.lab.bad_path", "Invalid texture path")); return; }
        try {
            byte[] b = ResourceHubScreen.vanilla(client, p);
            if (b == null) { fail(L.t("av.lab.not_found", "Texture not found") + ": " + p); return; }
            PixelCanvas c = PngIO.read(b);
            if (c.width() > 256 || c.height() > 256) { fail(L.t("av.lab.too_big", "Texture is larger than 256×256")); return; }
            canvas = c; path = p; ok(p + " " + c.width() + "×" + c.height());
        } catch (Exception e) { fail(String.valueOf(e.getMessage())); }
    }

    private void op(Runnable r) { canvas.checkpoint(); r.run(); }

    private void save() {
        try {
            CUSTOM.put("assets/minecraft/" + path, PngIO.encode(canvas));
            Path dir = CUSTOM.writeFolder(client.getResourcePackDir(), "ancient_visuals_lab");
            ResourceHubScreen.enableFolder(client, dir);
            ok(L.t("av.lab.saved", "Saved to pack ancient_visuals_lab") + ": " + path);
        } catch (Exception e) { Diagnostics.error("texture_lab", "save failed", e); fail(String.valueOf(e.getMessage())); }
    }

    @Override protected void draw(DrawContext dc, float delta) {
        int pw = Math.min(W - 12, 470), ph = Math.min(H - 12, 290), x = (W - pw) / 2, y = (H - ph) / 2;
        panel(dc, x, y, pw, ph);
        text(dc, title(L.t("av.tool.texture_lab", "Texture Lab")), x + 10, y + 8, pal.accent());
        button(dc, x + pw - 20, y + 5, 14, 14, "×", this::close);
        // left tools
        int lx = x + 8, lw = 120, ly = y + 22;
        field(dc, pathField, lx, ly, lw, 13);
        button(dc, lx, ly + 15, (lw - 2) / 2, 12, L.t("av.lab.load", "Load"), this::load);
        button(dc, lx + (lw + 2) / 2, ly + 15, (lw - 2) / 2, 12, L.t("av.lab.new", "New 16×16"), () -> confirm(L.t("av.lab.new_q", "Discard the current canvas?"), () -> { canvas = new PixelCanvas(16, 16); path = "textures/item/custom.png"; }));
        int ty = ly + 32;
        for (int i = 0; i < TOOLS.length; i++) { final int k = i; int bx = lx + (i % 3) * 41, by = ty + (i / 3) * 14; boolean a = tool == i; button(dc, bx, by, 39, 12, (a ? "▸" : "") + L.t("av.lab.tool." + TOOLS[i].toLowerCase(java.util.Locale.ROOT), TOOLS[i]), () -> tool = k); }
        ty += 30;
        text(dc, L.t("av.lab.brush", "Brush") + ": " + (brush * 2 + 1) + "px", lx, ty + 2, pal.text());
        button(dc, lx + lw - 30, ty, 14, 12, "−", () -> brush = Math.max(0, brush - 1));
        button(dc, lx + lw - 14, ty, 14, 12, "+", () -> brush = Math.min(4, brush + 1));
        ty += 16;
        swatch(dc, lx, ty, 26, 14, color); region(lx, ty, 26, 14, b -> colorPicker(color, true, v -> color = v));
        text(dc, Colors.toHex(color), lx + 30, ty + 3, pal.textMuted());
        ty += 18;
        List<Integer> palx = canvas.palette(16);
        for (int i = 0; i < palx.size(); i++) { int c = palx.get(i), bx = lx + (i % 8) * 15, by = ty + (i / 8) * 11; swatch(dc, bx, by, 13, 9, c); region(bx, by, 13, 9, b -> color = c); }
        ty += 24;
        Object[][] ops = {
            {L.t("av.lab.mirror_h", "Mirror ↔"), (Runnable) () -> op(canvas::mirrorHorizontal)}, {L.t("av.lab.mirror_v", "Mirror ↕"), (Runnable) () -> op(canvas::mirrorVertical)},
            {L.t("av.lab.rotate", "Rotate 90°"), (Runnable) () -> op(canvas::rotate90)}, {L.t("av.lab.gray", "Grayscale"), (Runnable) () -> op(canvas::grayscale)},
            {L.t("av.lab.contrast", "Contrast +"), (Runnable) () -> op(() -> canvas.contrast(1.2))}, {L.t("av.lab.hue", "Hue +30°"), (Runnable) () -> op(() -> canvas.adjustHsv(30f / 360f, 0, 0))},
            {L.t("av.lab.light", "Lighter"), (Runnable) () -> op(() -> canvas.adjustHsv(0, 0, 0.08f))}, {L.t("av.lab.dark", "Darker"), (Runnable) () -> op(() -> canvas.adjustHsv(0, 0, -0.08f))},
            {L.t("av.lab.tint_azure", "Tint azure"), (Runnable) () -> op(() -> canvas.tint(0xFF2F6FD6, 0.35))}, {L.t("av.lab.tint_gold", "Tint gold"), (Runnable) () -> op(() -> canvas.tint(0xFFD4A537, 0.35))},
            {L.t("av.lab.undo", "Undo"), (Runnable) canvas::undo}, {L.t("av.lab.redo", "Redo"), (Runnable) canvas::redo},
        };
        for (int i = 0; i < ops.length; i++) { int bx = lx + (i % 2) * 61, by = ty + (i / 2) * 14; if (by + 12 > y + ph - 22) break; button(dc, bx, by, 59, 12, (String) ops[i][0], (Runnable) ops[i][1]); }
        // canvas
        int cx0 = lx + lw + 10, cw = x + pw - 8 - cx0, chh = ph - 22 - 26;
        int W0 = canvas.width(), H0 = canvas.height();
        int cell = Math.max(1, Math.min(cw / W0, chh / H0));
        int ox = cx0 + (cw - cell * W0) / 2, oy = y + 22 + (chh - cell * H0) / 2;
        for (int py = 0; py < H0; py++) for (int px = 0; px < W0; px++) {
            int bx = ox + px * cell, by = oy + py * cell;
            dc.fill(bx, by, bx + cell, by + cell, ((px + py) & 1) == 0 ? 0xFF3A3F4A : 0xFF2C3038);
            int c = canvas.get(px, py);
            if (Colors.a(c) > 0) dc.fill(bx, by, bx + cell, by + cell, c);
        }
        if (grid && cell >= 6) { for (int i = 0; i <= W0; i++) dc.fill(ox + i * cell, oy, ox + i * cell + 1, oy + H0 * cell, 0x30FFFFFF); for (int i = 0; i <= H0; i++) dc.fill(ox, oy + i * cell, ox + W0 * cell, oy + i * cell + 1, 0x30FFFFFF); }
        Draw.outline(dc, ox - 1, oy - 1, W0 * cell + 2, H0 * cell + 2, t.corner(), 0, 1, pal.border());
        hx = (mx - ox) / Math.max(1, cell); hy = (my - oy) / Math.max(1, cell);
        boolean inside = mx >= ox && my >= oy && canvas.in(hx, hy);
        if (inside) dc.fill(ox + hx * cell, oy + hy * cell, ox + hx * cell + cell, oy + hy * cell + cell, 0x60FFFFFF);
        if (stroking && sx >= 0 && (tool == 4 || tool == 5) && inside) {
            int x0 = Math.min(sx, hx), y0 = Math.min(sy, hy), x1 = Math.max(sx, hx), y1 = Math.max(sy, hy);
            Draw.outline(dc, ox + x0 * cell, oy + y0 * cell, (x1 - x0 + 1) * cell, (y1 - y0 + 1) * cell, t.corner(), 0, 1, Colors.withAlpha(color, 255));
        }
        dragRegion(ox, oy, W0 * cell, H0 * cell, (px, py) -> stroke((px - ox) / Math.max(1, cell), (py - oy) / Math.max(1, cell)), null);
        int by = y + ph - 20;
        text(dc, trim(path + "  " + W0 + "×" + H0 + (inside ? "  [" + hx + "," + hy + "] " + Colors.toHex(canvas.get(hx, hy)) : ""), cw - 150), cx0, by + 3, pal.textMuted());
        button(dc, x + pw - 8 - 146, by, 70, 13, (grid ? "✓ " : "") + L.t("av.lab.grid", "Grid"), () -> grid = !grid);
        button(dc, x + pw - 8 - 72, by, 72, 13, L.t("av.lab.save", "Save to pack"), this::save);
    }

    private void stroke(int px, int py) {
        if (!canvas.in(px, py)) return;
        if (!stroking) {
            stroking = true; sx = px; sy = py;
            if (tool == 3) { color = canvas.get(px, py); return; }
            canvas.checkpoint();
            if (tool == 2) { canvas.fill(px, py, color, 0); return; }
        }
        switch (tool) {
            case 0 -> canvas.brush(px, py, brush, color);
            case 1 -> canvas.erase(px, py, brush);
            default -> { }
        }
    }

    @Override protected void onRelease(int x, int y, int b) {
        if (stroking && sx >= 0 && canvas.in(hx, hy)) {
            if (tool == 4) canvas.line(sx, sy, hx, hy, color, brush);
            else if (tool == 5) canvas.rect(sx, sy, hx, hy, color, hasShiftDown());
        }
        stroking = false; sx = sy = -1;
    }

    @Override protected boolean onKey(int key, int mods) {
        if (hasControlDown() && key == GLFW.GLFW_KEY_Z) { canvas.undo(); return true; }
        if (hasControlDown() && key == GLFW.GLFW_KEY_Y) { canvas.redo(); return true; }
        if (hasControlDown() && key == GLFW.GLFW_KEY_S) { save(); return true; }
        if (key >= GLFW.GLFW_KEY_1 && key <= GLFW.GLFW_KEY_6) { tool = key - GLFW.GLFW_KEY_1; return true; }
        if (key == GLFW.GLFW_KEY_LEFT_BRACKET) { brush = Math.max(0, brush - 1); return true; }
        if (key == GLFW.GLFW_KEY_RIGHT_BRACKET) { brush = Math.min(4, brush + 1); return true; }
        return false;
    }
}
