package dev.ancientvisuals.client.gui;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.client.L;
import dev.ancientvisuals.client.fx.Effects;
import dev.ancientvisuals.client.fx.FxEvents;
import dev.ancientvisuals.core.io.ImportValidator;
import dev.ancientvisuals.core.json.Json;
import dev.ancientvisuals.core.particle.*;
import dev.ancientvisuals.core.perf.QualityLevel;
import dev.ancientvisuals.core.util.Colors;
import dev.ancientvisuals.core.util.Easing;
import dev.ancientvisuals.core.util.Fuzzy;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.lwjgl.glfw.GLFW;

import java.util.*;
import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;

/** Particle Studio: browse 80+ effects, live 3D preview, edit every parameter, save overrides/customs, import/export. */
public final class ParticleStudioScreen extends BaseScreen {
    private final Field search = new Field("", 32);
    private EffectCategory catFilter;
    private String selId;
    private EffectDef edit;
    private final PreviewSim sim = new PreviewSim();
    private double yaw = 0.6, pitch = 0.35;
    private long lastTick, changedAt;
    private int listScroll, edScroll, loopTicks, dragLX = Integer.MIN_VALUE, dragLY;
    private boolean loop = true;
    // row cursor for the editor column
    private int ry, rIdx, rBottom, rX, rW;

    public ParticleStudioScreen(Screen parent) {
        super("Particle Studio", parent);
        search.placeholder = L.t("av.studio.search", "Search effects…");
        search.onChange = s -> listScroll = 0;
        List<String> ids = Effects.allIds();
        if (!ids.isEmpty()) select(ids.get(0));
    }

    private void select(String id) { selId = id; EffectDef d = Effects.get(id); edit = d == null ? null : d.copy(); edScroll = 0; play(); }
    private void play() { if (edit != null) { sim.clear(); sim.play(edit, System.nanoTime(), 0); loopTicks = 0; } }
    private void changed() { changedAt = System.currentTimeMillis(); }

    private List<String> filtered() {
        String q = search.text().trim();
        List<String> out = new ArrayList<>();
        for (String id : Effects.allIds()) {
            EffectDef d = Effects.get(id); if (d == null) continue;
            if (catFilter != null && d.category != catFilter) continue;
            if (!q.isEmpty() && Fuzzy.score(q, id + " " + d.name) <= 0) continue;
            out.add(id);
        }
        return out;
    }

    @Override protected void draw(DrawContext dc, float delta) {
        int pw = Math.min(W - 12, 540), ph = Math.min(H - 12, 300), x = (W - pw) / 2, y = (H - ph) / 2;
        panel(dc, x, y, pw, ph);
        text(dc, title(L.t("av.tool.particle_studio", "Particle Studio")), x + 10, y + 8, pal.accent());
        button(dc, x + pw - 20, y + 5, 14, 14, "×", this::close);
        // ---- list
        int lx = x + 8, lw = 128, ly = y + 22;
        field(dc, search, lx, ly, lw, 13);
        String cl = catFilter == null ? L.t("av.studio.all", "All categories") : pretty(catFilter.name().toLowerCase(Locale.ROOT));
        button(dc, lx, ly + 15, lw, 12, cl, () -> { EffectCategory[] v = EffectCategory.values(); int i = catFilter == null ? -1 : catFilter.ordinal(); i++; catFilter = i >= v.length ? null : v[i]; listScroll = 0; });
        List<String> ids = filtered();
        int rowsTop = ly + 30, rows = (y + ph - 8 - rowsTop) / 11;
        listScroll = Math.max(0, Math.min(listScroll, Math.max(0, ids.size() - rows)));
        for (int i = listScroll; i < ids.size() && i - listScroll < rows; i++) {
            String id = ids.get(i); EffectDef d = Effects.get(id); int iy = rowsTop + (i - listScroll) * 11;
            boolean s = id.equals(selId), hv = hover(lx, iy, lw, 11);
            if (s || hv) dc.fill(lx, iy, lx + lw, iy + 11, s ? Colors.withAlpha(pal.primary(), 130) : pal.hover());
            String mark = Effects.isCustom(id) ? "+ " : Effects.isOverridden(id) ? "• " : "";
            dc.fill(lx + 1, iy + 3, lx + 4, iy + 6, d.colorStart);
            text(dc, trim(mark + d.name, lw - 8), lx + 6, iy + 2, d.enabled ? pal.text() : pal.textMuted());
            region(lx, iy, lw, 11, b -> select(id));
        }
        scrollRegion(lx, rowsTop, lw, rows * 11, a -> listScroll -= (int) Math.signum(a) * 3);
        text(dc, ids.size() + " / " + Effects.allIds().size(), lx, y + ph - 9, pal.textMuted());
        if (edit == null) return;
        // ---- preview
        int ew = 196, vx = lx + lw + 8, vw = x + pw - 8 - ew - 6 - vx, vy = y + 22, vh = ph - 22 - 40;
        Draw.shape(dc, vx, vy, vw, vh, t.corner(), t.radius(), 0xE00A0F1A);
        long now = System.currentTimeMillis();
        if (lastTick == 0 || now - lastTick > 1000) lastTick = now;
        while (now - lastTick >= 50) { sim.tick(); lastTick += 50; loopTicks++; }
        if (changedAt > 0 && now - changedAt > 160) { changedAt = 0; play(); }
        if (loop && loopTicks > Math.max(30, edit.lifetime + edit.lifetimeVariance + 12)) play();
        double ppb = 26 * edit.previewScale; int cx = vx + vw / 2, cy = vy + vh * 2 / 3;
        for (int i = 0; i < 40; i++) { double a = i * Math.PI * 2 / 40; double[] p = PreviewSim.project(Math.cos(a) * 1.5, 0, Math.sin(a) * 1.5, yaw, pitch); dc.fill(cx + (int) (p[0] * ppb), cy + (int) (p[1] * ppb), cx + (int) (p[0] * ppb) + 1, cy + (int) (p[1] * ppb) + 1, 0x50FFFFFF); }
        List<PreviewSim.P> ps = new ArrayList<>(sim.particles());
        for (PreviewSim.P p : ps) {
            double[] pr = PreviewSim.project(p.x, p.y, p.z, yaw, pitch);
            int px = cx + (int) Math.round(pr[0] * ppb), py = cy + (int) Math.round(pr[1] * ppb);
            if (px < vx || py < vy || px >= vx + vw || py >= vy + vh || p.delay > 0) continue;
            double sz = edit.sizeStart + (edit.sizeEnd - edit.sizeStart) * p.t();
            int s = (int) Math.max(1, Math.round(sz * 2.2 * edit.previewScale));
            int a = (int) Math.round(255 * Math.max(0, Math.min(1, p.alpha() * edit.opacity)));
            if (a < 6) continue;
            dc.fill(px, py, Math.min(vx + vw, px + s), Math.min(vy + vh, py + s), Colors.withAlpha(p.color(), a));
        }
        text(dc, ps.size() + " p · " + edit.shape + " · " + edit.kind, vx + 4, vy + 4, 0xFFB8C7E0);
        text(dc, L.t("av.studio.drag", "Drag: rotate · Wheel: zoom"), vx + 4, vy + vh - 11, 0x90B8C7E0);
        dragRegion(vx, vy, vw, vh, (px, py) -> {
            if (dragLX != Integer.MIN_VALUE) { yaw += (px - dragLX) * 0.03; pitch = Math.max(-1.3, Math.min(1.3, pitch + (py - dragLY) * 0.02)); }
            dragLX = px; dragLY = py;
        }, null);
        scrollRegion(vx, vy, vw, vh, a -> edit.previewScale = Math.max(0.2, Math.min(3, edit.previewScale + Math.signum(a) * 0.1)));
        // ---- actions
        int by = vy + vh + 4, bw = (vw - 8) / 5;
        Object[][] row1 = {
            {"▶ " + L.t("av.studio.play", "Play"), (Runnable) this::play},
            {(loop ? "⟳ " : "→ ") + L.t("av.studio.loop", "Loop"), (Runnable) () -> loop = !loop},
            {L.t("av.studio.test", "Test in world"), (Runnable) () -> { if (!FxEvents.test(selId)) fail(L.t("av.studio.no_world", "Join a world first")); else if (changedAt != 0 || !same()) toast(L.t("av.studio.saved_only", "Plays the saved version — press Save first"), pal.warning()); }},
            {L.t("av.studio.save", "Save"), (Runnable) this::save},
            {L.t("av.studio.duplicate", "Duplicate"), (Runnable) () -> { EffectDef d = Effects.duplicate(selId); if (d != null) { AV.dirty(); select(d.id); ok(d.name); } }},
        };
        Object[][] row2 = {
            {L.t("av.studio.revert", "Revert edits"), (Runnable) () -> select(selId)},
            {L.t("av.studio.reset", "Reset to built-in"), (Runnable) () -> { if (!Effects.isOverridden(selId)) { toast(L.t("av.studio.not_overridden", "Not modified"), pal.textMuted()); return; } confirm(L.t("av.studio.reset_q", "Discard your changes to this effect?"), () -> { Effects.resetOverride(selId); AV.dirty(); select(selId); }); }},
            {L.t("av.studio.delete", "Delete custom"), (Runnable) () -> { if (!Effects.isCustom(selId)) { fail(L.t("av.studio.builtin", "Built-in effects cannot be deleted")); return; } confirm(L.t("av.studio.delete_q", "Delete custom effect") + " " + edit.name + "?", () -> { Effects.deleteCustom(selId); AV.dirty(); List<String> l = Effects.allIds(); select(l.get(0)); }); }},
            {L.t("av.studio.export", "Export"), (Runnable) this::export},
            {L.t("av.studio.import", "Import"), (Runnable) this::doImport},
        };
        for (int i = 0; i < row1.length; i++) button(dc, vx + i * (bw + 2), by, bw, 13, (String) row1[i][0], (Runnable) row1[i][1]);
        for (int i = 0; i < row2.length; i++) button(dc, vx + i * (bw + 2), by + 16, bw, 13, (String) row2[i][0], (Runnable) row2[i][1]);
        // ---- editor
        rX = x + pw - 8 - ew; rW = ew; ry = y + 22; rBottom = y + ph - 6; rIdx = 0;
        int top = ry;
        editor(dc);
        scrollRegion(rX, top, rW, rBottom - top, a -> edScroll = Math.max(0, edScroll - (int) Math.signum(a) * 2));
        if (rIdx - edScroll < 3) edScroll = Math.max(0, rIdx - 3);
    }

    private boolean same() { EffectDef d = Effects.get(selId); return d != null && Json.write(d.toJson(), false).equals(Json.write(edit.toJson(), false)); }

    private void save() {
        List<String> issues = edit.validate();
        Effects.save(edit.copy()); AV.dirty();
        if (issues != null && !issues.isEmpty()) toast(L.t("av.studio.adjusted", "Saved; adjusted: ") + String.join(", ", issues), pal.warning()); else ok(L.t("av.studio.saved", "Saved") + ": " + edit.name);
    }

    private void export() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("kind", "ancientvisuals.effect"); m.put("version", 1); m.put("effect", edit.toJson());
        client.keyboard.setClipboard(Json.write(m, true));
        ok(L.t("av.gui.copied", "Copied"));
    }

    @SuppressWarnings("unchecked")
    private void doImport() {
        String s = client.keyboard.getClipboard();
        if (s == null || s.isBlank() || s.length() > ImportValidator.MAX_IMPORT) { fail(L.t("av.gui.bad_clipboard", "Clipboard has no valid data")); return; }
        try {
            Object o = Json.parse(s);
            if (!(o instanceof Map<?, ?> m) || !"ancientvisuals.effect".equals(m.get("kind")) || !(m.get("effect") instanceof Map<?, ?> e)) { fail(L.t("av.studio.not_effect", "Not an Ancient Visuals effect")); return; }
            EffectDef d = new EffectDef("imported", "Imported", EffectCategory.MAGIC, EmitterShape.values()[0], ParticleKind.values()[0]);
            d.fromJson((Map<String, Object>) e);
            if (d.id == null || !d.id.matches("[a-z0-9_]{1,48}")) d.id = "custom_" + Long.toString(System.currentTimeMillis() % 1_000_000L, 36);
            if (EffectCatalog.get(d.id) == null && Effects.isCustom(d.id) == false && Effects.get(d.id) != null) d.id = d.id + "_imp";
            Effects.save(d); AV.dirty(); select(d.id); ok(L.t("av.studio.imported", "Imported") + ": " + d.name);
        } catch (RuntimeException ex) { fail(L.t("av.studio.not_effect", "Not an Ancient Visuals effect")); }
    }

    // ------------------------------------------------------------------ editor rows
    private boolean row(int h) { int idx = rIdx++; return idx >= edScroll && ry + h <= rBottom; }

    private void head(DrawContext dc, String s) { if (!row(12)) return; header(dc, s, rX, ry + 3, rW); ry += 12; }

    private void num(DrawContext dc, String label, double v, double min, double max, double step, DoubleConsumer set) {
        int h = rowH(); if (!row(h)) return;
        if (hover(rX, ry, rW, h)) dc.fill(rX, ry, rX + rW, ry + h, Colors.withAlpha(pal.hover(), 90));
        text(dc, trim(label, rW / 2 - 4), rX + 2, ry + (h - 8) / 2, pal.text());
        String val = step >= 1 ? String.valueOf(Math.round(v)) : String.format(Locale.ROOT, step >= 0.01 ? "%.2f" : "%.3f", v);
        DoubleConsumer s2 = val2 -> { set.accept(Math.round(Math.max(min, Math.min(max, val2)) / step) * step); changed(); };
        slider(dc, rX + rW / 2, ry, rW / 2 - 2, h, (v - min) / (max - min), val, f -> s2.accept(min + Math.max(0, Math.min(1, f)) * (max - min)), d -> s2.accept(v + d * step), null);
        ry += h;
    }

    private void choice(DrawContext dc, String label, String value, IntConsumer cycle) {
        int h = rowH(); if (!row(h)) return;
        boolean hv = hover(rX, ry, rW, h);
        text(dc, trim(label, rW / 2 - 4), rX + 2, ry + (h - 8) / 2, pal.text());
        valueBox(dc, rX + rW / 2, ry, rW / 2 - 2, h, value, hv);
        final int yy = ry;
        region(rX + rW / 2, ry, rW / 2 - 2, h, b -> { cycle.accept(b == 1 || mx < rX + rW / 2 + rW / 6 ? -1 : 1); changed(); });
        scrollRegion(rX + rW / 2, yy, rW / 2 - 2, h, a -> { cycle.accept(a > 0 ? -1 : 1); changed(); });
        ry += h;
    }

    private void bool(DrawContext dc, String label, boolean v, Runnable toggle) {
        int h = rowH(); if (!row(h)) return;
        text(dc, trim(label, rW - 30), rX + 2, ry + (h - 8) / 2, pal.text());
        toggleGfx(dc, rX + rW - 22, ry + (h - 9) / 2, v);
        region(rX, ry, rW, h, b -> { toggle.run(); changed(); });
        ry += h;
    }

    private void color(DrawContext dc, String label, int c, IntConsumer set) {
        int h = rowH(); if (!row(h)) return;
        text(dc, label, rX + 2, ry + (h - 8) / 2, pal.text());
        swatch(dc, rX + rW - 34, ry + 2, 30, h - 4, c);
        text(dc, Colors.toHex(c), rX + rW - 40 - tw(Colors.toHex(c)), ry + (h - 8) / 2, pal.textMuted());
        region(rX, ry, rW, h, b -> colorPicker(c, true, v -> { set.accept(v); changed(); }));
        ry += h;
    }

    private static <E extends Enum<E>> E cyc(Class<E> c, E v, int dir, boolean nullable) {
        E[] a = c.getEnumConstants(); int n = a.length + (nullable ? 1 : 0);
        int i = v == null ? a.length : v.ordinal();
        i = Math.floorMod(i + dir, n);
        return i >= a.length ? null : a[i];
    }
    private static String en(Enum<?> e) { return e == null ? "—" : pretty(e.name().toLowerCase(Locale.ROOT)); }

    private void editor(DrawContext dc) {
        EffectDef d = edit;
        head(dc, d.name + "  (" + d.id + ")");
        bool(dc, L.t("av.studio.f.enabled", "Enabled"), d.enabled, () -> d.enabled = !d.enabled);
        choice(dc, L.t("av.studio.f.category", "Category"), en(d.category), k -> d.category = cyc(EffectCategory.class, d.category, k, false));
        choice(dc, L.t("av.studio.f.trigger", "Trigger"), en(d.trigger), k -> d.trigger = cyc(Trigger.class, d.trigger, k, false));
        head(dc, L.t("av.studio.g.shape", "Shape"));
        choice(dc, L.t("av.studio.f.shape", "Emitter"), en(d.shape), k -> d.shape = cyc(EmitterShape.class, d.shape, k, false));
        choice(dc, L.t("av.studio.f.kind", "Particle"), en(d.kind), k -> d.kind = cyc(ParticleKind.class, d.kind, k, false));
        choice(dc, L.t("av.studio.f.kind2", "Secondary"), en(d.kind2), k -> d.kind2 = cyc(ParticleKind.class, d.kind2, k, true));
        num(dc, L.t("av.studio.f.secondary", "Secondary ratio"), d.secondaryRatio, 0, 1, 0.05, v -> d.secondaryRatio = v);
        num(dc, L.t("av.studio.f.turns", "Turns"), d.turns, 1, 12, 1, v -> d.turns = (int) v);
        num(dc, L.t("av.studio.f.height", "Height"), d.height, 0, 5, 0.05, v -> d.height = v);
        num(dc, L.t("av.studio.f.spread", "Spread"), d.spread, 0, 5, 0.05, v -> d.spread = v);
        head(dc, L.t("av.studio.g.emission", "Emission"));
        bool(dc, L.t("av.studio.f.burst", "Burst"), d.burst, () -> d.burst = !d.burst);
        num(dc, L.t("av.studio.f.count", "Count"), d.count, 1, 400, 1, v -> d.count = (int) v);
        num(dc, L.t("av.studio.f.rate", "Rate / s"), d.rate, 0, 60, 0.5, v -> d.rate = v);
        num(dc, L.t("av.studio.f.lifetime", "Lifetime (ticks)"), d.lifetime, 1, 200, 1, v -> d.lifetime = (int) v);
        num(dc, L.t("av.studio.f.variance", "Lifetime variance"), d.lifetimeVariance, 0, 100, 1, v -> d.lifetimeVariance = (int) v);
        num(dc, L.t("av.studio.f.max", "Max particles"), d.maxCount, 1, 2000, 1, v -> d.maxCount = (int) v);
        head(dc, L.t("av.studio.g.look", "Look"));
        color(dc, L.t("av.studio.f.color_start", "Start colour"), d.colorStart, v -> d.colorStart = v);
        color(dc, L.t("av.studio.f.color_end", "End colour"), d.colorEnd, v -> d.colorEnd = v);
        bool(dc, L.t("av.studio.f.random_color", "Random colour"), d.randomColor, () -> d.randomColor = !d.randomColor);
        num(dc, L.t("av.studio.f.size_start", "Start size"), d.sizeStart, 0.05, 4, 0.05, v -> d.sizeStart = v);
        num(dc, L.t("av.studio.f.size_end", "End size"), d.sizeEnd, 0, 4, 0.05, v -> d.sizeEnd = v);
        num(dc, L.t("av.studio.f.alpha_start", "Start alpha"), d.alphaStart, 0, 1, 0.05, v -> d.alphaStart = v);
        num(dc, L.t("av.studio.f.alpha_end", "End alpha"), d.alphaEnd, 0, 1, 0.05, v -> d.alphaEnd = v);
        choice(dc, L.t("av.studio.f.alpha_curve", "Alpha curve"), en(d.alphaCurve), k -> d.alphaCurve = cyc(Easing.class, d.alphaCurve, k, false));
        num(dc, L.t("av.studio.f.opacity", "Opacity"), d.opacity, 0, 1, 0.05, v -> d.opacity = v);
        num(dc, L.t("av.studio.f.scale", "Scale"), d.scale, 0.25, 3, 0.05, v -> d.scale = v);
        bool(dc, L.t("av.studio.f.trail", "Trail"), d.trail, () -> d.trail = !d.trail);
        head(dc, L.t("av.studio.g.motion", "Motion"));
        num(dc, L.t("av.studio.f.speed", "Speed"), d.speed, 0, 1.5, 0.01, v -> d.speed = v);
        num(dc, L.t("av.studio.f.accel", "Acceleration"), d.acceleration, -0.2, 0.2, 0.005, v -> d.acceleration = v);
        num(dc, L.t("av.studio.f.gravity", "Gravity"), d.gravity, -0.1, 0.1, 0.002, v -> d.gravity = v);
        num(dc, L.t("av.studio.f.drag", "Drag"), d.drag, 0.5, 1, 0.01, v -> d.drag = v);
        num(dc, L.t("av.studio.f.rotation", "Rotation"), d.rotation, 0, 6.28, 0.05, v -> d.rotation = v);
        num(dc, L.t("av.studio.f.spin", "Angular velocity"), d.angularVelocity, -0.5, 0.5, 0.01, v -> d.angularVelocity = v);
        num(dc, L.t("av.studio.f.jitter", "Direction jitter"), d.directionJitter, 0, 1, 0.01, v -> d.directionJitter = v);
        bool(dc, L.t("av.studio.f.collides", "Collides with blocks"), d.collides, () -> d.collides = !d.collides);
        head(dc, L.t("av.studio.g.performance", "Performance"));
        choice(dc, L.t("av.studio.f.min_quality", "Min quality"), en(d.minQuality), k -> d.minQuality = cyc(QualityLevel.class, d.minQuality, k, false));
        num(dc, L.t("av.studio.f.lod", "LOD distance"), d.lodDistance, 4, 128, 1, v -> d.lodDistance = v);
        num(dc, L.t("av.studio.f.preview", "Preview zoom"), d.previewScale, 0.2, 3, 0.1, v -> d.previewScale = v);
    }

    @Override protected void onRelease(int x, int y, int b) { dragLX = Integer.MIN_VALUE; }
    @Override protected boolean onKey(int key, int mods) {
        if (key == GLFW.GLFW_KEY_SPACE) { play(); return true; }
        if (key == GLFW.GLFW_KEY_S && hasControlDown()) { save(); return true; }
        if (key == GLFW.GLFW_KEY_F && hasControlDown()) { focus = search; return true; }
        if (key == GLFW.GLFW_KEY_DOWN || key == GLFW.GLFW_KEY_UP) {
            List<String> l = filtered(); if (l.isEmpty()) return true;
            int i = Math.floorMod(l.indexOf(selId) + (key == GLFW.GLFW_KEY_DOWN ? 1 : -1), l.size()); select(l.get(i)); return true;
        }
        return false;
    }
}
