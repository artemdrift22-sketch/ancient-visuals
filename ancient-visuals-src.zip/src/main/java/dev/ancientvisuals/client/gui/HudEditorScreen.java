package dev.ancientvisuals.client.gui;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.client.L;
import dev.ancientvisuals.client.hud.HudElement;
import dev.ancientvisuals.client.hud.HudRenderer;
import dev.ancientvisuals.core.hud.HudBox;
import dev.ancientvisuals.core.hud.HudLayout;
import dev.ancientvisuals.core.theme.CornerStyle;
import dev.ancientvisuals.core.util.Colors;
import dev.ancientvisuals.core.util.UndoStack;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.lwjgl.glfw.GLFW;

import java.util.*;

/** Visual HUD editor: drag, snap, guides, grid, multi-select, align, groups, undo/redo, named layouts. */
public final class HudEditorScreen extends BaseScreen {
    private final List<HudElement> sel = new ArrayList<>();
    private final UndoStack<String> undo = new UndoStack<>(80);
    private boolean grid = true, snap = true, showAll = false;
    private final int gridSize = 4;
    private HudElement grabbed; private double grabDX, grabDY; private boolean moved; private String pending;
    private List<HudLayout.Guide> guides = List.of();
    private double[] styleClip;
    private double g = 1, sw, sh;

    public HudEditorScreen(Screen parent) { super("HUD Editor", parent); }
    @Override protected float uiScale() { return 1f; }
    @Override protected double dim() { return 0.12; }

    private boolean shown(HudElement e) { return e.isEnabled() || showAll; }
    private double vx() { return mx / g; }
    private double vy() { return my / g; }

    private HudElement pick(double x, double y) {
        List<HudElement> l = HudRenderer.elements;
        for (int i = l.size() - 1; i >= 0; i--) {
            HudElement e = l.get(i); if (!shown(e)) continue;
            HudBox b = e.box; double bx = b.x(sw), by = b.y(sh);
            if (x >= bx - 1 && y >= by - 1 && x <= bx + b.scaledW() + 1 && y <= by + b.scaledH() + 1) return e;
        }
        return null;
    }

    private Set<HudBox> moving() {
        Set<HudBox> s = new LinkedHashSet<>();
        for (HudElement e : sel) { s.add(e.box); if (!e.box.group.isEmpty()) for (HudElement o : HudRenderer.elements) if (e.box.group.equals(o.box.group)) s.add(o.box); }
        return s;
    }
    private List<HudBox> selBoxes() { List<HudBox> l = new ArrayList<>(); for (HudElement e : sel) l.add(e.box); return l; }
    private void checkpoint() { undo.push(AV.layout.serialize()); }

    @Override protected void draw(DrawContext dc, float delta) {
        g = HudRenderer.scale();
        double[] vs = HudRenderer.virtualSize(dc); sw = vs[0]; sh = vs[1];
        if (grid) {
            int step = (int) Math.max(2, Math.round(gridSize * 4 * g));
            for (int x = 0; x < W; x += step) dc.fill(x, 0, x + 1, H, 0x12FFFFFF);
            for (int y = 0; y < H; y += step) dc.fill(0, y, W, y + 1, 0x12FFFFFF);
            dc.fill(W / 2, 0, W / 2 + 1, H, 0x30FFFFFF); dc.fill(0, H / 2, W, H / 2 + 1, 0x30FFFFFF);
        }
        int m = (int) Math.round(AV.hud.safeArea.i() * g);
        if (m > 0) Draw.outline(dc, m, m, W - 2 * m, H - 2 * m, CornerStyle.SQUARE, 0, 1, 0x40FFD27A);
        HudRenderer.drawAll(dc, client, delta, true, this::shown);

        List<HudBox> vis = new ArrayList<>();
        for (HudElement e : HudRenderer.elements) if (shown(e)) vis.add(e.box);
        Set<String> over = new HashSet<>();
        for (String[] p : AV.layout.overlaps(vis, sw, sh)) { over.add(p[0]); over.add(p[1]); }
        HudElement hov = overlay == null ? pick(vx(), vy()) : null;
        var mat = dc.getMatrices();
        mat.push(); mat.scale((float) g, (float) g, 1f);
        for (HudElement e : HudRenderer.elements) {
            if (!shown(e)) continue;
            HudBox b = e.box;
            int x = (int) Math.round(b.x(sw)), y = (int) Math.round(b.y(sh)), w = (int) Math.ceil(b.scaledW()), h = (int) Math.ceil(b.scaledH());
            int col = sel.contains(e) ? pal.accent() : over.contains(e.id()) ? pal.error() : !e.isEnabled() ? 0x60FFFFFF : e == hov ? pal.text() : Colors.withAlpha(pal.border(), 170);
            Draw.outline(dc, x - 1, y - 1, w + 2, h + 2, CornerStyle.SQUARE, 0, 1, col);
            if (!b.group.isEmpty()) dc.fill(x - 1, y - 1, x + 3, y + 3, pal.secondary());
            if (e == hov || sel.contains(e)) {
                String lab = L.module(e) + (b.group.isEmpty() ? "" : "  [" + b.group + "]") + "  " + Math.round(b.scale * 100) + "%";
                int ly = y - 10 < 0 ? y + h + 2 : y - 10;
                dc.fill(x - 1, ly - 1, x + tw(lab) + 3, ly + 9, 0xC0101826);
                dc.drawText(textRenderer, lab, x + 1, ly, 0xFFFFFFFF, false);
            }
        }
        for (HudLayout.Guide gd : guides) {
            if (gd.vertical()) dc.fill(gd.pos(), 0, gd.pos() + 1, (int) sh, pal.accent());
            else dc.fill(0, gd.pos(), (int) sw, gd.pos() + 1, pal.accent());
        }
        mat.pop();
        if (hov != null && grabbed == null) tip(L.moduleDesc(hov));
        toolbar(dc);
        String help = L.t("av.editor.help", "Drag · Shift: multi-select · Wheel: scale (Shift: opacity) · Alt: no snap · Arrows: nudge · Del: hide · Ctrl+Z/Y · Ctrl+C/V style");
        int hw = tw(help) + 10;
        dc.fill(W / 2 - hw / 2, H - 14, W / 2 + hw / 2, H - 2, 0xA0101826);
        textC(dc, help, W / 2, H - 12, 0xFFDDE6F5);
        if (!over.isEmpty()) textC(dc, L.t("av.editor.overlap", "Red outline: elements overlap"), W / 2, H - 26, pal.error());
    }

    private void toolbar(DrawContext dc) {
        List<Object[]> b = new ArrayList<>();
        b.add(new Object[]{(grid ? "▦ " : "□ ") + L.t("av.editor.grid", "Grid"), (Runnable) () -> grid = !grid});
        b.add(new Object[]{(snap ? "⌖ " : "○ ") + L.t("av.editor.snap", "Snap"), (Runnable) () -> snap = !snap});
        b.add(new Object[]{(showAll ? "◉ " : "◎ ") + L.t("av.editor.all", "All"), (Runnable) () -> showAll = !showAll});
        b.add(new Object[]{"↶", (Runnable) this::doUndo});
        b.add(new Object[]{"↷", (Runnable) this::doRedo});
        b.add(new Object[]{L.t("av.editor.align", "Align") + " ▾", (Runnable) this::alignMenu});
        b.add(new Object[]{L.t("av.editor.group", "Group") + " ▾", (Runnable) this::groupMenu});
        b.add(new Object[]{L.t("av.editor.layouts", "Layouts") + " ▾", (Runnable) this::layoutMenu});
        b.add(new Object[]{L.t("av.editor.elements", "Elements") + " ▾", (Runnable) this::elementsPicker});
        b.add(new Object[]{L.t("av.gui.done", "Done"), (Runnable) this::close});
        int total = 0; for (Object[] o : b) total += tw((String) o[0]) + 12;
        total += tw(L.t("av.gui.reset_short", "Reset")) + 12;
        int x = W / 2 - total / 2, y = 4;
        Draw.shape(dc, x - 4, y - 2, total + 8, 18, t.corner(), Math.min(4, t.radius()), Colors.withAlpha(pal.surface(), 225));
        for (Object[] o : b) { String s = (String) o[0]; int w = tw(s) + 10; button(dc, x, y, w, 14, s, (Runnable) o[1]); x += w + 2; }
        String rs = L.t("av.gui.reset_short", "Reset");
        danger(dc, x, y, tw(rs) + 10, 14, rs, L.t("av.editor.reset_q", "Reset every HUD element to its default position?"), () -> { checkpoint(); AV.layout.reset(); sel.clear(); });
    }

    private void doUndo() { String p = undo.undo(AV.layout.serialize()); if (p != null) AV.layout.deserialize(p); else toast(L.t("av.editor.nothing_undo", "Nothing to undo"), pal.textMuted()); }
    private void doRedo() { String p = undo.redo(AV.layout.serialize()); if (p != null) AV.layout.deserialize(p); }

    private void alignMenu() {
        if (sel.isEmpty()) { fail(L.t("av.editor.select_first", "Select elements first")); return; }
        List<MenuItem> items = new ArrayList<>();
        for (String mode : List.of("left", "center", "right", "top", "bottom"))
            items.add(new MenuItem(L.t("av.editor.align." + mode, pretty(mode)), () -> { checkpoint(); AV.layout.align(selBoxes(), mode, sw, sh); }));
        items.add(new MenuItem(L.t("av.editor.distribute", "Distribute vertically"), () -> { checkpoint(); AV.layout.distributeVertically(selBoxes(), 2, sw, sh); }));
        items.add(new MenuItem(L.t("av.editor.same_scale", "Same scale as first"), () -> { checkpoint(); double s = sel.get(0).box.scale; for (HudBox b : selBoxes()) b.scale = s; }));
        menu(mx, 22, items);
    }

    private void groupMenu() {
        List<MenuItem> items = new ArrayList<>();
        items.add(new MenuItem(L.t("av.editor.group_new", "Group selection…"), () -> {
            if (sel.size() < 2) { fail(L.t("av.editor.select_two", "Select at least two elements")); return; }
            prompt(L.t("av.editor.group_name", "Group name"), "group" + (1 + sel.size()), 24, n -> { checkpoint(); for (HudBox b : selBoxes()) b.group = n; });
        }));
        items.add(new MenuItem(L.t("av.editor.ungroup", "Ungroup selection"), () -> { checkpoint(); for (HudBox b : moving()) b.group = ""; }));
        menu(mx, 22, items);
    }

    private void layoutMenu() {
        List<MenuItem> items = new ArrayList<>();
        items.add(new MenuItem(L.t("av.editor.save_as", "Save current as…"), () -> prompt(L.t("av.editor.layout_name", "Layout name"), "My layout", 32, n -> { AV.ui.layouts.put(n, AV.layout.serialize()); AV.dirty(); ok(n); })));
        items.add(new MenuItem(L.t("av.editor.copy_layout", "Copy layout to clipboard"), () -> { client.keyboard.setClipboard(AV.layout.serialize()); ok(L.t("av.gui.copied", "Copied")); }));
        items.add(new MenuItem(L.t("av.editor.paste_layout", "Paste layout from clipboard"), () -> {
            String s = client.keyboard.getClipboard();
            if (s == null || s.length() > 256 * 1024 || !s.trim().startsWith("{")) { fail(L.t("av.gui.bad_clipboard", "Clipboard has no valid data")); return; }
            checkpoint(); AV.layout.deserialize(s);
        }));
        for (String name : new ArrayList<>(AV.ui.layouts.keySet())) {
            items.add(new MenuItem("▸ " + name, () -> { checkpoint(); AV.layout.deserialize(AV.ui.layouts.get(name)); ok(name); }));
            items.add(new MenuItem("   ✕ " + name, () -> confirm(L.t("av.editor.delete_layout", "Delete layout") + " " + name + "?", () -> { AV.ui.layouts.remove(name); AV.dirty(); })));
        }
        menu(mx, 22, items);
    }

    private void elementsPicker() {
        List<String> ids = new ArrayList<>(); for (HudElement e : HudRenderer.elements) ids.add(e.id());
        pick(L.t("av.editor.elements", "Elements") + " (" + ids.size() + ")", ids, id -> { HudElement e = HudRenderer.byId(id); return (e.isEnabled() ? "✓ " : "   ") + L.module(e); }, id -> { HudElement e = HudRenderer.byId(id); if (e != null) { e.toggle(); elementsPicker(); } }, null);
    }

    private void contextMenu(HudElement e) {
        List<MenuItem> items = new ArrayList<>();
        items.add(new MenuItem(L.t("av.editor.hide", "Hide element"), () -> { for (HudElement s : sel) s.setEnabled(false); sel.clear(); }));
        items.add(new MenuItem(L.t("av.editor.reset_pos", "Reset position"), () -> { checkpoint(); for (HudElement s : sel) AV.layout.resetBox(s.id()); }));
        items.add(new MenuItem(L.t("av.editor.bg", "Toggle background"), () -> { for (HudElement s : sel) s.background.toggle(); }));
        items.add(new MenuItem(L.t("av.editor.scale100", "Scale 100%"), () -> { checkpoint(); for (HudBox b : selBoxes()) b.scale = 1; }));
        items.add(new MenuItem(L.t("av.editor.opacity100", "Opacity 100%"), () -> { checkpoint(); for (HudBox b : selBoxes()) b.opacity = 1; }));
        items.add(new MenuItem(L.t("av.editor.settings", "Element settings…"), () -> AV.open(new ClickGuiScreen(this, e.id()))));
        menu(mx, my, items);
    }

    @Override protected boolean onEmptyClick(int x, int y, int button) {
        HudElement hit = pick(vx(), vy());
        if (hit == null) { if (!hasShiftDown()) sel.clear(); return true; }
        if (button == 1) { if (!sel.contains(hit)) { sel.clear(); sel.add(hit); } contextMenu(hit); return true; }
        if (button != 0) return true;
        if (hasShiftDown()) { if (!sel.remove(hit)) sel.add(hit); }
        else if (!sel.contains(hit)) { sel.clear(); sel.add(hit); }
        if (!sel.contains(hit)) return true;
        grabbed = hit; grabDX = vx() - hit.box.x(sw); grabDY = vy() - hit.box.y(sh); moved = false; pending = AV.layout.serialize();
        return true;
    }

    @Override protected boolean onDrag(int x, int y, int button) {
        if (grabbed == null || button != 0) return false;
        double nx = x / g - grabDX, ny = y / g - grabDY;
        Set<HudBox> mv = moving();
        if (snap && !hasAltDown()) {
            List<HudBox> others = new ArrayList<>();
            for (HudElement e : HudRenderer.elements) if (shown(e) && !mv.contains(e.box)) others.add(e.box);
            HudLayout.SnapResult r = AV.layout.snap(grabbed.box, nx, ny, sw, sh, grid ? gridSize : 0, 4, others);
            nx = r.x(); ny = r.y(); guides = r.guides();
        } else guides = List.of();
        double dx = nx - grabbed.box.x(sw), dy = ny - grabbed.box.y(sh);
        if (dx == 0 && dy == 0) return true;
        if (!moved) { undo.push(pending); moved = true; }
        for (HudBox b : mv) b.setTopLeft(b.x(sw) + dx, b.y(sh) + dy, sw, sh);
        return true;
    }

    @Override protected void onRelease(int x, int y, int button) { grabbed = null; guides = List.of(); }

    @Override protected boolean onScroll(int x, int y, double v) {
        HudElement hit = pick(vx(), vy());
        if (hit == null) return false;
        List<HudBox> targets = sel.contains(hit) ? selBoxes() : List.of(hit.box);
        checkpoint();
        for (HudBox b : targets) {
            if (hasShiftDown()) b.opacity = Math.max(0.1, Math.min(1, b.opacity + Math.signum(v) * 0.05));
            else { double bx = b.x(sw), by = b.y(sh); b.scale = Math.max(0.3, Math.min(4, Math.round((b.scale + Math.signum(v) * 0.05) * 100) / 100.0)); b.setTopLeft(bx, by, sw, sh); }
        }
        return true;
    }

    @Override protected boolean onKey(int key, int mods) {
        boolean ctrl = hasControlDown();
        if (ctrl && key == GLFW.GLFW_KEY_Z) { if (hasShiftDown()) doRedo(); else doUndo(); return true; }
        if (ctrl && key == GLFW.GLFW_KEY_Y) { doRedo(); return true; }
        if (ctrl && key == GLFW.GLFW_KEY_A) { sel.clear(); for (HudElement e : HudRenderer.elements) if (shown(e)) sel.add(e); return true; }
        if (ctrl && key == GLFW.GLFW_KEY_C && !sel.isEmpty()) { HudBox b = sel.get(0).box; styleClip = new double[]{b.scale, b.opacity, sel.get(0).background.on() ? 1 : 0}; ok(L.t("av.editor.style_copied", "Style copied")); return true; }
        if (ctrl && key == GLFW.GLFW_KEY_V && styleClip != null) { checkpoint(); for (HudElement e : sel) { e.box.scale = styleClip[0]; e.box.opacity = styleClip[1]; e.background.set(styleClip[2] > 0); } return true; }
        if (key == GLFW.GLFW_KEY_G && !ctrl) { grid = !grid; return true; }
        if ((key == GLFW.GLFW_KEY_DELETE || key == GLFW.GLFW_KEY_BACKSPACE) && !sel.isEmpty()) { for (HudElement e : sel) e.setEnabled(false); sel.clear(); return true; }
        int dx = key == GLFW.GLFW_KEY_LEFT ? -1 : key == GLFW.GLFW_KEY_RIGHT ? 1 : 0, dy = key == GLFW.GLFW_KEY_UP ? -1 : key == GLFW.GLFW_KEY_DOWN ? 1 : 0;
        if ((dx != 0 || dy != 0) && !sel.isEmpty()) {
            int step = hasShiftDown() ? 10 : 1;
            checkpoint();
            for (HudBox b : moving()) b.setTopLeft(b.x(sw) + dx * step, b.y(sh) + dy * step, sw, sh);
            return true;
        }
        return false;
    }

    @Override protected void onClosed() { AV.dirty(); }
}
