package dev.ancientvisuals.client.gui;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.client.L;
import dev.ancientvisuals.core.diag.Diagnostics;
import dev.ancientvisuals.core.texture.*;
import dev.ancientvisuals.core.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.resource.InputSupplier;
import net.minecraft.resource.ResourcePackManager;
import net.minecraft.resource.ResourcePackProfile;
import net.minecraft.resource.ResourceType;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** Resource Pack Hub: enable/disable/apply packs, generate themed GUI packs from vanilla textures, inspect packs and conflicts. */
public final class ResourceHubScreen extends BaseScreen {
    private int scroll, rScroll;
    private boolean pending;

    public ResourceHubScreen(Screen parent) { super("Resource Pack Hub", parent); }

    private ResourcePackManager mgr() { return client.getResourcePackManager(); }

    private void apply() { client.options.refreshResourcePacks(mgr()); pending = false; UiSoundsBridge.ok(); }

    @Override protected void onClosed() { if (pending) client.options.refreshResourcePacks(mgr()); }

    @Override protected void draw(DrawContext dc, float delta) {
        int pw = Math.min(W - 12, 480), ph = Math.min(H - 12, 290), x = (W - pw) / 2, y = (H - ph) / 2;
        panel(dc, x, y, pw, ph);
        text(dc, title(L.t("av.tool.resource_hub", "Resource Pack Hub")), x + 10, y + 8, pal.accent());
        button(dc, x + pw - 20, y + 5, 14, 14, "×", this::close);
        int lw = (pw - 24) * 3 / 5, lx = x + 8, ly = y + 22, rx = lx + lw + 8, rw = x + pw - 8 - rx;
        ResourcePackManager m = mgr();
        List<ResourcePackProfile> all = new ArrayList<>(m.getProfiles());
        Collection<String> en = m.getEnabledIds();
        all.sort(Comparator.comparing((ResourcePackProfile p) -> !en.contains(p.getId())).thenComparing(p -> p.getDisplayName().getString().toLowerCase(Locale.ROOT)));
        header(dc, L.t("av.hub.packs", "Packs") + " (" + en.size() + " / " + all.size() + ")", lx, ly, lw);
        int rh = 16, top = ly + 12, rows = (y + ph - 40 - top) / rh;
        scroll = Math.max(0, Math.min(scroll, Math.max(0, all.size() - rows)));
        for (int i = scroll; i < all.size() && i - scroll < rows; i++) {
            ResourcePackProfile p = all.get(i); int iy = top + (i - scroll) * rh;
            boolean on = en.contains(p.getId()), req = p.isRequired();
            if (hover(lx, iy, lw, rh)) dc.fill(lx, iy, lx + lw, iy + rh, Colors.withAlpha(pal.hover(), 110));
            if (req) text(dc, "◆", lx + 6, iy + 4, pal.textMuted()); else toggleGfx(dc, lx + 2, iy + 3, on);
            text(dc, trim(p.getDisplayName().getString(), lw - 34), lx + 28, iy + 1, on ? pal.text() : pal.textMuted());
            text(dc, trim(p.getDescription().getString(), lw - 34), lx + 28, iy + 8, Colors.withAlpha(pal.textMuted(), 180));
            if (!req) region(lx, iy, lw, rh, b -> { if (en.contains(p.getId())) m.disable(p.getId()); else m.enable(p.getId()); pending = true; });
        }
        scrollRegion(lx, top, lw, rows * rh, a -> scroll -= (int) Math.signum(a) * 2);
        // right: generator directions
        header(dc, L.t("av.hub.generate", "Generate GUI pack"), rx, ly, rw);
        int gt = ly + 12, grows = (y + ph - 40 - gt) / 12;
        List<GuiRecipes.Recipe> rs = GuiRecipes.ALL;
        rScroll = Math.max(0, Math.min(rScroll, Math.max(0, rs.size() - grows)));
        for (int i = rScroll; i < rs.size() && i - rScroll < grows; i++) {
            GuiRecipes.Recipe r = rs.get(i); int iy = gt + (i - rScroll) * 12;
            boolean hv = hover(rx, iy, rw, 12);
            if (hv) dc.fill(rx, iy, rx + rw, iy + 12, Colors.withAlpha(pal.hover(), 110));
            int[] ramp = r.ramp();
            for (int k = 0; k < Math.min(4, ramp.length); k++) dc.fill(rx + 2 + k * 5, iy + 3, rx + 6 + k * 5, iy + 9, ramp[k]);
            text(dc, trim(r.name(), rw - 30), rx + 26, iy + 2, pal.text());
            region(rx, iy, rw, 12, b -> confirm(L.t("av.hub.generate_q", "Generate and enable the pack") + " \"" + r.name() + "\"? (" + GuiRecipes.TARGETS.size() + " GUI textures)", () -> generate(r)));
        }
        scrollRegion(rx, gt, rw, grows * 12, a -> rScroll -= (int) Math.signum(a) * 2);
        int by = y + ph - 34, bw = (pw - 16 - 8) / 3;
        button(dc, x + 8, by, bw, 13, (pending ? "● " : "") + L.t("av.hub.apply", "Apply & reload"), this::apply);
        button(dc, x + 12 + bw, by, bw, 13, L.t("av.hub.refresh", "Rescan folder"), () -> { m.scanPacks(); ok("✓"); });
        button(dc, x + 16 + 2 * bw, by, bw, 13, L.t("av.hub.open", "Open packs folder"), () -> Util.getOperatingSystem().open(client.getResourcePackDir().toUri()));
        button(dc, x + 8, by + 16, bw, 13, L.t("av.hub.inspect", "Inspect packs & conflicts"), this::inspect);
        button(dc, x + 12 + bw, by + 16, bw, 13, L.t("av.tool.texture_lab", "Texture Lab"), () -> AV.open(new TextureLabScreen(this)));
        text(dc, L.t("av.hub.hint", "Generated packs are normal folders in resourcepacks/"), x + 16 + 2 * bw, by + 19, pal.textMuted());
    }

    static byte[] vanilla(MinecraftClient mc, String path) throws IOException {
        InputSupplier<InputStream> s = mc.getDefaultResourcePack().open(ResourceType.CLIENT_RESOURCES, Identifier.ofVanilla(path));
        if (s == null) return null;
        try (InputStream in = s.get()) { return in.readAllBytes(); }
    }

    static void enableFolder(MinecraftClient mc, Path dir) {
        ResourcePackManager m = mc.getResourcePackManager();
        m.scanPacks();
        m.enable("file/" + dir.getFileName().toString());
        mc.options.refreshResourcePacks(m);
    }

    private void generate(GuiRecipes.Recipe r) {
        PackWriter w = new PackWriter("Ancient Visuals · " + r.name());
        int done = 0, missing = 0;
        for (String path : GuiRecipes.TARGETS) {
            try {
                byte[] b = vanilla(client, path);
                if (b == null) { missing++; continue; }
                w.put("assets/minecraft/" + path, PngIO.encode(GuiRecipes.apply(r, PngIO.read(b))));
                done++;
            } catch (Exception e) { missing++; Diagnostics.warn("resource_hub", path + ": " + e.getMessage()); }
        }
        if (done == 0) { fail(L.t("av.hub.nothing", "No vanilla textures could be read")); return; }
        try {
            Path dir = w.writeFolder(client.getResourcePackDir(), "AV " + r.name());
            enableFolder(client, dir);
            pending = false;
            ok(r.name() + ": " + done + " ✓" + (missing > 0 ? ", " + missing + " ✗" : ""));
        } catch (IOException e) { Diagnostics.error("resource_hub", "write failed", e); fail(String.valueOf(e.getMessage())); }
    }

    private static String human(long b) { return b > 1 << 20 ? String.format(Locale.ROOT, "%.1f MB", b / 1048576.0) : (b / 1024) + " KB"; }

    private void inspect() {
        List<String> lines = new ArrayList<>();
        List<PackInspector.Report> reps = new ArrayList<>();
        Path dir = client.getResourcePackDir();
        try (var st = Files.list(dir)) {
            for (Path p : st.toList()) {
                String n = p.getFileName().toString();
                try {
                    if (Files.isDirectory(p)) reps.add(PackInspector.inspectFolder(p));
                    else if (n.toLowerCase(Locale.ROOT).endsWith(".zip")) try (InputStream in = Files.newInputStream(p)) { reps.add(PackInspector.inspectZip(n, in)); }
                } catch (IOException | RuntimeException e) { lines.add("✗ " + n + ": " + e.getMessage()); }
            }
        } catch (IOException e) { fail(String.valueOf(e.getMessage())); return; }
        for (PackInspector.Report r : reps) {
            lines.add((r.ok() ? "✓ " : "✗ ") + r.name + " — format " + r.packFormat + (r.formatMismatch() ? " (" + L.t("av.hub.format_mismatch", "expected") + " " + PackWriter.PACK_FORMAT + ")" : "") + ", " + r.assets.size() + " files, " + human(r.totalBytes));
            if (!r.counts.isEmpty()) lines.add("   " + r.counts);
            for (String s : r.warnings) lines.add("   ⚠ " + s);
            for (String s : r.errors) lines.add("   ✗ " + s);
        }
        Map<String, List<String>> c = PackInspector.conflicts(reps);
        lines.add(L.t("av.hub.conflicts", "Overlapping files") + ": " + c.size());
        int k = 0;
        for (Map.Entry<String, List<String>> e : c.entrySet()) { if (k++ >= 60) { lines.add("…"); break; } lines.add("   " + e.getKey() + "  ←  " + String.join(", ", e.getValue())); }
        if (reps.isEmpty()) lines.add(L.t("av.hub.empty", "resourcepacks/ is empty"));
        info(L.t("av.hub.inspect", "Inspect packs & conflicts"), lines);
    }

    /** Tiny indirection so this screen does not depend on the sound enum directly. */
    private static final class UiSoundsBridge { static void ok() { dev.ancientvisuals.client.UiSounds.play(dev.ancientvisuals.client.UiSounds.Kind.SUCCESS); } }
}
