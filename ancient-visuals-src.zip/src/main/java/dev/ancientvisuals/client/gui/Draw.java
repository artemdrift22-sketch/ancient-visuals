package dev.ancientvisuals.client.gui;

import dev.ancientvisuals.core.render.Ornaments;
import dev.ancientvisuals.core.render.Rect;
import dev.ancientvisuals.core.render.ShapeRaster;
import dev.ancientvisuals.core.texture.HudSkin;
import dev.ancientvisuals.core.theme.CornerStyle;
import dev.ancientvisuals.core.theme.OrnamentStyle;
import dev.ancientvisuals.core.util.Colors;
import net.minecraft.client.gui.DrawContext;

import java.util.List;

/** Pixel-exact drawing helpers shared by HUD and GUI (all shapes come from the tested core rasterisers). */
public final class Draw {
    private Draw() {}

    public static void rects(DrawContext dc, List<Rect> rs, int c0, int c1) {
        for (Rect r : rs) if (r.w() > 0 && r.h() > 0) dc.fill(r.x(), r.y(), r.x() + r.w(), r.y() + r.h(), r.tone() == 0 ? c0 : c1);
    }

    public static void shape(DrawContext dc, int x, int y, int w, int h, CornerStyle cs, int radius, int color) {
        if (w <= 0 || h <= 0 || Colors.a(color) == 0) return;
        rects(dc, ShapeRaster.fill(x, y, w, h, cs, radius), color, color);
    }

    public static void outline(DrawContext dc, int x, int y, int w, int h, CornerStyle cs, int radius, int t, int color) {
        if (w <= 0 || h <= 0 || Colors.a(color) == 0) return;
        rects(dc, ShapeRaster.outline(x, y, w, h, cs, radius, t), color, color);
    }

    public static void ornament(DrawContext dc, OrnamentStyle st, int x, int y, int w, int h, int color, double intensity) {
        if (st == null || st == OrnamentStyle.NONE || intensity <= 0.02 || w <= 4 || h <= 0) return;
        int c = Colors.mulAlpha(color, Math.min(1.0, intensity));
        rects(dc, Ornaments.band(st, x, y, w, h), c, Colors.mulAlpha(c, 0.7));
    }

    public static void gradientH(DrawContext dc, int x, int y, int w, int h, int c0, int c1) {
        if (w <= 0 || h <= 0) return;
        int step = Math.max(1, w / 48);
        for (int i = 0; i < w; i += step) {
            int c = Colors.lerp(c0, c1, w <= 1 ? 0 : i / (double) (w - 1));
            dc.fill(x + i, y, x + Math.min(w, i + step), y + h, c);
        }
    }

    public static void bar(DrawContext dc, HudSkin.Bar style, int x, int y, int w, int h, double f, int color, int bg) {
        f = Math.max(0, Math.min(1, f));
        int fw = (int) Math.round(w * f);
        switch (style == null ? HudSkin.Bar.FLAT : style) {
            case FLAT -> { dc.fill(x, y, x + w, y + h, bg); dc.fill(x, y, x + fw, y + h, color); }
            case SEGMENTED -> {
                int seg = 10, gap = 1, sw = Math.max(1, (w - gap * (seg - 1)) / seg);
                for (int i = 0; i < seg; i++) {
                    int sx = x + i * (sw + gap);
                    boolean on = (i + 0.5) / seg <= f;
                    dc.fill(sx, y, sx + sw, y + h, on ? color : bg);
                }
            }
            case GRADIENT -> { dc.fill(x, y, x + w, y + h, bg); gradientH(dc, x, y, fw, h, Colors.darken(color, 0.35), color); }
            case OUTLINE -> {
                dc.fill(x, y, x + w, y + 1, color); dc.fill(x, y + h - 1, x + w, y + h, color);
                dc.fill(x, y, x + 1, y + h, color); dc.fill(x + w - 1, y, x + w, y + h, color);
                if (fw > 2) dc.fill(x + 1, y + 1, x + fw - 1, y + h - 1, Colors.mulAlpha(color, 0.75));
            }
            case BEADS -> {
                int d = Math.max(2, h), n = Math.max(1, (w + 1) / (d + 1));
                for (int i = 0; i < n; i++) {
                    int bx = x + i * (d + 1);
                    boolean on = (i + 0.5) / n <= f;
                    dc.fill(bx, y, bx + d, y + h, on ? color : bg);
                }
            }
        }
    }
}
