package dev.ancientvisuals.client.gui;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.client.L;
import dev.ancientvisuals.client.UiSounds;
import dev.ancientvisuals.core.io.ImportValidator;
import dev.ancientvisuals.core.profile.Profile;
import dev.ancientvisuals.core.profile.ProfilePresets;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;

import java.util.ArrayList;
import java.util.List;

/** Profiles: switch, create, duplicate, rename, delete, default, compare, presets, import/export. */
public final class ProfilesScreen extends BaseScreen {
    private String selected;
    private int scroll;

    public ProfilesScreen(Screen parent) { super("Profiles", parent); selected = AV.profiles.activeId(); }

    private Profile sel() { Profile p = AV.profiles.get(selected); if (p == null) { p = AV.profiles.active(); selected = p == null ? null : p.id; } return p; }

    private void after(List<String> warnings, String okMsg) {
        AV.invalidateTheme(); AV.dirty(); UiSounds.play(UiSounds.Kind.PROFILE);
        if (warnings != null && !warnings.isEmpty()) { info(L.t("av.profiles.warnings", "Applied with warnings"), warnings); }
        else ok(okMsg);
    }

    @Override protected void draw(DrawContext dc, float delta) {
        int pw = Math.min(W - 20, 420), ph = Math.min(H - 20, 260), x = (W - pw) / 2, y = (H - ph) / 2;
        panel(dc, x, y, pw, ph);
        text(dc, title(L.t("av.tool.profiles", "Profiles")), x + 10, y + 8, pal.accent());
        button(dc, x + pw - 20, y + 5, 14, 14, "×", this::close);
        List<Profile> list = AV.profiles.all();
        int lx = x + 8, ly = y + 24, lw = 140, rh = 14, rows = (ph - 34) / rh;
        scroll = Math.max(0, Math.min(scroll, Math.max(0, list.size() - rows)));
        for (int i = scroll; i < list.size() && i - scroll < rows; i++) {
            Profile p = list.get(i); int ry = ly + (i - scroll) * rh;
            boolean act = p.id.equals(AV.profiles.activeId()), s = p.id.equals(selected), hv = hover(lx, ry, lw, rh);
            if (s || hv) Draw.shape(dc, lx, ry, lw, rh, t.corner(), Math.min(3, t.radius()), s ? dev.ancientvisuals.core.util.Colors.withAlpha(pal.primary(), 130) : pal.hover());
            String mark = (act ? "● " : "   ") + p.name + (p.id.equals(AV.profiles.defaultId()) ? " ★" : "") + (p.builtin ? " ◆" : "");
            text(dc, trim(mark, lw - 6), lx + 3, ry + 3, act ? pal.accent() : pal.text());
            region(lx, ry, lw, rh, b -> { selected = p.id; if (b == 1) { AV.profiles.switchTo(p.id); after(null, p.name); } });
        }
        scrollRegion(lx, ly, lw, rows * rh, a -> scroll -= (int) Math.signum(a));

        Profile p = sel();
        int dx = lx + lw + 10, dw = x + pw - 8 - dx, dy = ly;
        if (p == null) return;
        header(dc, p.name, dx, dy, dw); dy += 12;
        text(dc, "id: " + p.id + (p.builtin ? "  ·  " + L.t("av.profiles.builtin", "built-in") : ""), dx, dy, pal.textMuted()); dy += 10;
        if (p.id.equals(AV.profiles.activeId())) {
            List<String> ch = AV.profiles.unsavedChanges();
            text(dc, ch.isEmpty() ? L.t("av.profiles.saved", "Active · no unsaved changes") : L.t("av.profiles.changes", "Active · changes:") + " " + ch.size(), dx, dy, ch.isEmpty() ? pal.success() : pal.warning());
            if (!ch.isEmpty()) region(dx, dy, dw, 10, b -> info(L.t("av.profiles.changes_title", "Changes since last save"), ch));
        }
        dy += 14;
        int bw = (dw - 4) / 2, bh = 14, r = 0;
        Object[][] actions = {
            {L.t("av.profiles.switch", "Switch to"), (Runnable) () -> after(AV.profiles.switchTo(p.id), p.name)},
            {L.t("av.profiles.save", "Save current state"), (Runnable) () -> { if (p.builtin) { fail(L.t("av.profiles.builtin_ro", "Built-in: duplicate it first")); return; } p.data = AV.profiles.capture(); AV.dirty(); ok(p.name); }},
            {L.t("av.profiles.new", "New from current"), (Runnable) () -> prompt(L.t("av.profiles.name", "Profile name"), "My profile", 32, n -> { selected = AV.profiles.create(n).id; AV.dirty(); ok(n); })},
            {L.t("av.profiles.duplicate", "Duplicate"), (Runnable) () -> { Profile d = AV.profiles.duplicate(p.id); if (d != null) { selected = d.id; AV.dirty(); ok(d.name); } }},
            {L.t("av.profiles.rename", "Rename"), (Runnable) () -> prompt(L.t("av.profiles.name", "Profile name"), p.name, 32, n -> { if (AV.profiles.rename(p.id, n)) { AV.dirty(); ok(n); } else fail(L.t("av.profiles.cant", "Not allowed for this profile")); })},
            {L.t("av.profiles.set_default", "Set as default"), (Runnable) () -> { AV.profiles.setDefault(p.id); AV.dirty(); ok(p.name); }},
            {L.t("av.profiles.compare", "Compare with…"), (Runnable) () -> { List<String> ids = new ArrayList<>(); for (Profile o : AV.profiles.all()) if (!o.id.equals(p.id)) ids.add(o.id); pick(L.t("av.profiles.compare", "Compare with…"), ids, id -> AV.profiles.get(id).name, id -> info(p.name + " ↔ " + AV.profiles.get(id).name, AV.profiles.compare(p.id, id)), null); }},
            {L.t("av.profiles.export", "Export to clipboard"), (Runnable) () -> { client.keyboard.setClipboard(AV.profiles.exportProfile(p.id)); ok(L.t("av.gui.copied", "Copied")); }},
            {L.t("av.profiles.import", "Import from clipboard"), (Runnable) this::doImport},
            {L.t("av.profiles.preset", "Apply preset…"), (Runnable) this::presetPicker},
        };
        for (Object[] a : actions) {
            int bx = dx + (r % 2) * (bw + 4), by = dy + (r / 2) * (bh + 3);
            button(dc, bx, by, bw, bh, (String) a[0], (Runnable) a[1]); r++;
        }
        int by = dy + ((r + 1) / 2) * (bh + 3) + 4;
        if (p.builtin) button(dc, dx, by, bw, bh, L.t("av.profiles.restore", "Restore built-in"), () -> confirm(L.t("av.profiles.restore_q", "Restore this built-in profile to its original settings?"), () -> { AV.profiles.restoreBuiltin(p.id); AV.dirty(); ok(p.name); }));
        else danger(dc, dx, by, bw, bh, L.t("av.profiles.delete", "Delete"), L.t("av.profiles.delete_q", "Delete profile") + " \"" + p.name + "\"?", () -> { if (AV.profiles.delete(p.id)) { selected = AV.profiles.activeId(); AV.dirty(); } else fail(L.t("av.profiles.cant", "Not allowed for this profile")); });
        text(dc, L.t("av.profiles.hint", "Right-click a profile to switch instantly. ★ default · ◆ built-in"), dx, y + ph - 14, pal.textMuted());
    }

    private void doImport() {
        String s = client.keyboard.getClipboard();
        ImportValidator.Result r = AV.profiles.importProfile(s == null ? "" : s);
        if (!r.ok()) { fail(r.summary()); info(L.t("av.profiles.import_failed", "Import rejected"), r.errors); return; }
        AV.dirty();
        if (!r.warnings.isEmpty()) info(L.t("av.profiles.imported", "Imported with warnings"), r.warnings); else ok(L.t("av.profiles.imported_ok", "Profile imported"));
    }

    private void presetPicker() {
        List<String> ids = new ArrayList<>(); for (ProfilePresets.Preset p : ProfilePresets.ALL) ids.add(p.id());
        pick(L.t("av.profiles.preset", "Apply preset…"), ids, id -> { for (ProfilePresets.Preset p : ProfilePresets.ALL) if (p.id().equals(id)) return p.name(); return id; },
                id -> { for (ProfilePresets.Preset p : ProfilePresets.ALL) if (p.id().equals(id)) confirm(p.name() + ": " + p.description() + "\n" + L.t("av.profiles.preset_q", "Apply to the current state?"), () -> after(AV.profiles.apply(AV.profiles.buildPreset(p)), p.name())); }, null);
    }
}
