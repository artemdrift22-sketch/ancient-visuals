package dev.ancientvisuals.client.gui;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.client.L;
import dev.ancientvisuals.client.UiSounds;
import dev.ancientvisuals.client.module.SimpleModules;
import dev.ancientvisuals.core.module.Category;
import dev.ancientvisuals.core.module.Module;
import dev.ancientvisuals.core.module.ModuleRegistry;
import dev.ancientvisuals.core.search.ActionRegistry;
import dev.ancientvisuals.core.setting.Setting;
import dev.ancientvisuals.core.theme.CornerStyle;
import dev.ancientvisuals.core.theme.ShellLayout;
import dev.ancientvisuals.core.util.Colors;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Supplier;

/** Main menu (ClickGUI). Seven shell layouts share the same model: categories, module list, settings. */
public final class ClickGuiScreen extends BaseScreen {
    static final String FAV = "favorites", RECENT = "recent", TOOLS = "tools";
    private String cat;
    private Module selected;
    private final Field search = new Field("", 48);
    private int listScroll, setScroll;
    private boolean movingWin; private int grabX, grabY, winX = Integer.MIN_VALUE, winY;

    public ClickGuiScreen(Screen parent) { this(parent, null); }
    public ClickGuiScreen(Screen parent, String moduleId) {
        super("Ancient Visuals", parent);
        search.placeholder = L.t("av.gui.search_hint", "Search modules, settings, actions…  (Ctrl+F)");
        search.onChange = s -> { listScroll = 0; };
        cat = AV.ui.category == null || AV.ui.category.isEmpty() ? Category.GUI.name() : AV.ui.category;
        if (moduleId != null) { selected = AV.modules.get(moduleId); if (selected != null) cat = selected.category().name(); }
    }

    // ------------------------------------------------------------------ model
    private List<String> cats() {
        List<String> l = new ArrayList<>(List.of(FAV, RECENT));
        for (Category c : Category.values()) if (!AV.modules.byCategory(c).isEmpty()) l.add(c.name());
        l.add(TOOLS);
        return l;
    }
    private String catLabel(String c) {
        return switch (c) {
            case FAV -> "★ " + L.t("av.category.favorites", "Favorites");
            case RECENT -> "⟲ " + L.t("av.category.recent", "Recent");
            case TOOLS -> "⚒ " + L.t("av.category.tools", "Tools");
            default -> { Category k = Category.valueOf(c); yield k.glyph + " " + L.category(k); }
        };
    }
    private List<Module> modules() {
        String q = search.text().trim();
        List<Module> l = new ArrayList<>();
        if (!q.isEmpty()) { for (ModuleRegistry.SearchHit h : AV.modules.search(q)) if (!l.contains(h.module())) l.add(h.module()); return l; }
        switch (cat) {
            case FAV -> { for (String id : AV.ui.favorites) { Module m = AV.modules.get(id); if (m != null) l.add(m); } return l; }
            case RECENT -> { for (String id : AV.ui.recent) { Module m = AV.modules.get(id); if (m != null) l.add(m); } return l; }
            case TOOLS -> { return l; }
            default -> l.addAll(AV.modules.byCategory(Category.valueOf(cat)));
        }
        SimpleModules.ClickGui.Sort sort = AV.clickGui.sort.get();
        switch (sort) {
            case NAME -> l.sort(Comparator.comparing(L::module));
            case ENABLED_FIRST -> l.sort(Comparator.comparing((Module m) -> !m.isEnabled()).thenComparing(L::module));
            case RECENT -> l.sort(Comparator.comparingInt(m -> { int i = AV.ui.recent.indexOf(m.id()); return i < 0 ? 999 : i; }));
            default -> { }
        }
        return l;
    }
    private void select(Module m) { selected = m; setScroll = 0; if (m != null) { AV.ui.touch(m.id()); } }
    private void setCat(String c) { cat = c; AV.ui.category = c; listScroll = 0; search.set(""); }

    // ------------------------------------------------------------------ draw
    @Override protected void draw(DrawContext dc, float delta) {
        ShellLayout lay = t.layout();
        int gw = Math.min(W - 16, lay == ShellLayout.CENTER_COLUMN ? 300 : 480), gh = Math.min(H - 16, 300);
        if (winX == Integer.MIN_VALUE) {
            boolean remember = AV.clickGui.rememberPos.on() && AV.ui.guiX != Integer.MIN_VALUE;
            winX = remember ? AV.ui.guiX : (W - gw) / 2; winY = remember ? AV.ui.guiY : (H - gh) / 2;
        }
        winX = Math.max(0, Math.min(W - gw, winX)); winY = Math.max(0, Math.min(H - gh, winY));
        int x = winX, y = winY;
        panel(dc, x, y, gw, gh);
        // header
        text(dc, title("Ancient Visuals"), x + 10, y + 9, pal.accent());
        dragRegion(x, y, 110, 22, (px, py) -> { if (!movingWin) { movingWin = true; grabX = px - winX; grabY = py - winY; } winX = px - grabX; winY = py - grabY; AV.ui.guiX = winX; AV.ui.guiY = winY; }, null);
        field(dc, search, x + 112, y + 6, gw - 112 - 120, 14);
        String prof = AV.profiles.active() == null ? "-" : AV.profiles.active().name;
        button(dc, x + gw - 104, y + 6, 80, 14, "◈ " + prof, () -> AV.open(new ProfilesScreen(this)));
        button(dc, x + gw - 20, y + 6, 14, 14, "×", this::close);
        int top = y + 26, bottom = y + gh - 6;
        boolean vertical = lay == ShellLayout.SIDEBAR || lay == ShellLayout.COMPACT_LIST || lay == ShellLayout.BOOK_SPREAD;
        int listX, listW, setX, setW, bodyTop = top;
        List<String> cs = cats();
        if (vertical) {
            int rw = 92;
            for (int i = 0; i < cs.size(); i++) {
                String c = cs.get(i); int cy = top + i * 15;
                if (cy + 14 > bottom) break;
                boolean act = c.equals(cat) && search.text().isEmpty(), hv = hover(x + 4, cy, rw, 14);
                if (act || hv) Draw.shape(dc, x + 4, cy, rw, 14, t.corner(), Math.min(4, t.radius()), act ? Colors.withAlpha(pal.primary(), 200) : pal.hover());
                text(dc, trim(catLabel(c), rw - 8), x + 9, cy + 3, act ? 0xFFFFFFFF : pal.text());
                region(x + 4, cy, rw, 14, b -> setCat(c));
            }
            listX = x + rw + 10;
        } else {
            int cx = x + 6; int n = cs.size();
            for (int i = 0; i < n; i++) {
                String c = cs.get(i);
                String lab = lay == ShellLayout.ARC_DEPTH ? catLabel(c).substring(0, Math.min(catLabel(c).length(), 2)).trim() : catLabel(c);
                int w = tw(lab) + 10;
                int arc = lay == ShellLayout.ARC_DEPTH ? (int) Math.round(Math.abs(i - (n - 1) / 2.0) * 1.5) : 0;
                if (cx + w > x + gw - 6) break;
                boolean act = c.equals(cat) && search.text().isEmpty(), hv = hover(cx, top + arc, w, 14);
                Draw.shape(dc, cx, top + arc, w, 14, lay == ShellLayout.TOP_TABS ? CornerStyle.TAB : t.corner(), Math.min(4, t.radius()), act ? Colors.withAlpha(pal.primary(), 210) : hv ? pal.hover() : pal.surfaceAlt());
                text(dc, lab, cx + 5, top + arc + 3, act ? 0xFFFFFFFF : pal.text());
                if (hv && lay == ShellLayout.ARC_DEPTH) tip(catLabel(c));
                region(cx, top + arc, w, 14, b -> setCat(c));
                cx += w + 3;
            }
            bodyTop = top + (lay == ShellLayout.ARC_DEPTH ? 26 : 18);
            listX = x + 6;
        }
        if (lay == ShellLayout.CENTER_COLUMN) { listW = gw - (listX - x) - 6; setX = -1; setW = 0; }
        else { listW = lay == ShellLayout.TILE_GRID ? (gw - (listX - x)) * 55 / 100 : Math.min(170, (gw - (listX - x)) * 45 / 100); setX = listX + listW + 6; setW = x + gw - 6 - setX; }
        if (lay == ShellLayout.BOOK_SPREAD && setX > 0) dc.fill(setX - 4, bodyTop, setX - 2, bottom, Colors.withAlpha(pal.ornament(), 160));

        if (TOOLS.equals(cat) && search.text().isEmpty()) { drawTools(dc, listX, bodyTop, x + gw - 6 - listX, bottom - bodyTop); return; }
        drawList(dc, lay, listX, bodyTop, listW, bottom - bodyTop, setX < 0);
        if (setX > 0) drawSettings(dc, setX, bodyTop, setW, bottom - bodyTop);
    }

    private void drawList(DrawContext dc, ShellLayout lay, int x, int y, int w, int h, boolean accordion) {
        List<Module> mods = modules();
        int cy = y;
        String q = search.text().trim();
        if (!q.isEmpty()) {
            for (ActionRegistry.Hit a : AV.actions.search(q, 4)) {
                if (cy + 13 > y + h) break;
                boolean hv = hover(x, cy, w, 13);
                if (hv) dc.fill(x, cy, x + w, cy + 13, pal.hover());
                text(dc, trim("▶ " + a.action().title(), w - 8), x + 4, cy + 3, pal.accent());
                region(x, cy, w, 13, b -> { AV.actions.run(a.action().id()); ok(a.action().title()); });
                cy += 14;
            }
        }
        if (mods.isEmpty()) {
            textC(dc, FAV.equals(cat) ? L.t("av.gui.no_favorites", "Middle-click a module to favorite it") : L.t("av.gui.nothing", "Nothing here"), x + w / 2, cy + 20, pal.textMuted());
            return;
        }
        if (lay == ShellLayout.TILE_GRID) {
            int tw = 74, th = 34, cols = Math.max(1, (w + 4) / (tw + 4)), rows = Math.max(1, (y + h - cy) / (th + 4));
            listScroll = Math.max(0, Math.min(listScroll, Math.max(0, (mods.size() + cols - 1) / cols - rows)));
            for (int i = listScroll * cols; i < mods.size() && (i / cols - listScroll) < rows; i++) {
                Module m = mods.get(i);
                int tx = x + (i % cols) * (tw + 4), ty = cy + (i / cols - listScroll) * (th + 4);
                boolean hv = hover(tx, ty, tw, th), sel = m == selected;
                Draw.shape(dc, tx, ty, tw, th, t.corner(), t.radius(), sel ? Colors.withAlpha(pal.primary(), 120) : hv ? pal.hover() : pal.surfaceAlt());
                if (m.isEnabled()) dc.fill(tx + 3, ty + th - 3, tx + tw - 3, ty + th - 2, pal.accent());
                text(dc, trim(L.module(m), tw - 8), tx + 4, ty + 5, pal.text());
                text(dc, m.isEnabled() ? "ON" : "OFF", tx + 4, ty + 18, m.isEnabled() ? pal.success() : pal.textMuted());
                moduleInput(tx, ty, tw, th, m);
            }
            scrollRegion(x, y, w, h, a -> listScroll -= (int) Math.signum(a));
            return;
        }
        int rh = lay == ShellLayout.COMPACT_LIST ? 12 : Math.max(14, rowH());
        int visible = Math.max(1, (y + h - cy) / rh);
        listScroll = Math.max(0, Math.min(listScroll, Math.max(0, mods.size() - 1)));
        int i = listScroll;
        while (i < mods.size() && cy + rh <= y + h) {
            Module m = mods.get(i++);
            boolean hv = hover(x, cy, w, rh), sel = m == selected;
            if (sel || hv) Draw.shape(dc, x, cy, w, rh, t.corner(), Math.min(3, t.radius()), sel ? Colors.withAlpha(pal.primary(), 110) : pal.hover());
            if (m.disabledReason() != null) { dc.fill(x, cy, x + 2, cy + rh, pal.error()); if (hv) tip(m.disabledReason()); }
            else if (hv) tip(L.moduleDesc(m));
            String star = AV.ui.favorite(m.id()) ? "★ " : "";
            text(dc, trim(star + L.module(m), w - 30), x + 5, cy + (rh - 8) / 2, m.isEnabled() ? pal.text() : pal.textMuted());
            if (!m.alwaysOn()) { toggleGfx(dc, x + w - 22, cy + (rh - 9) / 2, m.isEnabled()); region(x + w - 24, cy, 24, rh, b -> toggle(m)); }
            moduleInput(x, cy, w - 24, rh, m);
            cy += rh;
            if (accordion && sel) {
                int used = drawSettingsInline(dc, x + 6, cy, w - 6, y + h - cy);
                cy += used + 2;
            }
        }
        if (visible < mods.size()) {
            int bh = Math.max(10, h * visible / mods.size()), by = y + (h - bh) * listScroll / Math.max(1, mods.size() - 1);
            dc.fill(x + w - 1, by, x + w, by + bh, Colors.withAlpha(pal.border(), 200));
        }
        scrollRegion(x, y, w, h, a -> listScroll -= (int) Math.signum(a) * 2);
    }

    private void moduleInput(int x, int y, int w, int h, Module m) {
        region(x, y, w, h, b -> {
            if (b == 0) { if (selected == m && hasShiftDown()) toggle(m); else select(m); }
            else if (b == 2) { AV.ui.toggleFavorite(m.id()); AV.dirty(); }
            else if (b == 1) contextMenu(m);
        });
    }

    private void toggle(Module m) {
        if (m.alwaysOn()) return;
        m.toggle();
        AV.ui.logChange((m.isEnabled() ? "+ " : "- ") + L.module(m));
    }

    private void contextMenu(Module m) {
        List<MenuItem> items = new ArrayList<>();
        if (!m.alwaysOn()) items.add(new MenuItem(m.isEnabled() ? L.t("av.gui.disable", "Disable") : L.t("av.gui.enable", "Enable"), () -> toggle(m)));
        items.add(new MenuItem(AV.ui.favorite(m.id()) ? L.t("av.gui.unfavorite", "Remove from favorites") : L.t("av.gui.favorite", "Add to favorites"), () -> { AV.ui.toggleFavorite(m.id()); AV.dirty(); }));
        items.add(new MenuItem(L.t("av.gui.copy_settings", "Copy settings"), () -> { client.keyboard.setClipboard(dev.ancientvisuals.core.json.Json.write(moduleJson(m), true)); ok(L.t("av.gui.copied", "Copied")); }));
        items.add(new MenuItem(L.t("av.gui.paste_settings", "Paste settings"), () -> pasteSettings(m)));
        items.add(new MenuItem(L.t("av.gui.reset", "Reset to defaults"), () -> confirm(L.t("av.gui.reset_q", "Reset all settings of") + " " + L.module(m) + "?", () -> { m.resetToDefaults(); UiSounds.play(UiSounds.Kind.RESET); })));
        if (m.disabledReason() != null) items.add(new MenuItem(L.t("av.gui.reenable", "Clear error and re-enable"), () -> { m.clearErrors(); m.setEnabled(true); }));
        menu(mx, my, items);
    }

    private java.util.Map<String, Object> moduleJson(Module m) {
        java.util.Map<String, Object> o = new java.util.LinkedHashMap<>();
        o.put("kind", "ancientvisuals.module"); o.put("module", m.id());
        java.util.Map<String, Object> s = new java.util.LinkedHashMap<>();
        for (Setting<?> st : m.settings()) { Object v = st.toJson(); if (v != null) s.put(st.id(), v); }
        o.put("settings", s);
        return o;
    }

    @SuppressWarnings("unchecked")
    private void pasteSettings(Module m) {
        try {
            Object o = dev.ancientvisuals.core.json.Json.parse(client.keyboard.getClipboard());
            if (!(o instanceof java.util.Map<?, ?> map) || !"ancientvisuals.module".equals(map.get("kind")) || !(map.get("settings") instanceof java.util.Map<?, ?> s)) { fail(L.t("av.gui.bad_clipboard", "Clipboard has no module settings")); return; }
            int n = 0;
            for (var e : ((java.util.Map<String, Object>) s).entrySet()) { Setting<?> st = m.setting(e.getKey()); if (st != null && st.fromJson(e.getValue())) n++; }
            ok(n + " " + L.t("av.gui.applied", "settings applied"));
        } catch (RuntimeException e) { fail(L.t("av.gui.bad_clipboard", "Clipboard has no module settings")); }
    }

    private void drawSettings(DrawContext dc, int x, int y, int w, int h) {
        Draw.shape(dc, x, y, w, h, t.corner(), t.radius(), Colors.withAlpha(pal.background(), (int) (120 * t.panelAlpha() + 40)));
        if (selected == null) {
            textC(dc, L.t("av.gui.pick_module", "Select a module"), x + w / 2, y + h / 2 - 10, pal.textMuted());
            textC(dc, L.t("av.gui.hint_keys", "Right click: menu · Middle: favorite · Shift+click: toggle"), x + w / 2, y + h / 2 + 2, pal.textMuted());
            return;
        }
        drawSettingsBody(dc, x + 4, y + 4, w - 8, h - 8);
    }

    private int drawSettingsInline(DrawContext dc, int x, int y, int w, int maxH) {
        return drawSettingsBody(dc, x, y, w, Math.min(maxH, 160));
    }

    private int drawSettingsBody(DrawContext dc, int x, int y, int w, int h) {
        Module m = selected;
        int cy = y;
        text(dc, title(L.module(m)), x, cy, pal.accent());
        if (!m.alwaysOn()) { toggleGfx(dc, x + w - 20, cy - 1, m.isEnabled()); region(x + w - 22, cy - 2, 22, 12, b -> toggle(m)); }
        cy += 11;
        for (String line : wrap(L.moduleDesc(m), w)) { if (cy > y + 40) break; text(dc, line, x, cy, pal.textMuted()); cy += 9; }
        cy += 3;
        List<Object> rows = new ArrayList<>();
        String grp = "";
        for (Setting<?> s : m.settings()) {
            if (!s.isVisible()) continue;
            if (!s.group().equals(grp)) { grp = s.group(); if (!grp.isEmpty()) rows.add(grp); }
            rows.add(s);
        }
        rows.add(m.toggleKey());
        int rh = rowH();
        int avail = (y + h - cy - 16) / rh;
        setScroll = Math.max(0, Math.min(setScroll, Math.max(0, rows.size() - avail)));
        int listTop = cy;
        for (int i = setScroll; i < rows.size() && cy + rh <= y + h - 16; i++) {
            Object o = rows.get(i);
            if (o instanceof String g) { header(dc, L.t("av.group." + g.toLowerCase(java.util.Locale.ROOT).replace(' ', '_'), g), x, cy + 3, w); cy += rh; }
            else cy += settingRow(dc, m, (Setting<?>) o, x, cy, w);
        }
        final int sTop = listTop;
        scrollRegion(x, sTop, w, Math.max(1, cy - sTop), a -> setScroll -= (int) Math.signum(a) * 2);
        int by = y + h - 14;
        danger(dc, x, by, 70, 13, L.t("av.gui.reset_short", "Reset"), L.t("av.gui.reset_q", "Reset all settings of") + " " + L.module(m) + "?", () -> { m.resetToDefaults(); UiSounds.play(UiSounds.Kind.RESET); });
        button(dc, x + 74, by, 70, 13, AV.ui.favorite(m.id()) ? "★" : "☆", () -> { AV.ui.toggleFavorite(m.id()); AV.dirty(); });
        if (AV.clickGui.showIds.on()) text(dc, m.id(), x + 150, by + 3, pal.textMuted());
        return cy - y + 16;
    }

    private void drawTools(DrawContext dc, int x, int y, int w, int h) {
        record Tool(String key, String name, String desc, Supplier<Screen> s) {}
        List<Tool> tools = List.of(
                new Tool("hud_editor", "HUD Editor", "Drag, snap, align and group HUD elements.", () -> new HudEditorScreen(this)),
                new Tool("profiles", "Profiles", "Create, switch, compare, import and export profiles.", () -> new ProfilesScreen(this)),
                new Tool("particle_studio", "Particle Studio", "Preview and edit all 80 effects.", () -> new ParticleStudioScreen(this)),
                new Tool("theme_editor", "Theme Editor", "Shell, palette tokens, ornaments, transparency.", () -> new ThemeEditorScreen(this)),
                new Tool("resource_hub", "Resource Pack Hub", "Inspect packs and generate Olympus GUI packs.", () -> new ResourceHubScreen(this)),
                new Tool("texture_lab", "Texture Lab", "Pixel editor for item and GUI textures.", () -> new TextureLabScreen(this)),
                new Tool("compat", "Compatibility Center", "Hooks, detected mods, diagnostics and safe mode.", () -> new DiagnosticsScreen(this)),
                new Tool("emotes", "Emote Wheel", "Local emotes with particles.", () -> new EmoteWheelScreen(null)));
        int cols = Math.max(1, w / 150), bw = (w - (cols - 1) * 6) / cols, bh = 36;
        for (int i = 0; i < tools.size(); i++) {
            Tool tl = tools.get(i);
            int bx = x + (i % cols) * (bw + 6), by = y + (i / cols) * (bh + 6);
            if (by + bh > y + h) break;
            boolean hv = hover(bx, by, bw, bh);
            Draw.shape(dc, bx, by, bw, bh, t.corner(), t.radius(), hv ? pal.hover() : pal.surfaceAlt());
            Draw.outline(dc, bx, by, bw, bh, t.corner(), t.radius(), 1, hv ? pal.accent() : pal.border());
            text(dc, L.t("av.tool." + tl.key(), tl.name()), bx + 6, by + 6, pal.text());
            text(dc, trim(L.t("av.tool." + tl.key() + ".desc", tl.desc()), bw - 12), bx + 6, by + 20, pal.textMuted());
            region(bx, by, bw, bh, b -> AV.open(tl.s().get()));
        }
        int hy = y + ((tools.size() + cols - 1) / cols) * (bh + 6) + 4;
        if (hy + 12 < y + h) {
            header(dc, L.t("av.gui.history", "Recent changes"), x, hy, w);
            int ly = hy + 12;
            for (String s : AV.ui.history) { if (ly + 9 > y + h) break; text(dc, trim(s, w), x, ly, pal.textMuted()); ly += 9; }
        }
    }

    // ------------------------------------------------------------------ input
    @Override protected void onRelease(int x, int y, int b) { movingWin = false; }
    @Override protected boolean onKey(int key, int mods) {
        if (key == GLFW.GLFW_KEY_F && hasControlDown()) { focus = search; return true; }
        List<Module> l = modules();
        if (key == GLFW.GLFW_KEY_DOWN || key == GLFW.GLFW_KEY_UP) {
            if (l.isEmpty()) return true;
            int i = selected == null ? -1 : l.indexOf(selected);
            i = Math.floorMod(i + (key == GLFW.GLFW_KEY_DOWN ? 1 : -1), l.size());
            select(l.get(i));
            if (i < listScroll) listScroll = i; else if (i > listScroll + 12) listScroll = i - 12;
            return true;
        }
        if ((key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_SPACE) && selected != null) { toggle(selected); return true; }
        if (key == GLFW.GLFW_KEY_TAB) { List<String> c = cats(); setCat(c.get(Math.floorMod(c.indexOf(cat) + (hasShiftDown() ? -1 : 1), c.size()))); return true; }
        if (key == GLFW.GLFW_KEY_RIGHT_SHIFT && AV.ui != null) { close(); return true; }
        return false;
    }
    @Override protected boolean onChar(char c) {
        if (Character.isLetterOrDigit(c)) { focus = search; search.sb.append(c); search.changed(); return true; }
        return false;
    }
}
