package dev.ancientvisuals.client.gui;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.client.L;
import dev.ancientvisuals.core.io.ImportValidator;
import dev.ancientvisuals.core.json.Json;
import dev.ancientvisuals.core.setting.Setting;
import dev.ancientvisuals.core.theme.Palette;
import dev.ancientvisuals.core.theme.Themes;
import dev.ancientvisuals.core.util.Colors;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Theme Editor: shell/palette/animation settings, custom palette token editing, validation, import/export, preview. */
public final class ThemeEditorScreen extends BaseScreen {
    private int scrollR;
    private boolean demoToggle = true; private double demoSlider = 0.6;

    public ThemeEditorScreen(Screen parent) { super("Theme Editor", parent); }

    private void setCustom(Palette p) { AV.customPalette = p.renamed("user_custom", "Custom"); AV.invalidateTheme(); AV.dirty(); }

    @Override protected void draw(DrawContext dc, float delta) {
        int pw = Math.min(W - 12, 470), ph = Math.min(H - 12, 300), x = (W - pw) / 2, y = (H - ph) / 2;
        panel(dc, x, y, pw, ph);
        text(dc, title(L.t("av.tool.theme_editor", "Theme Editor")), x + 10, y + 8, pal.accent());
        button(dc, x + pw - 20, y + 5, 14, 14, "×", this::close);
        int cw = (pw - 24) / 2, lx = x + 8, rx = lx + cw + 8, cy = y + 22;
        // ---- left: theme settings
        header(dc, L.t("av.theme.settings", "Shell & behaviour"), lx, cy, cw); cy += 12;
        for (Setting<?> s : AV.theme.settings()) { if (!s.isVisible()) continue; cy += settingRow(dc, AV.theme, s, lx, cy, cw); }
        cy += 4;
        header(dc, L.t("av.theme.preview", "Preview"), lx, cy, cw); cy += 12;
        int bh = y + ph - 8 - cy;
        if (bh > 40) {
            Draw.shape(dc, lx, cy, cw, bh, t.corner(), t.radius(), t.alpha(pal.background()));
            Draw.outline(dc, lx, cy, cw, bh, t.corner(), t.radius(), 1, pal.border());
            if (t.ornamentIntensity() > 0.05) Draw.ornament(dc, t.ornament(), lx + 6, cy + 2, cw - 12, 4, pal.ornament(), t.ornamentIntensity());
            text(dc, title(t.shell().name()), lx + 6, cy + 8, pal.accent());
            text(dc, pal.name(), lx + 6, cy + 18, pal.textMuted());
            button(dc, lx + 6, cy + 30, 70, 13, L.t("av.theme.sample", "Button"), () -> ok("✓"));
            toggleGfx(dc, lx + 84, cy + 32, demoToggle); region(lx + 84, cy + 30, 22, 13, b -> demoToggle = !demoToggle);
            sliderGfx(dc, lx + 112, cy + 35, Math.max(20, cw - 120), demoSlider);
            dragRegion(lx + 110, cy + 30, Math.max(20, cw - 116), 12, (px, py) -> demoSlider = Math.max(0, Math.min(1, (px - lx - 112) / (double) Math.max(20, cw - 120))), null);
            int chipY = cy + 48;
            if (chipY + 12 < cy + bh) {
                int cx2 = lx + 6;
                int[] cols = {pal.success(), pal.warning(), pal.error(), pal.primary(), pal.secondary(), pal.accent()};
                for (int c : cols) { Draw.shape(dc, cx2, chipY, 14, 10, t.corner(), 3, c); cx2 += 17; }
                List<String> issues = pal.validate();
                text(dc, issues.isEmpty() ? "✓ " + L.t("av.theme.contrast_ok", "Contrast OK") : "⚠ " + issues.size(), cx2 + 4, chipY + 1, issues.isEmpty() ? pal.success() : pal.warning());
            }
        }
        // ---- right: custom palette
        int ry = y + 22;
        header(dc, L.t("av.theme.custom", "Custom palette"), rx, ry, cw); ry += 12;
        boolean using = "user_custom".equals(AV.theme.palette.get());
        button(dc, rx, ry, cw, 13, using ? "✓ " + L.t("av.theme.using_custom", "Custom palette is active") : L.t("av.theme.use_custom", "Use custom palette"), () -> { AV.theme.palette.set("user_custom"); AV.invalidateTheme(); });
        ry += 16;
        Palette cp = AV.customPalette;
        int rowsTop = ry, rh = 12, rows = Math.max(1, (y + ph - 8 - 3 * 16 - ry) / rh);
        String[] tok = Palette.TOKENS;
        scrollR = Math.max(0, Math.min(scrollR, Math.max(0, tok.length - rows)));
        for (int i = scrollR; i < tok.length && i - scrollR < rows; i++) {
            String k = tok[i]; int c = cp.get(k), iy = rowsTop + (i - scrollR) * rh;
            boolean hv = hover(rx, iy, cw, rh);
            if (hv) dc.fill(rx, iy, rx + cw, iy + rh, Colors.withAlpha(pal.hover(), 100));
            swatch(dc, rx + 2, iy + 1, 18, rh - 2, c);
            text(dc, L.t("av.token." + k, k), rx + 24, iy + 2, pal.text());
            text(dc, Colors.toHex(c), rx + cw - 4 - tw(Colors.toHex(c)), iy + 2, pal.textMuted());
            region(rx, iy, cw, rh, b -> colorPicker(AV.customPalette.get(k), true, v -> setCustom(AV.customPalette.with(k, v))));
        }
        scrollRegion(rx, rowsTop, cw, rows * rh, a -> scrollR -= (int) Math.signum(a) * 2);
        int by = y + ph - 8 - 3 * 16 + 4, bw = (cw - 4) / 2;
        button(dc, rx, by, bw, 13, L.t("av.theme.copy_current", "Copy current palette"), () -> setCustom(AV.theme.basePalette()));
        button(dc, rx + bw + 4, by, bw, 13, L.t("av.theme.high_contrast", "High-contrast variant"), () -> setCustom(AV.customPalette.highContrast()));
        button(dc, rx, by + 16, bw, 13, L.t("av.theme.validate", "Validate"), () -> { List<String> v = AV.customPalette.validate(); if (v.isEmpty()) ok(L.t("av.theme.contrast_ok", "Contrast OK")); else showList(L.t("av.theme.issues", "Palette issues"), v); });
        button(dc, rx + bw + 4, by + 16, bw, 13, L.t("av.theme.export", "Export to clipboard"), this::export);
        button(dc, rx, by + 32, bw, 13, L.t("av.theme.import", "Import from clipboard"), this::doImport);
        danger(dc, rx + bw + 4, by + 32, bw, 13, L.t("av.theme.restore", "Restore defaults"), L.t("av.theme.restore_q", "Reset theme settings and the custom palette?"), () -> { AV.customPalette = Themes.palette("user_custom"); AV.theme.resetToDefaults(); AV.invalidateTheme(); AV.dirty(); });
        AV.invalidateTheme();
    }

    private void showList(String title, List<String> lines) {
        List<MenuItem> items = new ArrayList<>();
        for (String l : lines) items.add(new MenuItem(l, () -> { }));
        menu(W / 2 - 100, H / 2 - lines.size() * 6, items);
        toast(title, pal.warning());
    }

    private void export() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("kind", "ancientvisuals.theme"); m.put("version", 1);
        m.put("shell", AV.theme.shell.get()); m.put("palette", AV.customPalette.toJson());
        client.keyboard.setClipboard(Json.write(m, true));
        ok(L.t("av.gui.copied", "Copied"));
    }

    @SuppressWarnings("unchecked")
    private void doImport() {
        String s = client.keyboard.getClipboard();
        if (s == null || s.isBlank() || s.length() > ImportValidator.MAX_IMPORT) { fail(L.t("av.gui.bad_clipboard", "Clipboard has no valid data")); return; }
        try {
            Object o = Json.parse(s);
            if (!(o instanceof Map<?, ?> m) || !"ancientvisuals.theme".equals(m.get("kind")) || !(m.get("palette") instanceof Map<?, ?> p)) { fail(L.t("av.theme.not_theme", "Not an Ancient Visuals theme")); return; }
            setCustom(Palette.fromJson((Map<String, Object>) p, AV.customPalette));
            if (m.get("shell") instanceof String sh && Themes.shellIds().contains(sh)) AV.theme.shell.set(sh);
            AV.theme.palette.set("user_custom");
            List<String> v = AV.customPalette.validate();
            if (v.isEmpty()) ok(L.t("av.theme.imported", "Theme imported")); else toast(L.t("av.theme.imported_warn", "Imported; contrast warnings: ") + v.size(), pal.warning());
        } catch (RuntimeException e) { fail(L.t("av.theme.not_theme", "Not an Ancient Visuals theme")); }
    }
}
