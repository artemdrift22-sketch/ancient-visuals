package dev.ancientvisuals.client.gui;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.client.L;
import dev.ancientvisuals.client.fx.Effects;
import dev.ancientvisuals.core.diag.Diagnostics;
import dev.ancientvisuals.core.module.Module;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.util.Util;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/** Compatibility Center: mixin hooks, detected mods, error log, safe mode, re-enable, reset. */
public final class DiagnosticsScreen extends BaseScreen {
    public static final List<String> EXPECTED_HOOKS = List.of("hud", "crosshair", "held_item", "totem", "mouse", "fog", "fog_color", "companion_render");
    static final Map<String, String> NOTES = Map.of(
            "optifabric", "OptiFine via OptiFabric: rendering hooks may not fire.",
            "iris", "Compatible. Shader packs may override fog tint.",
            "sodium", "Compatible. HUD/GUI are not affected.",
            "immediatelyfast", "Compatible.",
            "feather", "Third-party client may draw its own HUD on top.",
            "lunar", "Third-party client may draw its own HUD on top.",
            "betterf3", "Use 'Hide with F3' if both overlays overlap.");
    private int tab, scroll;

    public DiagnosticsScreen(Screen parent) { super("Compatibility Center", parent); }

    private List<String[]> lines() {
        List<String[]> l = new ArrayList<>();
        switch (tab) {
            case 0 -> {
                l.add(new String[]{"h", L.t("av.diag.hooks", "Rendering hooks")});
                for (String h : EXPECTED_HOOKS) l.add(new String[]{AV.hooks.contains(h) ? "ok" : "muted", (AV.hooks.contains(h) ? "✓ " : "… ") + h + (AV.hooks.contains(h) ? "" : "  " + L.t("av.diag.not_yet", "(not triggered yet — normal for unused features)"))});
                l.add(new String[]{"h", L.t("av.diag.state", "State")});
                int en = 0, err = 0; for (Module m : AV.modules.all()) { if (m.isEnabled()) en++; if (m.disabledReason() != null) err++; }
                l.add(new String[]{"t", "FPS: " + AV.frames.fps() + "   " + L.t("av.diag.modules", "Modules") + ": " + en + " / " + AV.modules.all().size()});
                l.add(new String[]{err > 0 ? "err" : "t", L.t("av.diag.errored", "Auto-disabled after errors") + ": " + err});
                for (Module m : AV.modules.all()) if (m.disabledReason() != null) l.add(new String[]{"err", "  " + L.module(m) + ": " + m.disabledReason()});
                l.add(new String[]{AV.modules.safeMode() ? "warn" : "t", L.t("av.diag.safe", "Safe mode") + ": " + (AV.modules.safeMode() ? "ON" : "off")});
                l.add(new String[]{"t", L.t("av.diag.log_counts", "Log") + ": " + Diagnostics.errorCount() + " errors, " + Diagnostics.warningCount() + " warnings"});
                l.add(new String[]{"t", L.t("av.diag.effects", "Effects") + ": " + Effects.allIds().size()});
            }
            case 1 -> {
                List<ModContainer> mods = new ArrayList<>(FabricLoader.getInstance().getAllMods());
                mods.sort(Comparator.comparing(c -> c.getMetadata().getId()));
                l.add(new String[]{"h", L.t("av.diag.mods", "Loaded mods") + " (" + mods.size() + ")"});
                for (ModContainer c : mods) {
                    String id = c.getMetadata().getId(), note = NOTES.get(id);
                    l.add(new String[]{note == null ? "t" : note.startsWith("Compatible") ? "ok" : "warn", id + "  " + c.getMetadata().getVersion().getFriendlyString() + (note == null ? "" : "  — " + note)});
                }
            }
            default -> {
                List<Diagnostics.Entry> e = Diagnostics.entries();
                Collections.reverse(e);
                l.add(new String[]{"h", L.t("av.diag.log", "Diagnostics log") + " (" + e.size() + ")"});
                for (Diagnostics.Entry en : e) l.add(new String[]{en.level() == Diagnostics.Level.ERROR ? "err" : en.level() == Diagnostics.Level.WARN ? "warn" : "t", en.toString()});
            }
        }
        return l;
    }

    private String report() {
        StringBuilder sb = new StringBuilder("Ancient Visuals diagnostics\n");
        int keep = tab; for (tab = 0; tab < 3; tab++) for (String[] s : lines()) sb.append(s[1]).append('\n');
        tab = keep;
        return sb.toString();
    }

    @Override protected void draw(DrawContext dc, float delta) {
        int pw = Math.min(W - 12, 480), ph = Math.min(H - 12, 290), x = (W - pw) / 2, y = (H - ph) / 2;
        panel(dc, x, y, pw, ph);
        text(dc, title(L.t("av.tool.compat", "Compatibility Center")), x + 10, y + 8, pal.accent());
        button(dc, x + pw - 20, y + 5, 14, 14, "×", this::close);
        String[] tabs = {L.t("av.diag.tab.overview", "Overview"), L.t("av.diag.tab.mods", "Mods"), L.t("av.diag.tab.log", "Log")};
        int tx = x + 10;
        for (int i = 0; i < tabs.length; i++) { final int k = i; chip(dc, tx, y + 22, tabs[i], tab == i, () -> { tab = k; scroll = 0; }); tx += chipW(tabs[i]); }
        List<String> wrapped = new ArrayList<>(); List<String> kinds = new ArrayList<>();
        for (String[] s : lines()) for (String w : wrap(s[1], pw - 28)) { wrapped.add(w); kinds.add(s[0]); }
        int ly = y + 38, rows = (ph - 38 - 40) / 10;
        scroll = Math.max(0, Math.min(scroll, Math.max(0, wrapped.size() - rows)));
        for (int i = scroll; i < wrapped.size() && i - scroll < rows; i++) {
            String k = kinds.get(i);
            int c = switch (k) { case "h" -> pal.accent(); case "ok" -> pal.success(); case "warn" -> pal.warning(); case "err" -> pal.error(); case "muted" -> pal.textMuted(); default -> pal.text(); };
            text(dc, wrapped.get(i), x + 12, ly + (i - scroll) * 10, c);
        }
        scrollRegion(x, ly, pw, rows * 10, a -> scroll -= (int) Math.signum(a) * 3);
        int by = y + ph - 34, bw = (pw - 20 - 8) / 3;
        button(dc, x + 10, by, bw, 13, (AV.modules.safeMode() ? "✓ " : "") + L.t("av.diag.safe_toggle", "Safe mode (heavy visuals off)"), () -> { AV.modules.setSafeMode(!AV.modules.safeMode()); AV.dirty(); });
        button(dc, x + 14 + bw, by, bw, 13, L.t("av.diag.reenable", "Re-enable errored modules"), () -> { AV.modules.reenableErrored(); ok("✓"); });
        button(dc, x + 18 + 2 * bw, by, bw, 13, L.t("av.diag.copy", "Copy report"), () -> { client.keyboard.setClipboard(report()); ok(L.t("av.gui.copied", "Copied")); });
        button(dc, x + 10, by + 16, bw, 13, L.t("av.diag.open_config", "Open config folder"), () -> {
            try { Path p = FabricLoader.getInstance().getConfigDir().resolve("ancientvisuals"); Files.createDirectories(p); Util.getOperatingSystem().open(p.toUri()); } catch (Exception e) { fail(String.valueOf(e.getMessage())); }
        });
        button(dc, x + 14 + bw, by + 16, bw, 13, L.t("av.diag.clear", "Clear log"), () -> { Diagnostics.clear(); scroll = 0; });
        danger(dc, x + 18 + 2 * bw, by + 16, bw, 13, L.t("av.diag.reset_all", "Reset everything"), L.t("av.diag.reset_all_q", "Reset ALL modules, HUD layout and effect edits to defaults? Profiles are kept."), () -> {
            for (Module m : AV.modules.all()) m.resetToDefaults();
            AV.layout.reset(); Effects.INSTANCE.reset(); AV.invalidateTheme(); AV.dirty(); ok("✓");
        });
    }
}
