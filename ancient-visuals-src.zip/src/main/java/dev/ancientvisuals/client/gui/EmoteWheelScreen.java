package dev.ancientvisuals.client.gui;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.client.L;
import dev.ancientvisuals.client.fx.FxEvents;
import dev.ancientvisuals.core.theme.CornerStyle;
import dev.ancientvisuals.core.util.Colors;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/** Radial emote menu. Emotes are purely local: particles around you plus an action-bar notice. Nothing is sent to the server. */
public final class EmoteWheelScreen extends BaseScreen {
    public record Emote(String id, String name, String effect, String glyph) {}
    public static final List<Emote> EMOTES = List.of(
            new Emote("greeting", "Greeting", "item_pickup_spark", "☼"),
            new Emote("bow", "Bow", "laurel_leaves", "❦"),
            new Emote("victory", "Victory", "victory_confetti", "★"),
            new Emote("wave", "Wave", "feather_drift", "≈"),
            new Emote("playful", "Playful", "hera_bloom", "✿"),
            new Emote("sitting", "Sitting", "cloud_puff", "☁"),
            new Emote("idle", "Idle", "celestial_dust", "✧"),
            new Emote("celebration", "Celebration", "olympus_burst", "❂"));

    public EmoteWheelScreen(Screen parent) { super("Emotes", parent); }
    @Override protected double dim() { return 0.25; }

    private int hovered() {
        int cx = W / 2, cy = H / 2; double dx = mx - cx, dy = my - cy;
        if (dx * dx + dy * dy < 18 * 18) return -1;
        double ang = Math.atan2(dy, dx);
        return Math.floorMod((int) Math.round((ang + Math.PI / 2) / (Math.PI / 4)), 8);
    }

    public static void perform(Emote e) {
        var mc = net.minecraft.client.MinecraftClient.getInstance();
        var p = mc.player;
        if (p == null) return;
        if (!AV.emotes.isEnabled()) { p.sendMessage(Text.literal(L.t("av.emotes.off", "Emotes module is disabled")), true); return; }
        if (AV.emotes.particles.on()) FxEvents.play(e.effect(), p.getX(), p.getY(), p.getZ(), p.getYaw(), false);
        if (AV.emotes.notice.on()) p.sendMessage(Text.literal(e.glyph() + " " + L.t("av.emote." + e.id(), e.name())), true);
    }

    private void run(int i) { if (i < 0 || i >= EMOTES.size()) return; Emote e = EMOTES.get(i); close(); perform(e); }

    @Override protected void draw(DrawContext dc, float delta) {
        int cx = W / 2, cy = H / 2, R = 78, hov = overlay == null ? hovered() : -1;
        for (int i = 0; i < 64; i++) { double a = i * Math.PI * 2 / 64; int px = cx + (int) (Math.cos(a) * (R - 22)), py = cy + (int) (Math.sin(a) * (R - 22)); dc.fill(px, py, px + 1, py + 1, Colors.withAlpha(pal.ornament(), 150)); }
        for (int i = 0; i < EMOTES.size(); i++) {
            Emote e = EMOTES.get(i);
            double a = i * Math.PI / 4 - Math.PI / 2;
            String lab = e.glyph() + " " + L.t("av.emote." + e.id(), e.name()) + "  " + (i + 1);
            int w = tw(lab) + 12, h = 16, lx = cx + (int) (Math.cos(a) * R) - w / 2, ly = cy + (int) (Math.sin(a) * R) - h / 2;
            boolean hv = i == hov;
            Draw.shape(dc, lx, ly, w, h, t.corner(), Math.min(6, t.radius() + 2), hv ? Colors.withAlpha(pal.primary(), 235) : Colors.withAlpha(pal.surface(), 220));
            Draw.outline(dc, lx, ly, w, h, t.corner(), Math.min(6, t.radius() + 2), 1, hv ? pal.accent() : pal.border());
            text(dc, lab, lx + 6, ly + 4, hv ? 0xFFFFFFFF : pal.text());
            final int idx = i;
            region(lx, ly, w, h, b -> run(idx));
        }
        Draw.shape(dc, cx - 22, cy - 22, 44, 44, CornerStyle.PILL, 22, Colors.withAlpha(pal.surface(), 235));
        Draw.outline(dc, cx - 22, cy - 22, 44, 44, CornerStyle.PILL, 22, 1, pal.accent());
        String center = hov >= 0 ? EMOTES.get(hov).glyph() : "❂";
        textC(dc, center, cx, cy - 4, pal.accent());
        textC(dc, L.t("av.emotes.hint", "Click an emote · 1-8 · Esc to close · visible only to you"), cx, cy + R + 22, 0xFFE0E8F5);
    }

    @Override protected boolean onEmptyClick(int x, int y, int button) { int h = hovered(); if (h >= 0) run(h); else close(); return true; }
    @Override protected boolean onKey(int key, int mods) {
        if (key >= GLFW.GLFW_KEY_1 && key <= GLFW.GLFW_KEY_8) { run(key - GLFW.GLFW_KEY_1); return true; }
        return false;
    }
}
