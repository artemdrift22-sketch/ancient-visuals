package dev.ancientvisuals.client;

import dev.ancientvisuals.core.module.Category;
import dev.ancientvisuals.core.module.Module;
import dev.ancientvisuals.core.setting.Setting;
import net.minecraft.client.resource.language.I18n;

/** Localisation helper with English fallbacks (keys live in assets/ancientvisuals/lang). */
public final class L {
    private L() {}
    public static String t(String key, String fallback) { try { return I18n.hasTranslation(key) ? I18n.translate(key) : fallback; } catch (Throwable e) { return fallback; } }
    public static String module(Module m) { return t("av.module." + m.id(), m.name()); }
    public static String moduleDesc(Module m) { return t("av.module." + m.id() + ".desc", m.description()); }
    public static String setting(Module m, Setting<?> s) { return t("av.setting." + m.id() + "." + s.id(), s.name()); }
    public static String category(Category c) { return t(c.langKey(), c.title); }
}
