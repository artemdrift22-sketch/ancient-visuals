package dev.ancientvisuals.client.fx;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.core.particle.ParticleKind;
import dev.ancientvisuals.core.particle.ParticleRequest;
import dev.ancientvisuals.core.util.Colors;
import net.minecraft.client.network.ClientPlayerEntity;

/** 13 trail modes, emitted along the path travelled since the previous tick. */
public final class TrailFx {
    private TrailFx() {}
    private static double px, py, pz;
    private static boolean has;
    private static int tick;

    public static void tick(ClientPlayerEntity p, boolean first) {
        var t = AV.trails;
        if (t == null || !t.isEnabled() || (first && !t.firstPerson.on())) { has = false; return; }
        double x = p.getX(), y = p.getY() + t.height.d(), z = p.getZ();
        if (!has) { px = x; py = y; pz = z; has = true; return; }
        double dx = x - px, dy = y - py, dz = z - pz;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        tick++;
        double inten = FxEvents.intensity(first);
        if (len < 0.03 || len > 6 || inten <= 0 || (t.onlySprint.on() && !p.isSprinting()) || AV.sink.live() >= AV.effects.limit()) { px = x; py = y; pz = z; return; }
        int n = (int) Math.max(1, Math.min(12, Math.round(len * 4 * t.density.d() * inten)));
        double hl = Math.max(1e-4, Math.hypot(dx, dz));
        double nx = -dz / hl, nz = dx / hl;
        double w = t.width.d();
        int life = Math.max(4, t.length.i());
        for (int i = 0; i < n; i++) {
            double f = (i + 1) / (double) n;
            double sx = px + dx * f, sy = py + dy * f, sz = pz + dz * f;
            double phase = tick + f;
            int c0 = t.colors.stop(0), c1 = t.colors.stop(t.colors.stops() - 1);
            int cs = t.colors.sample((phase * 0.04) % 1.0);
            switch (t.mode.get()) {
                case THIN_LINE -> emit(ParticleKind.DUST, sx, sy, sz, 0, 0, 0, cs, cs, 0.45f, life, 1f, 0.2f);
                case GLOWING_RIBBON -> {
                    emit(ParticleKind.GLOW, sx + nx * w * 0.5, sy, sz + nz * w * 0.5, 0, 0, 0, cs, c1, 1f, life, 0.9f, 0f);
                    emit(ParticleKind.GLOW, sx - nx * w * 0.5, sy, sz - nz * w * 0.5, 0, 0, 0, cs, c1, 1f, life, 0.9f, 0f);
                }
                case SPRITE_SEQUENCE -> {
                    ParticleKind k = switch ((tick + i) % 3) { case 0 -> ParticleKind.END_ROD; case 1 -> ParticleKind.ENCHANT; default -> ParticleKind.WAX; };
                    emit(k, sx, sy, sz, 0, 0.005, 0, cs, cs, 0.8f, life, 1f, 0f);
                }
                case STAR_PATH -> {
                    if ((tick + i) % 3 == 0) emit(ParticleKind.END_ROD, sx, sy, sz, 0, 0, 0, c1, c1, 0.7f, life, 1f, 0f);
                    else emit(ParticleKind.DUST, sx, sy, sz, 0, 0, 0, c0, c1, 0.35f, life / 2 + 2, 1f, 0f);
                }
                case GEOMETRIC_FRAGMENTS -> {
                    double j = (Math.sin(phase * 12.9898) * 43758.5453) % 1.0;
                    emit(i % 2 == 0 ? ParticleKind.SCRAPE : ParticleKind.WAX, sx + nx * j * w, sy + j * 0.2, sz + nz * j * w, 0, 0.01, 0, cs, cs, 0.8f, life, 1f, 0f);
                }
                case FADING_DOTS -> { if ((tick + i) % 2 == 0) emit(ParticleKind.DUST, sx, sy, sz, 0, 0, 0, cs, cs, 0.9f, life, 1f, 0f); }
                case GRADIENT -> emit(ParticleKind.DUST, sx, sy, sz, 0, 0, 0, c0, c1, 0.7f, life, 1f, 0.3f);
                case DOUBLE_RIBBON -> {
                    emit(ParticleKind.DUST, sx + nx * w, sy, sz + nz * w, 0, 0, 0, c0, c0, 0.5f, life, 1f, 0.2f);
                    emit(ParticleKind.DUST, sx - nx * w, sy, sz - nz * w, 0, 0, 0, c1, c1, 0.5f, life, 1f, 0.2f);
                }
                case COMET_TAIL -> {
                    if (i == n - 1) emit(ParticleKind.FIREWORK, sx, sy, sz, 0, 0, 0, c1, c1, 0.6f, 6, 1f, 0f);
                    emit(ParticleKind.DUST, sx, sy, sz, -dx * 0.05, 0.002, -dz * 0.05, cs, c0, 0.6f * (float) f + 0.2f, life, 1f, 0f);
                }
                case RING_TRAIL -> {
                    if (i == n - 1 && tick % 4 == 0) {
                        for (int k = 0; k < 8; k++) {
                            double a = k * Math.PI / 4;
                            emit(ParticleKind.DUST, sx + nx * Math.cos(a) * w, sy + Math.sin(a) * w, sz + nz * Math.cos(a) * w, 0, 0, 0, cs, cs, 0.45f, life, 1f, 0f);
                        }
                    }
                }
                case ORNAMENTAL_RIBBON -> {
                    double s = (Math.floor(phase * 2) % 2 == 0 ? 1 : -1) * w * 0.6;
                    emit(ParticleKind.DUST, sx + nx * s, sy, sz + nz * s, 0, 0, 0, Colors.lerp(c0, 0xFFD4A537, 0.5), c1, 0.5f, life, 1f, 0.2f);
                }
                case DUST_TRAIL -> { if (p.isOnGround()) emit((tick + i) % 2 == 0 ? ParticleKind.DUST_PLUME : ParticleKind.ASH, sx, p.getY() + 0.05, sz, 0, 0.01, 0, cs, cs, 0.7f, life, 1f, 0f); }
                case COLOR_PULSES -> {
                    float size = (float) (0.4 + 0.35 * (0.5 + 0.5 * Math.sin(phase * 0.6)));
                    emit(ParticleKind.DUST, sx, sy, sz, 0, 0, 0, cs, cs, size, life, 1f, 0.1f);
                }
            }
        }
        px = x; py = y; pz = z;
    }

    private static void emit(ParticleKind k, double x, double y, double z, double vx, double vy, double vz, int c0, int c1, float size, int life, float a0, float a1) {
        ParticleRequest r = new ParticleRequest();
        r.kind = k; r.x = x; r.y = y; r.z = z; r.vx = vx; r.vy = vy; r.vz = vz;
        r.colorStart = c0; r.colorEnd = c1; r.size = size; r.lifetime = life; r.alphaStart = a0; r.alphaEnd = a1;
        r.gravity = 0; r.drag = 0.9f;
        AV.sink.spawn(r);
    }
}
