package dev.ancientvisuals.client.fx;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.client.module.SimpleModules;
import dev.ancientvisuals.core.companion.CompanionModel;
import dev.ancientvisuals.core.companion.Companions;
import dev.ancientvisuals.core.companion.Voxel;
import dev.ancientvisuals.core.diag.Diagnostics;
import dev.ancientvisuals.core.particle.EffectDef;
import dev.ancientvisuals.core.util.Colors;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RotationAxis;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/** Local-only voxel companion. Rendered for this client only; nothing is sent to the server. */
public final class CompanionRenderer {
    private CompanionRenderer() {}
    public static final dev.ancientvisuals.core.companion.FollowController follow = new dev.ancientvisuals.core.companion.FollowController();
    private static String lastType;
    private static boolean spawned;
    private static int ticks, errors;
    private static double lastPX, lastPZ;
    private static float moving;

    public static void tick(MinecraftClient mc) {
        var c = AV.companion;
        var p = mc.player;
        if (c == null || !c.isEnabled() || p == null || mc.world == null) { spawned = false; follow.reset(); return; }
        CompanionModel m = Companions.get(c.type.get());
        if (m == null) return;
        if (!m.id.equals(lastType)) { follow.reset(); spawned = false; lastType = m.id; }
        follow.side = (c.side.get() == SimpleModules.Companion.Side.RIGHT ? 1 : -1) * 0.9;
        follow.up = c.height.d();
        follow.smoothing = c.smoothing.d();
        follow.tick(p.getX(), p.getY(), p.getZ(), p.getYaw(), m.hover, m.flies, m.bob);
        double sp = Math.hypot(p.getX() - lastPX, p.getZ() - lastPZ);
        moving += ((sp > 0.02 ? 1f : 0f) - moving) * 0.2f;
        lastPX = p.getX(); lastPZ = p.getZ();
        ticks++;
        if (!spawned) { spawned = true; FxEvents.play("companion_arrival", follow.x, follow.y, follow.z, follow.yaw, false); }
        if (c.trail.on()) {
            EffectDef d = Effects.get("companion_trail");
            if (d != null) AV.effects.emitContinuous("companion", d, follow.x, follow.y, follow.z, follow.yaw, FxEvents.intensity(false));
        }
    }

    public static void render(WorldRenderContext ctx) {
        var c = AV.companion;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (c == null || !c.isEnabled() || mc.player == null || mc.world == null || !spawned) return;
        if (mc.options.getPerspective().isFirstPerson() && !c.firstPerson.on()) return;
        MatrixStack ms = ctx.matrixStack();
        VertexConsumerProvider vcp = ctx.consumers();
        if (ms == null || vcp == null) return;
        try {
            AV.hook("companion_render");
            CompanionModel m = Companions.get(c.type.get());
            float td = ctx.tickCounter().getTickDelta(false);
            double x = follow.lerpX(td), y = follow.lerpY(td), z = follow.lerpZ(td);
            float yaw = (float) follow.lerpYaw(td);
            Vec3d cam = ctx.camera().getPos();
            float light = 0.35f + 0.65f * mc.world.getLightLevel(BlockPos.ofFloored(x, y + 0.3, z)) / 15f;
            int detail = AV.effects.quality.modelDetail >= 3 ? 0 : AV.effects.quality.modelDetail == 2 ? 1 : 2;
            float time = (ticks + td) / 20f;
            ms.push();
            ms.translate((float) (x - cam.x), (float) (y - cam.y), (float) (z - cam.z));
            ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(-yaw));
            float s = (float) (c.scale.d() * m.scale / 16.0);
            ms.scale(s, s, s);
            VertexConsumer vc = vcp.getBuffer(RenderLayer.getDebugQuads());
            for (Voxel v : m.lod(detail)) {
                ms.push();
                switch (v.part()) {
                    case WING_L, WING_R -> {
                        if (m.flies) {
                            float a = (float) Math.sin(time * Math.PI * 2 * Math.max(0.5f, m.wingFlap)) * 32f;
                            float pivot = v.part() == Voxel.Part.WING_L ? v.x() + v.w() : v.x();
                            ms.translate(pivot, v.y(), 0);
                            ms.multiply(RotationAxis.POSITIVE_Z.rotationDegrees(v.part() == Voxel.Part.WING_L ? a : -a));
                            ms.translate(-pivot, -v.y(), 0);
                        }
                    }
                    case TAIL -> {
                        float a = (float) Math.sin(time * 3.2) * 20f * m.tailSwing;
                        float pz = v.z() + v.d();
                        ms.translate(v.x() + v.w() / 2, 0, pz);
                        ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(a));
                        ms.translate(-(v.x() + v.w() / 2), 0, -pz);
                    }
                    case LEG -> {
                        float a = (float) Math.sin(time * 9 + (v.x() < 0 ? 0 : Math.PI)) * 28f * moving;
                        float py = v.y() + v.h();
                        ms.translate(0, py, v.z() + v.d() / 2);
                        ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(a));
                        ms.translate(0, -py, -(v.z() + v.d() / 2));
                    }
                    default -> { }
                }
                boolean glow = v.part() == Voxel.Part.GLOW || v.part() == Voxel.Part.EYE;
                int col = v.color();
                if (v.part() == Voxel.Part.GLOW) col = Colors.mulAlpha(col, 0.65 + 0.35 * Math.sin(time * 4));
                box(vc, ms.peek().getPositionMatrix(), v.x(), v.y(), v.z(), v.x() + v.w(), v.y() + v.h(), v.z() + v.d(), col, glow ? 1f : light);
                ms.pop();
            }
            ms.pop();
        } catch (Throwable t) {
            if (errors++ < 3) Diagnostics.error("companion", "render failed", t);
        }
    }

    private static void box(VertexConsumer vc, Matrix4f m, float x0, float y0, float z0, float x1, float y1, float z1, int argb, float light) {
        quad(vc, m, argb, light * 1.0f, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0);
        quad(vc, m, argb, light * 0.5f, x0, y0, z0, x1, y0, z0, x1, y0, z1, x0, y0, z1);
        quad(vc, m, argb, light * 0.8f, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1);
        quad(vc, m, argb, light * 0.8f, x0, y0, z0, x0, y1, z0, x1, y1, z0, x1, y0, z0);
        quad(vc, m, argb, light * 0.62f, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0);
        quad(vc, m, argb, light * 0.62f, x1, y0, z0, x1, y1, z0, x1, y1, z1, x1, y0, z1);
    }

    private static void quad(VertexConsumer vc, Matrix4f m, int argb, float shade, float... p) {
        int a = Colors.a(argb);
        int r = Math.min(255, Math.round(Colors.r(argb) * shade)), g = Math.min(255, Math.round(Colors.g(argb) * shade)), b = Math.min(255, Math.round(Colors.b(argb) * shade));
        for (int i = 0; i < 12; i += 3) vc.vertex(m, p[i], p[i + 1], p[i + 2]).color(r, g, b, a);
    }
}
