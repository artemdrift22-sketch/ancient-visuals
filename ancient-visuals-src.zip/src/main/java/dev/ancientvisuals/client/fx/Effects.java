package dev.ancientvisuals.client.fx;

import dev.ancientvisuals.core.diag.Diagnostics;
import dev.ancientvisuals.core.particle.EffectCatalog;
import dev.ancientvisuals.core.particle.EffectDef;
import dev.ancientvisuals.core.particle.Trigger;
import dev.ancientvisuals.core.profile.SectionCodec;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Effect lookup: catalog definitions plus user overrides and user-made copies (stored per profile). */
public final class Effects implements SectionCodec {
    public static final Effects INSTANCE = new Effects();
    private final Map<String, EffectDef> overrides = new LinkedHashMap<>();
    private final Map<String, EffectDef> custom = new LinkedHashMap<>();

    public static EffectDef get(String id) {
        if (id == null || id.equals("none")) return null;
        EffectDef d = INSTANCE.custom.get(id);
        if (d == null) d = INSTANCE.overrides.get(id);
        if (d == null) d = EffectCatalog.get(id);
        return d != null && d.enabled ? d : null;
    }
    public static EffectDef raw(String id) { EffectDef d = INSTANCE.custom.get(id); if (d == null) d = INSTANCE.overrides.get(id); return d != null ? d : EffectCatalog.get(id); }
    public static List<String> options() { List<String> l = new ArrayList<>(); l.add("none"); l.addAll(EffectCatalog.ids()); l.addAll(INSTANCE.custom.keySet()); return l; }
    public static List<String> allIds() { List<String> l = new ArrayList<>(EffectCatalog.ids()); l.addAll(INSTANCE.custom.keySet()); return l; }
    public static String firstFor(Trigger t, String fallback) { List<EffectDef> l = EffectCatalog.forTrigger(t); return l.isEmpty() ? fallback : l.get(0).id; }
    public static boolean isCustom(String id) { return INSTANCE.custom.containsKey(id); }
    public static boolean isOverridden(String id) { return INSTANCE.overrides.containsKey(id); }

    public static void save(EffectDef d) {
        d.validate();
        if (INSTANCE.custom.containsKey(d.id) || EffectCatalog.get(d.id) == null) INSTANCE.custom.put(d.id, d.copy()); else INSTANCE.overrides.put(d.id, d.copy());
    }
    public static void resetOverride(String id) { INSTANCE.overrides.remove(id); }
    public static void deleteCustom(String id) { INSTANCE.custom.remove(id); }
    public static EffectDef duplicate(String id) {
        EffectDef src = raw(id); if (src == null) return null;
        int n = 1; while (INSTANCE.custom.containsKey("custom_" + src.id + "_" + n)) n++;
        EffectDef d = new EffectDef("custom_" + src.id + "_" + n, src.name + " #" + n, src.category, src.shape, src.kind);
        d.fromJson(src.toJson());
        INSTANCE.custom.put(d.id, d);
        return d;
    }

    @Override public Object save() {
        Map<String, Object> m = new LinkedHashMap<>();
        Map<String, Object> o = new LinkedHashMap<>(); overrides.forEach((k, v) -> o.put(k, v.toJson()));
        Map<String, Object> c = new LinkedHashMap<>(); custom.forEach((k, v) -> { Map<String, Object> j = new LinkedHashMap<>(v.toJson()); j.put("_name", v.name); j.put("_category", v.category.name()); j.put("_shape", v.shape.name()); j.put("_kind", v.kind.name()); c.put(k, j); });
        m.put("overrides", o); m.put("custom", c);
        return m;
    }
    @SuppressWarnings("unchecked")
    @Override public void load(Object data) {
        reset();
        if (!(data instanceof Map<?, ?> m)) return;
        if (m.get("overrides") instanceof Map<?, ?> o) for (Map.Entry<?, ?> e : o.entrySet()) {
            EffectDef base = EffectCatalog.get(String.valueOf(e.getKey()));
            if (base == null || !(e.getValue() instanceof Map<?, ?> j)) continue;
            EffectDef d = base.copy(); d.fromJson((Map<String, Object>) j); d.validate(); overrides.put(base.id, d);
        }
        if (m.get("custom") instanceof Map<?, ?> c) for (Map.Entry<?, ?> e : c.entrySet()) {
            try {
                Map<String, Object> j = (Map<String, Object>) e.getValue();
                String id = String.valueOf(e.getKey());
                if (!id.matches("[a-z0-9_]{1,64}")) continue;
                EffectDef d = new EffectDef(id, String.valueOf(j.getOrDefault("_name", id)),
                    dev.ancientvisuals.core.particle.EffectCategory.valueOf(String.valueOf(j.get("_category"))),
                    dev.ancientvisuals.core.particle.EmitterShape.valueOf(String.valueOf(j.get("_shape"))),
                    dev.ancientvisuals.core.particle.ParticleKind.valueOf(String.valueOf(j.get("_kind"))));
                d.fromJson(j); d.validate(); custom.put(id, d);
            } catch (RuntimeException ex) { Diagnostics.warn("effects", "skipped broken custom effect " + e.getKey()); }
        }
    }
    @Override public void reset() { overrides.clear(); custom.clear(); }
}
