package dev.ancientvisuals.client.fx;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.core.diag.Diagnostics;
import dev.ancientvisuals.core.particle.ParticleKind;
import dev.ancientvisuals.core.particle.ParticleRequest;
import dev.ancientvisuals.core.particle.ParticleSink;
import dev.ancientvisuals.core.util.Colors;
import dev.ancientvisuals.mixin.ParticleAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.Particle;
import net.minecraft.particle.*;
import org.joml.Vector3f;

import java.util.ArrayDeque;
import java.util.Iterator;

/** Bridges core particle requests to vanilla particles and animates alpha/colour/rotation of the ones we created. */
public final class McParticleSink implements ParticleSink {
    private static final int MAX_TRACKED = 2000;
    private static final class Tracked { Particle p; ParticleRequest r; int age; }
    private final ArrayDeque<Tracked> tracked = new ArrayDeque<>();
    private int failures, spawnedTotal;

    public int live() { return tracked.size(); }
    public int spawnedTotal() { return spawnedTotal; }

    static ParticleEffect effect(ParticleRequest r) {
        if (r.kind == ParticleKind.DUST) {
            float sc = Math.max(0.2f, Math.min(4f, r.size));
            Vector3f a = vec(r.colorStart), b = vec(r.colorEnd);
            if (r.colorStart == r.colorEnd) return new DustParticleEffect(a, sc);
            return new DustColorTransitionParticleEffect(a, b, sc);
        }
        return switch (r.kind.name()) {
            case "SPARK" -> ParticleTypes.ELECTRIC_SPARK; case "END_ROD" -> ParticleTypes.END_ROD; case "ENCHANT" -> ParticleTypes.ENCHANT;
            case "FLAME" -> ParticleTypes.FLAME; case "SOUL_FLAME" -> ParticleTypes.SOUL_FIRE_FLAME; case "SMOKE" -> ParticleTypes.SMOKE;
            case "CLOUD" -> ParticleTypes.CLOUD; case "BUBBLE" -> ParticleTypes.BUBBLE_POP; case "CHERRY" -> ParticleTypes.CHERRY_LEAVES;
            case "CRIT" -> ParticleTypes.CRIT; case "MAGIC_CRIT" -> ParticleTypes.ENCHANTED_HIT; case "HEART" -> ParticleTypes.HEART;
            case "NOTE" -> ParticleTypes.NOTE; case "PORTAL" -> ParticleTypes.PORTAL; case "REVERSE_PORTAL" -> ParticleTypes.REVERSE_PORTAL;
            case "SPLASH" -> ParticleTypes.SPLASH; case "DRIP_WATER" -> ParticleTypes.FALLING_WATER; case "LAVA" -> ParticleTypes.LAVA;
            case "WAX" -> ParticleTypes.WAX_ON; case "SCRAPE" -> ParticleTypes.SCRAPE; case "FIREWORK" -> ParticleTypes.FIREWORK;
            case "TOTEM" -> ParticleTypes.TOTEM_OF_UNDYING; case "ASH" -> ParticleTypes.ASH; case "SPORE" -> ParticleTypes.SPORE_BLOSSOM_AIR;
            case "SOUL" -> ParticleTypes.SOUL; case "HAPPY" -> ParticleTypes.HAPPY_VILLAGER; case "WITCH" -> ParticleTypes.WITCH;
            case "DRAGON" -> ParticleTypes.DRAGON_BREATH; case "NAUTILUS" -> ParticleTypes.NAUTILUS; case "DOLPHIN" -> ParticleTypes.DOLPHIN;
            case "POOF" -> ParticleTypes.POOF; case "SWEEP" -> ParticleTypes.SWEEP_ATTACK; case "SCULK_SOUL" -> ParticleTypes.SCULK_SOUL;
            case "WHITE_SMOKE" -> ParticleTypes.WHITE_SMOKE; case "DUST_PLUME" -> ParticleTypes.DUST_PLUME;
            default -> ParticleTypes.GLOW;
        };
    }
    private static Vector3f vec(int c) { return new Vector3f(Colors.r(c) / 255f, Colors.g(c) / 255f, Colors.b(c) / 255f); }

    @Override public boolean spawn(ParticleRequest r) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.world == null || mc.particleManager == null || r.kind == null) return false;
        Particle p;
        try { p = mc.particleManager.addParticle(effect(r), r.x, r.y, r.z, r.vx, r.vy, r.vz); }
        catch (Throwable t) { if (failures++ < 5) Diagnostics.error("particles", "spawn failed for " + r.kind, t); return false; }
        if (p == null) return false;
        spawnedTotal++;
        try {
            if (r.kind.tintable && r.kind != ParticleKind.DUST) p.setColor(Colors.r(r.colorStart) / 255f, Colors.g(r.colorStart) / 255f, Colors.b(r.colorStart) / 255f);
            p.setMaxAge(Math.max(1, r.lifetime));
            if (r.kind != ParticleKind.DUST) p.scale(Math.max(0.05f, r.size));
            ParticleAccessor a = (ParticleAccessor) p;
            a.setAvGravity(r.gravity);
            a.setAvVelocityMultiplier(r.drag);
            a.setAvCollides(r.collides);
            a.setAvAlpha(Math.max(0f, Math.min(1f, r.alphaStart)));
        } catch (Throwable t) { if (failures++ < 5) Diagnostics.error("particles", "particle setup failed", t); }
        Tracked tr = new Tracked(); tr.p = p; tr.r = r;
        tracked.addLast(tr);
        while (tracked.size() > MAX_TRACKED) tracked.pollFirst();
        return true;
    }

    public void tick() {
        boolean animate = AV.particles == null || AV.particles.animate.on();
        Iterator<Tracked> it = tracked.iterator();
        while (it.hasNext()) {
            Tracked t = it.next();
            if (!t.p.isAlive()) { it.remove(); continue; }
            t.age++;
            if (!animate) continue;
            try {
                ParticleRequest r = t.r;
                double f = Math.min(1.0, t.age / (double) Math.max(1, r.lifetime));
                double e = r.alphaCurve == null ? f : r.alphaCurve.apply(f);
                ParticleAccessor a = (ParticleAccessor) t.p;
                a.setAvAlpha((float) Math.max(0, Math.min(1, r.alphaStart + (r.alphaEnd - r.alphaStart) * e)));
                if (r.kind.tintable && r.kind != ParticleKind.DUST && r.colorStart != r.colorEnd) {
                    int c = Colors.lerp(r.colorStart, r.colorEnd, f);
                    t.p.setColor(Colors.r(c) / 255f, Colors.g(c) / 255f, Colors.b(c) / 255f);
                }
                if (r.angularVelocity != 0) { float ang = a.getAvAngle(); a.setAvPrevAngle(ang); a.setAvAngle(ang + r.angularVelocity); }
            } catch (Throwable ignored) { }
        }
    }

    public void clear() { tracked.clear(); }
}
