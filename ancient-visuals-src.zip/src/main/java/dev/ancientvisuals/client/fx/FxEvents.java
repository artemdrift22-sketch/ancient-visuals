package dev.ancientvisuals.client.fx;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.client.UiSounds;
import dev.ancientvisuals.core.diag.Diagnostics;
import dev.ancientvisuals.core.particle.EffectDef;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.registry.RegistryKey;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Detects gameplay events from local client state only (no packets, no hidden information)
 * and plays the configured effects. Everything here is cosmetic and visible only to this client.
 */
public final class FxEvents {
    private FxEvents() {}

    // session statistics (real, counted locally)
    public static int hits, crits, kills, jumps, totemsPopped, damageTaken;
    public static double distance;
    // combat feedback state
    public static float hitPulse;
    public static int hitmarkerTicks, hitmarkerMax = 1;
    public static boolean hitmarkerCrit;
    public static Entity lastTarget;
    public static long lastAttackMs;
    public static float lastDamageAmount;
    public static long lastDamageMs;

    private static boolean wasOnGround = true, wasInWater, wasUsing, init;
    private static float maxFall, lastHealth = -1, lastYaw;
    private static RegistryKey<World> lastDim;
    private static double lx, ly, lz, stepAcc;
    private static long lastMoveMs = System.currentTimeMillis();
    private static int lastHurt, lastItems = -1;
    private static Object lastScreen;

    public static void reset() { init = false; lastTarget = null; lastHealth = -1; lastItems = -1; lastDim = null; }

    public static void resetSession() { hits = crits = kills = jumps = totemsPopped = damageTaken = 0; distance = 0; }

    public static double intensity(boolean firstPerson) {
        if (AV.particles == null || !AV.particles.isEnabled()) return 0;
        double i = AV.particles.intensity.d();
        if (firstPerson) i *= AV.particles.firstPersonDensity.d();
        return i;
    }

    public static boolean play(String id, double x, double y, double z, double yaw, boolean selfFirstPerson) {
        EffectDef d = Effects.get(id);
        if (d == null) return false;
        double inten = intensity(selfFirstPerson);
        if (inten <= 0) return false;
        MinecraftClient mc = MinecraftClient.getInstance();
        double dist = 0;
        try { dist = mc.gameRenderer.getCamera().getPos().distanceTo(new Vec3d(x, y, z)); } catch (Throwable ignored) { }
        try {
            int n = AV.effects.play(d, x, y, z, yaw, inten, dist);
            if (AV.developer != null && AV.developer.isEnabled() && AV.developer.logEvents.on()) Diagnostics.info("fx", id + " -> " + n + " particles");
            return n > 0;
        } catch (Throwable t) { Diagnostics.error("fx", "effect " + id + " failed", t); return false; }
    }

    private static boolean firstPerson(MinecraftClient mc) { return mc.options.getPerspective().isFirstPerson(); }

    public static void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) { reset(); return; }
        long now = System.currentTimeMillis();
        boolean first = firstPerson(mc);
        double x = p.getX(), y = p.getY(), z = p.getZ();
        float yaw = p.getYaw();
        if (!init) {
            init = true; lx = x; ly = y; lz = z; lastYaw = yaw; wasOnGround = p.isOnGround(); lastHealth = p.getHealth();
            lastDim = mc.world.getRegistryKey(); wasInWater = p.isTouchingWater(); lastHurt = p.hurtTime; lastScreen = mc.currentScreen;
        }
        double dxz = Math.hypot(x - lx, z - lz);
        if (dxz < 5) distance += dxz;
        if (dxz > 0.01 || Math.abs(y - ly) > 0.01 || Math.abs(yaw - lastYaw) > 0.5f) lastMoveMs = now;
        if (hitPulse > 0) hitPulse = Math.max(0, hitPulse - 0.18f);
        if (hitmarkerTicks > 0) hitmarkerTicks--;
        boolean menus = mc.currentScreen != null && AV.performance != null && AV.performance.isEnabled() && AV.performance.pauseInMenus.on();

        var mv = AV.movement;
        boolean mvOn = mv != null && mv.isEnabled() && !(first && !mv.firstPerson.on());
        boolean on = p.isOnGround();
        if (wasOnGround && !on && p.getVelocity().y > 0.2 && !p.isClimbing() && !p.isTouchingWater()) {
            jumps++;
            if (mvOn) play(mv.jump.get(), x, y, z, yaw, first);
        }
        if (!on) maxFall = Math.max(maxFall, p.fallDistance);
        if (!wasOnGround && on) {
            if (mvOn && maxFall >= mv.minFall.d()) play(mv.land.get(), x, y, z, yaw, first);
            maxFall = 0;
        }
        if (on && mvOn && !menus) {
            stepAcc += dxz;
            if (stepAcc >= mv.stepDistance.d()) { stepAcc = 0; if (!"none".equals(mv.footstep.get())) play(mv.footstep.get(), x, y, z, yaw, first); }
            if (p.isSprinting() && dxz > 0.05) {
                EffectDef d = Effects.get(mv.sprint.get());
                if (d != null) AV.effects.emitContinuous("sprint", d, x, y, z, yaw, intensity(first));
            }
        }
        wasOnGround = on;

        boolean water = p.isTouchingWater();
        if (water && !wasInWater && mvOn) play(mv.water.get(), x, y, z, yaw, first);
        wasInWater = water;

        RegistryKey<World> dim = mc.world.getRegistryKey();
        if (lastDim != null && dim != lastDim && mvOn) play(mv.portal.get(), x, y, z, yaw, first);
        lastDim = dim;

        boolean using = p.isUsingItem();
        if (using && !wasUsing && mvOn && !"none".equals(mv.itemUse.get())) play(mv.itemUse.get(), x, y + 1, z, yaw, first);
        wasUsing = using;

        int items = countItems(p);
        if (lastItems >= 0 && items > lastItems && mc.currentScreen == null && mvOn) play(mv.pickup.get(), x, y + 0.5, z, yaw, first);
        lastItems = items;

        Object scr = mc.currentScreen;
        if (scr != lastScreen) {
            if (scr instanceof HandledScreen<?> && !(scr instanceof InventoryScreen) && !(scr instanceof CreativeInventoryScreen) && mvOn
                    && mc.crosshairTarget instanceof BlockHitResult bh && bh.getType() == HitResult.Type.BLOCK) {
                BlockPos bp = bh.getBlockPos();
                play(mv.chest.get(), bp.getX() + 0.5, bp.getY() + 1.0, bp.getZ() + 0.5, yaw, false);
            }
            lastScreen = scr;
        }

        float hp = p.getHealth();
        var hf = AV.hitFx;
        boolean hfOn = hf != null && hf.isEnabled();
        if (p.hurtTime > lastHurt && p.maxHurtTime > 0 && p.hurtTime == p.maxHurtTime) {
            damageTaken++;
            lastDamageAmount = Math.max(0, lastHealth - hp);
            lastDamageMs = now;
            if (hfOn) play(hf.damage.get(), x, y + 1, z, yaw, first);
        }
        lastHurt = p.hurtTime;
        if (lastHealth > 0 && hp > lastHealth + 0.99f && hfOn) play(hf.heal.get(), x, y + 0.2, z, yaw, first);
        lastHealth = hp;

        // kill confirmation: only for the entity this client attacked, and only if it visibly died shortly after
        if (lastTarget != null) {
            if (now - lastAttackMs > 3000 || lastTarget.isRemoved() && !(lastTarget instanceof LivingEntity le0 && le0.isDead())) lastTarget = null;
            else if (lastTarget instanceof LivingEntity le && (le.isDead() || le.getHealth() <= 0)) {
                kills++;
                if (hfOn) play(hf.kill.get(), le.getX(), le.getY() + le.getHeight() * 0.5, le.getZ(), yaw, false);
                lastTarget = null;
            }
        }

        var am = AV.ambient;
        if (am != null && am.isEnabled() && !menus) {
            EffectDef d = Effects.get(am.effect.get());
            if (d != null) AV.effects.emitContinuous("ambient", d, x, y, z, yaw, intensity(first));
            if (now - lastMoveMs > am.idleSeconds.i() * 1000L) {
                EffectDef i = Effects.get(am.idle.get());
                if (i != null) AV.effects.emitContinuous("idle", i, x, y, z, yaw, intensity(first));
            }
        }
        if (!menus) TrailFx.tick(p, first);
        lx = x; ly = y; lz = z; lastYaw = yaw;
    }

    private static int countItems(ClientPlayerEntity p) {
        int n = 0;
        var inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) n += inv.getStack(i).getCount();
        return n;
    }

    /** Called from the attack callback when this client attacks an entity. */
    public static void onAttack(ClientPlayerEntity p, Entity target) {
        hits++;
        boolean crit = p.fallDistance > 0 && !p.isOnGround() && !p.isClimbing() && !p.isTouchingWater() && !p.hasVehicle()
                && !p.isSprinting() && p.getAttackCooldownProgress(0.5f) > 0.9f && target instanceof LivingEntity;
        if (crit) crits++;
        lastTarget = target;
        lastAttackMs = System.currentTimeMillis();
        var hf = AV.hitFx;
        if (hf == null || !hf.isEnabled()) return;
        double tx = target.getX(), ty = target.getY() + target.getHeight() * 0.6, tz = target.getZ();
        play(crit ? hf.crit.get() : hf.hit.get(), tx, ty, tz, p.getYaw(), false);
        if (hf.hitmarker.on()) { hitmarkerTicks = hitmarkerMax = Math.max(1, hf.hitmarkerTicks.i()); hitmarkerCrit = crit; }
        if (hf.hitColor.on() && !AV.reduceFlashing()) hitPulse = 1f;
        if (hf.hitSound.on()) UiSounds.hit((float) hf.hitSoundVolume.d());
    }

    /** Called when the vanilla totem animation starts for this client. */
    public static void onTotem() {
        totemsPopped++;
        MinecraftClient mc = MinecraftClient.getInstance();
        var p = mc.player;
        var t = AV.totem;
        if (p == null || t == null || !t.isEnabled()) return;
        play(t.effect.get(), p.getX(), p.getY() + 1, p.getZ(), p.getYaw(), firstPerson(mc));
        if (t.announce.on()) p.sendMessage(Text.translatable("av.notice.totem"), true);
    }

    /** Plays an effect in front of the player (Particle Studio "test in world"). */
    public static boolean test(String id) {
        MinecraftClient mc = MinecraftClient.getInstance();
        var p = mc.player;
        if (p == null) return false;
        Vec3d look = p.getRotationVec(1f);
        return play(id, p.getX() + look.x * 2.5, p.getY(), p.getZ() + look.z * 2.5, p.getYaw(), false);
    }
}
