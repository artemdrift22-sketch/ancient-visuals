package dev.ancientvisuals.client.fx;

import com.mojang.blaze3d.systems.RenderSystem;
import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.core.util.Colors;
import net.minecraft.block.enums.CameraSubmersionType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.world.World;

/**
 * Fog colour/distance presets on top of the vanilla fog. Never extends fog beyond the vanilla end distance
 * and never weakens blindness/darkness, lava or water fog.
 */
public final class WorldFx {
    private WorldFx() {}

    public static boolean active() {
        var w = AV.world;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (w == null || !w.isEnabled() || mc.world == null) return false;
        return w.otherDims.on() || mc.world.getRegistryKey() == World.OVERWORLD;
    }

    private static boolean impaired(Camera camera) {
        if (camera.getSubmersionType() != CameraSubmersionType.NONE) return true;
        return camera.getFocusedEntity() instanceof LivingEntity le && (le.hasStatusEffect(StatusEffects.BLINDNESS) || le.hasStatusEffect(StatusEffects.DARKNESS));
    }

    public static void afterFog(Camera camera, BackgroundRenderer.FogType type) {
        if (!active() || type != BackgroundRenderer.FogType.FOG_TERRAIN || impaired(camera)) return;
        AV.hook("fog");
        double k = AV.world.distanceMul();
        if (Math.abs(k - 1) < 1e-3) return;
        float start = RenderSystem.getShaderFogStart(), end = RenderSystem.getShaderFogEnd();
        float ns = (float) Math.min(start * k, end * 0.97);
        float ne = (float) (end * Math.min(1.0, k));
        RenderSystem.setShaderFogStart(Math.min(ns, ne * 0.97f));
        RenderSystem.setShaderFogEnd(ne);
    }

    /** @return tinted fog/clear colour or null when inactive. */
    public static float[] tint(Camera camera, float r, float g, float b) {
        if (!active() || camera == null || impaired(camera)) return null;
        AV.hook("fog_color");
        double t = AV.world.tint.d();
        int c = AV.world.color();
        return new float[]{
            (float) (r + (Colors.r(c) / 255f - r) * t),
            (float) (g + (Colors.g(c) / 255f - g) * t),
            (float) (b + (Colors.b(c) / 255f - b) * t)};
    }
}
