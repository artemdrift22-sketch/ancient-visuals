package dev.ancientvisuals.client.module;

import dev.ancientvisuals.core.module.Category;
import dev.ancientvisuals.core.module.Module;
import dev.ancientvisuals.core.setting.BoolSetting;
import dev.ancientvisuals.core.setting.DoubleSetting;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.*;
import net.minecraft.util.Arm;
import net.minecraft.util.math.RotationAxis;

public final class ViewModelModule extends Module {
    public final DoubleSetting x = add(new DoubleSetting("x", "Offset X", 0, -1, 1, 0.01));
    public final DoubleSetting y = add(new DoubleSetting("y", "Offset Y", 0, -1, 1, 0.01));
    public final DoubleSetting z = add(new DoubleSetting("z", "Offset Z", 0, -1, 1, 0.01));
    public final DoubleSetting rotX = add(new DoubleSetting("rot_x", "Rotation X", 0, -180, 180, 1)).suffix("\u00B0");
    public final DoubleSetting rotY = add(new DoubleSetting("rot_y", "Rotation Y", 0, -180, 180, 1)).suffix("\u00B0");
    public final DoubleSetting rotZ = add(new DoubleSetting("rot_z", "Rotation Z", 0, -180, 180, 1)).suffix("\u00B0");
    public final DoubleSetting scale = add(new DoubleSetting("scale", "Scale", 1, 0.3, 2, 0.01));
    public final BoolSetting mirror = add(new BoolSetting("mirror", "Mirror for left hand", true));
    public final BoolSetting perItem = add(new BoolSetting("per_item", "Per-item presets", false)).desc("Extra offsets for weapons, tools, blocks and ranged items.");
    private static final String[] GROUPS = {"weapon", "tool", "block", "ranged"};
    private static final String[] GROUP_NAMES = {"Weapons", "Tools", "Blocks", "Ranged"};
    private final DoubleSetting[][] groups = new DoubleSetting[4][];

    public ViewModelModule() {
        super("viewmodel", "ViewModel", "First-person hand/item position, rotation and scale.", Category.MODEL, false);
        for (int i = 0; i < 4; i++) {
            String g = GROUPS[i], n = GROUP_NAMES[i];
            groups[i] = new DoubleSetting[]{
                add(new DoubleSetting(g + "_x", n + ": X", 0, -1, 1, 0.01)),
                add(new DoubleSetting(g + "_y", n + ": Y", 0, -1, 1, 0.01)),
                add(new DoubleSetting(g + "_z", n + ": Z", 0, -1, 1, 0.01)),
                add(new DoubleSetting(g + "_scale", n + ": scale", 1, 0.3, 2, 0.01))};
            for (DoubleSetting d : groups[i]) { d.visibleWhen(perItem::on); d.inGroup(n); }
        }
    }

    public void apply(MatrixStack m, Arm arm, ItemStack stack) {
        float side = arm == Arm.RIGHT || !mirror.on() ? 1f : -1f;
        double dx = x.d(), dy = y.d(), dz = z.d(), sc = scale.d();
        if (perItem.on() && stack != null && !stack.isEmpty()) {
            int gi = group(stack);
            if (gi >= 0) { DoubleSetting[] g = groups[gi]; dx += g[0].d(); dy += g[1].d(); dz += g[2].d(); sc *= g[3].d(); }
        }
        m.translate((float) (dx * side), (float) dy, (float) dz);
        if (rotY.d() != 0) m.multiply(RotationAxis.POSITIVE_Y.rotationDegrees((float) rotY.d() * side));
        if (rotX.d() != 0) m.multiply(RotationAxis.POSITIVE_X.rotationDegrees((float) rotX.d()));
        if (rotZ.d() != 0) m.multiply(RotationAxis.POSITIVE_Z.rotationDegrees((float) rotZ.d() * side));
        if (sc != 1) m.scale((float) sc, (float) sc, (float) sc);
    }

    static int group(ItemStack s) {
        Item i = s.getItem();
        if (i instanceof SwordItem || i instanceof AxeItem || i instanceof TridentItem || i instanceof MaceItem) return 0;
        if (i instanceof MiningToolItem || i instanceof ShearsItem) return 1;
        if (i instanceof BlockItem) return 2;
        if (i instanceof RangedWeaponItem) return 3;
        return -1;
    }
}
