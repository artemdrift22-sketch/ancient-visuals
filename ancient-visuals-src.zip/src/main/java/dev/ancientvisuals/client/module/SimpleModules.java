package dev.ancientvisuals.client.module;

import dev.ancientvisuals.client.fx.Effects;
import dev.ancientvisuals.core.module.Category;
import dev.ancientvisuals.core.module.Module;
import dev.ancientvisuals.core.particle.Trigger;
import dev.ancientvisuals.core.perf.QualityLevel;
import dev.ancientvisuals.core.setting.*;
import dev.ancientvisuals.core.texture.HudSkin;
import dev.ancientvisuals.core.util.Easing;
import dev.ancientvisuals.core.companion.Companions;

/** Smaller modules grouped in one file. Each nested class is an independent module. */
public final class SimpleModules {
    private SimpleModules() {}

    public static final class Accessibility extends Module {
        public final BoolSetting highContrast = add(new BoolSetting("high_contrast", "High contrast", false)).desc("Forces readable contrast in every theme.");
        public final BoolSetting reducedMotion = add(new BoolSetting("reduced_motion", "Reduced motion", false)).desc("Disables GUI animations and camera-near motion effects.");
        public final BoolSetting reduceFlashing = add(new BoolSetting("reduce_flashing", "Reduce flashing", false)).desc("Softens hit/kill flashes and pulses.");
        public final BoolSetting largeTargets = add(new BoolSetting("large_targets", "Larger click targets", false));
        public final BoolSetting focusOutline = add(new BoolSetting("focus_outline", "Strong focus outline", true));
        public Accessibility() { super("accessibility", "Accessibility", "Contrast, motion and readability options.", Category.SYSTEM, true); }
        @Override public boolean alwaysOn() { return true; }
    }

    public static final class ClickGui extends Module {
        public final DoubleSetting uiScale = add(new DoubleSetting("ui_scale", "GUI scale", 1.0, 0.6, 1.6, 0.05));
        public final DoubleSetting dim = add(new DoubleSetting("background_dim", "Background dim", 0.45, 0.0, 0.9, 0.05));
        public final BoolSetting tooltips = add(new BoolSetting("tooltips", "Tooltips", true));
        public final BoolSetting rememberPos = add(new BoolSetting("remember_position", "Remember window position", true));
        public final BoolSetting showIds = add(new BoolSetting("show_ids", "Show technical ids", false));
        public final EnumSetting<Sort> sort = add(new EnumSetting<>("sort", "Module sorting", Sort.CATEGORY));
        public enum Sort { CATEGORY, NAME, ENABLED_FIRST, RECENT }
        public ClickGui() { super("click_gui", "ClickGUI", "Main menu behaviour. Default key: Right Shift.", Category.GUI, true); }
        @Override public boolean alwaysOn() { return true; }
    }

    public static final class UiAudio extends Module {
        public final DoubleSetting volume = add(new DoubleSetting("volume", "Volume", 0.5, 0.0, 1.0, 0.05));
        public final BoolSetting clicks = add(new BoolSetting("clicks", "Clicks and toggles", true));
        public final BoolSetting panels = add(new BoolSetting("panels", "Panel open/close", true));
        public final BoolSetting notices = add(new BoolSetting("notices", "Warnings, errors, success", true));
        public UiAudio() { super("ui_audio", "UI Sounds", "Interface sounds. Turn the module off to mute everything.", Category.SYSTEM, true); }
    }

    public static final class Swing extends Module {
        public enum Style { VANILLA_REFINED, SMOOTH_ARC, COMPACT, WIDE_ARC, ELEGANT, HEAVY_MOTION, QUICK_VISUAL, MINIMAL, USER_CURVE }
        public final EnumSetting<Style> style = add(new EnumSetting<>("style", "Swing style", Style.SMOOTH_ARC)).desc("Changes the timing curve of the first-person swing (visual only).");
        public final EnumSetting<Easing> curve = add(new EnumSetting<>("user_curve", "User curve", Easing.IN_OUT_SINE));
        public Swing() { super("swing", "Swing Styles", "First-person swing animation curves.", Category.MODEL, false); curve.visibleWhen(() -> style.get() == Style.USER_CURVE); }
        public float map(float t) {
            double r = switch (style.get()) {
                case VANILLA_REFINED -> t;
                case SMOOTH_ARC -> Easing.IN_OUT_SINE.apply(t);
                case COMPACT -> Easing.OUT_CUBIC.apply(t);
                case WIDE_ARC -> Math.min(1.0, Easing.OUT_BACK.apply(t));
                case ELEGANT -> Easing.IN_OUT_CUBIC.apply(t);
                case HEAVY_MOTION -> Easing.IN_QUAD.apply(t);
                case QUICK_VISUAL -> Easing.OUT_QUAD.apply(t);
                case MINIMAL -> Math.sqrt(Math.max(0, t));
                case USER_CURVE -> curve.get().apply(t);
            };
            return (float) Math.max(0, Math.min(1, r));
        }
    }

    public static final class MovementFx extends Module {
        public final ChoiceSetting jump = add(FxChoice.of("jump", "Jump effect", Trigger.JUMP, "jump_circle"));
        public final ChoiceSetting land = add(FxChoice.of("land", "Landing effect", Trigger.LAND, "landing_ring"));
        public final DoubleSetting minFall = add(new DoubleSetting("min_fall", "Min. fall for landing", 1.2, 0.0, 10.0, 0.1)).suffix(" b");
        public final ChoiceSetting sprint = add(FxChoice.of("sprint", "Sprint effect", Trigger.SPRINT, "sprint_streaks"));
        public final ChoiceSetting footstep = add(FxChoice.of("footstep", "Footsteps", Trigger.MOVE, "none"));
        public final DoubleSetting stepDistance = add(new DoubleSetting("step_distance", "Footstep distance", 1.6, 0.5, 5.0, 0.1));
        public final ChoiceSetting water = add(FxChoice.of("water", "Water entry", Trigger.WATER, "water_ripples"));
        public final ChoiceSetting portal = add(FxChoice.of("portal", "Dimension change", Trigger.PORTAL, "portal_fragments"));
        public final ChoiceSetting itemUse = add(FxChoice.of("item_use", "Item use", Trigger.ITEM_USE, "none"));
        public final ChoiceSetting pickup = add(FxChoice.of("pickup", "Item pickup", Trigger.PICKUP, "item_pickup_spark"));
        public final ChoiceSetting chest = add(new ChoiceSetting("chest", "Container open", "chest_open_glimmer", Effects::options));
        public final BoolSetting firstPerson = add(new BoolSetting("first_person", "Show in first person", true));
        public MovementFx() { super("movement_fx", "Movement Visuals", "JumpCircle, landing rings, sprint streaks, footsteps, water and portal effects.", Category.MOVEMENT, true); }
    }

    public static final class Trails extends Module {
        public enum Mode { THIN_LINE, GLOWING_RIBBON, SPRITE_SEQUENCE, STAR_PATH, GEOMETRIC_FRAGMENTS, FADING_DOTS, GRADIENT, DOUBLE_RIBBON, COMET_TAIL, RING_TRAIL, ORNAMENTAL_RIBBON, DUST_TRAIL, COLOR_PULSES }
        public final EnumSetting<Mode> mode = add(new EnumSetting<>("mode", "Trail mode", Mode.GLOWING_RIBBON));
        public final GradientSetting colors = add(new GradientSetting("colors", "Colours", 0xFF2F6FD6, 0xFF8FC4FF, 0xFFD4A537));
        public final IntSetting length = add(new IntSetting("length", "Lifetime", 20, 4, 80)).suffix(" t");
        public final DoubleSetting width = add(new DoubleSetting("width", "Width", 0.35, 0.05, 1.5, 0.05));
        public final DoubleSetting density = add(new DoubleSetting("density", "Density", 1.0, 0.2, 3.0, 0.1));
        public final DoubleSetting height = add(new DoubleSetting("height", "Height", 0.15, 0.0, 2.0, 0.05));
        public final BoolSetting onlySprint = add(new BoolSetting("only_sprint", "Only while sprinting", false));
        public final BoolSetting firstPerson = add(new BoolSetting("first_person", "Show in first person", true));
        public Trails() { super("trails", "Trails", "Movement trails in 13 modes.", Category.MOVEMENT, false); }
        @Override public boolean heavy() { return true; }
    }

    public static final class HitFx extends Module {
        public final BoolSetting hitmarker = add(new BoolSetting("hitmarker", "Hitmarker", true));
        public final ColorSetting hitmarkerColor = add(new ColorSetting("hitmarker_color", "Hitmarker colour", 0xFFF4F1EA, true));
        public final ColorSetting critColor = add(new ColorSetting("crit_color", "Critical colour", 0xFFD4A537, true));
        public final IntSetting hitmarkerTicks = add(new IntSetting("hitmarker_ticks", "Hitmarker duration", 6, 2, 20)).suffix(" t");
        public final BoolSetting hitColor = add(new BoolSetting("hit_color", "HitColor pulse", true)).desc("Briefly tints the crosshair after a hit.");
        public final ColorSetting hitColorValue = add(new ColorSetting("hit_color_value", "HitColor", 0xFFFF5A5A, true));
        public final ChoiceSetting hit = add(FxChoice.of("hit_effect", "Hit particles", Trigger.HIT, "impact_sparks"));
        public final ChoiceSetting crit = add(FxChoice.of("crit_effect", "Critical hit", Trigger.CRIT, "critical_stars"));
        public final ChoiceSetting kill = add(FxChoice.of("kill_effect", "Kill effect", Trigger.KILL, "olympus_burst")).desc("Only plays when the attacked entity is seen dying shortly after your hit.");
        public final ChoiceSetting damage = add(FxChoice.of("damage_effect", "Damage taken", Trigger.DAMAGE_TAKEN, "damage_flash"));
        public final ChoiceSetting heal = add(FxChoice.of("heal_effect", "Heal", Trigger.HEAL, "healing_motifs"));
        public final BoolSetting hitSound = add(new BoolSetting("hit_sound", "Hit sound", false));
        public final DoubleSetting hitSoundVolume = add(new DoubleSetting("hit_sound_volume", "Hit sound volume", 0.5, 0.0, 1.0, 0.05));
        public final BoolSetting lowHealthVignette = add(new BoolSetting("low_health_vignette", "Low health edge glow", true));
        public final DoubleSetting lowHealthAt = add(new DoubleSetting("low_health_at", "Low health threshold", 6.0, 1.0, 20.0, 0.5));
        public HitFx() { super("hit_fx", "Hit Effects", "Hitmarker, HitColor, hit/crit/kill particles, hit sound.", Category.COMBAT, true); }
    }

    public static final class TotemFx extends Module {
        public final ChoiceSetting effect = add(FxChoice.of("effect", "Totem effect", Trigger.TOTEM, "totem_halo"));
        public final BoolSetting announce = add(new BoolSetting("announce", "Local action-bar notice", true));
        public TotemFx() { super("totem_fx", "Totem Visuals", "Extra effect and notice when your totem pops (from the vanilla totem animation event).", Category.COMBAT, true); }
    }

    public static final class WorldFog extends Module {
        public enum Preset { OLYMPUS_DAYLIGHT, AEGEAN_BLUE, TEMPLE_SUNSET, APOLLO_SKY, MYTHIC_FOREST, NETHER_EMBER, END_RELICS, CLEAR_ARENA, VANILLA_REFINED, USER }
        public final EnumSetting<Preset> preset = add(new EnumSetting<>("preset", "World preset", Preset.OLYMPUS_DAYLIGHT));
        public final DoubleSetting distance = add(new DoubleSetting("distance", "Fog distance", 1.0, 0.3, 3.0, 0.05)).desc("Multiplier for terrain fog start/end. Not a shader.");
        public final DoubleSetting tint = add(new DoubleSetting("tint", "Fog tint strength", 0.35, 0.0, 1.0, 0.05));
        public final ColorSetting userColor = add(new ColorSetting("user_color", "User fog colour", 0xFF8FB8E8));
        public final BoolSetting otherDims = add(new BoolSetting("other_dimensions", "Apply in Nether/End", false));
        public WorldFog() { super("world_fog", "World Visuals", "Fog colour and distance presets (vanilla fog only, no shader pipeline).", Category.WORLD, false); userColor.visibleWhen(() -> preset.get() == Preset.USER); }
        public int color() {
            return switch (preset.get()) {
                case OLYMPUS_DAYLIGHT -> 0xFFA9C8F0; case AEGEAN_BLUE -> 0xFF5E9BD6; case TEMPLE_SUNSET -> 0xFFE8A36A; case APOLLO_SKY -> 0xFFF2DFA0;
                case MYTHIC_FOREST -> 0xFF7FA88A; case NETHER_EMBER -> 0xFF8A3A22; case END_RELICS -> 0xFF4A3A6A; case CLEAR_ARENA -> 0xFFD8E4F0;
                case VANILLA_REFINED -> 0xFFC0D8FF; case USER -> userColor.argb();
            };
        }
        public double distanceMul() { return switch (preset.get()) { case CLEAR_ARENA -> 1.8; case MYTHIC_FOREST -> 0.75; case TEMPLE_SUNSET -> 0.9; default -> 1.0; } * distance.d(); }
    }

    public static final class Companion extends Module {
        public enum Side { RIGHT, LEFT }
        public final ChoiceSetting type = add(new ChoiceSetting("type", "Companion", "olympus_owl", Companions::ids));
        public final DoubleSetting scale = add(new DoubleSetting("scale", "Size", 1.0, 0.5, 2.0, 0.05));
        public final EnumSetting<Side> side = add(new EnumSetting<>("side", "Side", Side.RIGHT));
        public final DoubleSetting height = add(new DoubleSetting("height", "Height", 1.1, 0.0, 2.5, 0.05));
        public final DoubleSetting smoothing = add(new DoubleSetting("smoothing", "Follow smoothing", 0.18, 0.05, 0.6, 0.01));
        public final BoolSetting trail = add(new BoolSetting("trail", "Companion trail", true));
        public final BoolSetting firstPerson = add(new BoolSetting("first_person", "Visible in first person", true));
        public Companion() { super("companion", "Companions", "Local-only decorative companion. Other players do not see it (that needs a server component).", Category.COMPANIONS, false); }
        @Override public boolean heavy() { return true; }
    }

    public static final class Particles extends Module {
        public final DoubleSetting intensity = add(new DoubleSetting("intensity", "Intensity", 0.8, 0.0, 2.0, 0.05));
        public final EnumSetting<QualityLevel> quality = add(new EnumSetting<>("quality", "Quality", QualityLevel.BALANCED));
        public final IntSetting max = add(new IntSetting("max_particles", "Max live particles", 900, 50, 3000, 50));
        public final DoubleSetting firstPersonDensity = add(new DoubleSetting("first_person_density", "First-person density", 0.7, 0.0, 1.0, 0.05)).desc("Fewer particles near the camera in first person.");
        public final BoolSetting animate = add(new BoolSetting("animate", "Animate alpha/colour/rotation", true));
        public Particles() { super("particles", "Particle Engine", "Budget, quality and intensity for all Ancient Visuals effects.", Category.PARTICLES, true); }
    }

    public static final class Ambient extends Module {
        public final ChoiceSetting effect = add(FxChoice.of("effect", "Ambient effect", Trigger.AMBIENT, "fireflies"));
        public final ChoiceSetting idle = add(FxChoice.of("idle", "Idle effect", Trigger.IDLE, "spirit_wisps"));
        public final IntSetting idleSeconds = add(new IntSetting("idle_seconds", "Idle after", 8, 3, 60)).suffix(" s");
        public Ambient() { super("ambient_particles", "Ambient Particles", "Soft ambient particles around you and idle effects.", Category.PARTICLES, false); }
        @Override public boolean heavy() { return true; }
    }

    public static final class Performance extends Module {
        public final BoolSetting adaptive = add(new BoolSetting("adaptive", "Adaptive quality", true)).desc("Lowers particle quality when FPS drops below the target, raises it back later.");
        public final IntSetting targetFps = add(new IntSetting("target_fps", "Target FPS", 60, 20, 240, 5));
        public final EnumSetting<QualityLevel> maxQuality = add(new EnumSetting<>("max_quality", "Max quality", QualityLevel.HIGH));
        public final BoolSetting pauseInMenus = add(new BoolSetting("pause_in_menus", "No effects behind menus", true));
        public Performance() { super("performance", "Performance Lab", "Adaptive quality and budgets. Presets: Low / Balanced / High / Ultra.", Category.PERFORMANCE, true); }
    }

    public static final class Developer extends Module {
        public final BoolSetting overlay = add(new BoolSetting("overlay", "Debug overlay", false));
        public final BoolSetting logEvents = add(new BoolSetting("log_events", "Log FX events", false));
        public Developer() { super("developer", "Developer Tools", "Debug overlay, event log, safe-mode helpers.", Category.SYSTEM, false); }
    }

    public static final class Hud extends Module {
        public final ChoiceSetting skin = add(new ChoiceSetting("skin", "HUD skin", "olympus_azure", HudSkin::ids));
        public final BoolSetting hideAll = add(new BoolSetting("hide_all", "Hide all overlays", false));
        public final DoubleSetting globalScale = add(new DoubleSetting("scale", "Global scale", 1.0, 0.5, 2.0, 0.05));
        public final BoolSetting hideInDebug = add(new BoolSetting("hide_in_debug", "Hide with F3", true));
        public final BoolSetting textShadow = add(new BoolSetting("text_shadow", "Text shadow", true));
        public final IntSetting safeArea = add(new IntSetting("safe_area", "Safe area margin", 4, 0, 40));
        public Hud() { super("hud", "HUD", "Global HUD settings. Each element is its own module in this category.", Category.HUD, true); }
        @Override public boolean alwaysOn() { return true; }
    }

    public static final class Emotes extends Module {
        public final BoolSetting particles = add(new BoolSetting("particles", "Emote particles", true));
        public final BoolSetting notice = add(new BoolSetting("notice", "Action-bar notice", true));
        public Emotes() { super("emotes", "Emotes", "Local emotes from the radial menu (default key: B). Visible only to you.", Category.MODEL, true); }
    }
}
