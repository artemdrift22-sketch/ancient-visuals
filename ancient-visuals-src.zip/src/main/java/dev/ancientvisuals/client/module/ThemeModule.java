package dev.ancientvisuals.client.module;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.core.module.Category;
import dev.ancientvisuals.core.module.Module;
import dev.ancientvisuals.core.setting.BoolSetting;
import dev.ancientvisuals.core.setting.ChoiceSetting;
import dev.ancientvisuals.core.setting.DoubleSetting;
import dev.ancientvisuals.core.theme.Palette;
import dev.ancientvisuals.core.theme.ResolvedTheme;
import dev.ancientvisuals.core.theme.Shell;
import dev.ancientvisuals.core.theme.Themes;

import java.util.ArrayList;
import java.util.List;

public final class ThemeModule extends Module {
    public final ChoiceSetting shell = add(new ChoiceSetting("shell", "Shell", "olympus", Themes::shellIds)).desc("GUI structure: layout, geometry, controls, ornament placement.");
    public final ChoiceSetting palette = add(new ChoiceSetting("palette", "Colour theme", "auto", ThemeModule::paletteOptions)).desc("'auto' uses the palette recommended by the shell.");
    public final BoolSetting animations = add(new BoolSetting("animations", "Animations", true));
    public final DoubleSetting animSpeed = add(new DoubleSetting("anim_speed", "Animation speed", 1.0, 0.25, 3.0, 0.05));
    public final DoubleSetting panelAlpha = add(new DoubleSetting("panel_alpha", "Panel opacity", 1.0, 0.3, 1.0, 0.05));
    public final DoubleSetting ornament = add(new DoubleSetting("ornament", "Ornament intensity", 1.0, 0.0, 1.5, 0.05)).desc("Ornaments live inside components; 0 removes them.");
    public final BoolSetting textShadow = add(new BoolSetting("text_shadow", "Text shadow", true));

    public ThemeModule() { super("theme", "Theme", "Interface shells and colour themes.", Category.GUI, true); }
    @Override public boolean alwaysOn() { return true; }

    static List<String> paletteOptions() { List<String> l = new ArrayList<>(); l.add("auto"); l.addAll(Themes.paletteIds()); return l; }

    public Palette basePalette() {
        Shell s = Themes.shell(shell.get());
        String id = palette.get();
        if ("auto".equals(id)) return Themes.palette(s.palette());
        if ("user_custom".equals(id) && AV.customPalette != null) return AV.customPalette;
        return Themes.palette(id);
    }

    public ResolvedTheme resolve() {
        Shell s = Themes.shell(shell.get());
        Palette p = basePalette();
        boolean hc = AV.access != null && AV.access.isEnabled() && AV.access.highContrast.on();
        boolean reduced = AV.access != null && AV.access.isEnabled() && AV.access.reducedMotion.on();
        if (hc) p = p.highContrast();
        return new ResolvedTheme(s, p, s.layout(), s.corner(), s.radius(), s.ornament(), s.ornamentIntensity() * ornament.d(), s.rowHeight(), s.padding(),
            hc ? 1.0 : panelAlpha.d(), animations.on() && !reduced, animSpeed.d(), hc, textShadow.on());
    }
}
