package dev.ancientvisuals.client.module;

import dev.ancientvisuals.client.AV;
import dev.ancientvisuals.core.module.Category;
import dev.ancientvisuals.core.module.Module;
import dev.ancientvisuals.core.setting.*;
import dev.ancientvisuals.core.util.Colors;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

public final class CrosshairModule extends Module {
    public enum Style { CLASSIC_PLUS, TINY_DOT, RING, FOUR_LINES, HOLLOW_SQUARE, DIAMOND, GREEK_DIAMOND, MINIMAL_RUNE, CIRCLE_DOT, PRECISION_BRACKETS, THEME, CUSTOM }
    public final EnumSetting<Style> style = add(new EnumSetting<>("style", "Style", Style.CLASSIC_PLUS));
    public final IntSetting size = add(new IntSetting("size", "Size", 5, 1, 20));
    public final IntSetting thickness = add(new IntSetting("thickness", "Thickness", 1, 1, 4));
    public final IntSetting gap = add(new IntSetting("gap", "Gap", 2, 0, 10));
    public final ColorSetting color = add(new ColorSetting("color", "Colour", 0xFFF4F1EA));
    public final BoolSetting outline = add(new BoolSetting("outline", "Outline", true));
    public final ColorSetting outlineColor = add(new ColorSetting("outline_color", "Outline colour", 0xB0101418));
    public final DoubleSetting opacity = add(new DoubleSetting("opacity", "Opacity", 1.0, 0.1, 1.0, 0.05));
    public final BoolSetting centerDot = add(new BoolSetting("center_dot", "Centre dot", false));
    public final BoolSetting dynamicGap = add(new BoolSetting("dynamic_gap", "Cooldown animation", true)).desc("The gap widens while the attack cooldown recharges.");
    public final BoolSetting targetTint = add(new BoolSetting("target_tint", "Tint when aiming at an entity", true));
    public final ColorSetting targetColor = add(new ColorSetting("target_color", "Entity colour", 0xFFFF7A6B));
    public final BoolSetting thirdPerson = add(new BoolSetting("third_person", "Show in third person", false));
    public final BoolSetting attackBar = add(new BoolSetting("attack_bar", "Cooldown bar", false));
    public final BoolSetting contrast = add(new BoolSetting("contrast_helper", "Contrast helper", false)).desc("Forces a strong outline so the crosshair stays visible on bright blocks.");
    public final TextSetting pattern = add(new TextSetting("pattern", "Custom pattern", "00100|00100|11211|00100|00100", 400)).desc("Rows separated by '|': 0 empty, 1 main colour, 2 accent.");
    public final IntSetting patternScale = add(new IntSetting("pattern_scale", "Pattern scale", 1, 1, 4));
    public final ActionSetting presetPrecision = add(new ActionSetting("preset_precision", "Preset: Precision", () -> preset(Style.PRECISION_BRACKETS, 4, 1, 3, true, true)));
    public final ActionSetting presetMinimal = add(new ActionSetting("preset_minimal", "Preset: Minimal dot", () -> preset(Style.TINY_DOT, 2, 2, 0, true, false)));
    public final ActionSetting presetOlympus = add(new ActionSetting("preset_olympus", "Preset: Greek diamond", () -> preset(Style.GREEK_DIAMOND, 5, 1, 2, true, false)));

    public CrosshairModule() {
        super("crosshair", "Crosshair", "12 crosshair styles, outline, cooldown animation, entity tint and custom patterns.", Category.COMBAT, true);
        pattern.visibleWhen(() -> style.get() == Style.CUSTOM);
        patternScale.visibleWhen(() -> style.get() == Style.CUSTOM);
        targetColor.visibleWhen(targetTint::on);
    }

    private void preset(Style s, int sz, int th, int gp, boolean ol, boolean dot) { style.set(s); size.set(sz); thickness.set(th); gap.set(gp); outline.set(ol); centerDot.set(dot); }

    private static final class Grid {
        final byte[][] g; final int r, n;
        Grid(int r) { this.r = r; this.n = 2 * r + 1; g = new byte[n][n]; }
        void set(int x, int y, int v) { int gx = x + r, gy = y + r; if (gx >= 0 && gy >= 0 && gx < n && gy < n) g[gy][gx] = (byte) v; }
        void rect(int x, int y, int w, int h, int v) { for (int j = 0; j < h; j++) for (int i = 0; i < w; i++) set(x + i, y + j, v); }
        void ring(double rad, int t, int v) { for (int y = -r; y <= r; y++) for (int x = -r; x <= r; x++) { double d = Math.sqrt(x * x + y * y); if (d >= rad - t / 2.0 && d < rad + t / 2.0) set(x, y, v); } }
        void diamond(int rad, int t, int v) { for (int y = -r; y <= r; y++) for (int x = -r; x <= r; x++) { int m = Math.abs(x) + Math.abs(y); if (m <= rad && m > rad - t) set(x, y, v); } }
    }

    private String key;
    private List<int[]> runs = List.of();

    /** Horizontal runs {x, y, width, value} relative to the centre. value: 1 main, 2 accent, 3 outline. */
    public List<int[]> runs(int extraGap) {
        Style st = style.get();
        int s = size.i(), t = thickness.i(), g = gap.i() + extraGap;
        boolean ol = outline.on() || contrast.on();
        String k = st + ":" + s + ":" + t + ":" + g + ":" + ol + ":" + centerDot.on() + ":" + pattern.get() + ":" + patternScale.i();
        if (k.equals(key)) return runs;
        int rad = s + g + t + 6;
        if (st == Style.CUSTOM) rad = Math.max(rad, 48);
        Grid G = new Grid(rad);
        int h = (t - 1) / 2;
        switch (st) {
            case CLASSIC_PLUS, THEME -> {
                G.rect(-g - s, -h, s, t, 1); G.rect(g + 1, -h, s, t, 1); G.rect(-h, -g - s, t, s, 1); G.rect(-h, g + 1, t, s, 1);
                if (st == Style.THEME) { G.diamond(1, 2, 2); }
            }
            case TINY_DOT -> { int d = Math.max(1, t + s / 6); G.rect(-(d - 1) / 2, -(d - 1) / 2, d, d, 1); }
            case RING -> G.ring(s + g / 2.0, t, 1);
            case FOUR_LINES -> { for (int i = g + 1; i <= g + s; i++) { G.rect(i - h, i - h, t, t, 1); G.rect(-i - h, i - h, t, t, 1); G.rect(i - h, -i - h, t, t, 1); G.rect(-i - h, -i - h, t, t, 1); } }
            case HOLLOW_SQUARE -> { int r = s + g; G.rect(-r, -r, 2 * r + 1, t, 1); G.rect(-r, r - t + 1, 2 * r + 1, t, 1); G.rect(-r, -r, t, 2 * r + 1, 1); G.rect(r - t + 1, -r, t, 2 * r + 1, 1); }
            case DIAMOND -> G.diamond(s + g, t, 1);
            case GREEK_DIAMOND -> {
                int r = s + g / 2; G.diamond(r, t, 1); G.set(0, 0, 2);
                G.rect(r + 2, 0, 2, 1, 2); G.rect(-r - 3, 0, 2, 1, 2); G.rect(0, r + 2, 1, 2, 2); G.rect(0, -r - 3, 1, 2, 2);
            }
            case MINIMAL_RUNE -> { int w = g + 2; G.rect(-h, -s, t, 2 * s + 1, 1); G.rect(-w - h, -s, t, s, 1); G.rect(w - h, -s, t, s, 1); G.rect(-w, -h, 2 * w + 1, t, 1); }
            case CIRCLE_DOT -> { G.ring(s + g, t, 1); G.rect(-h, -h, t, t, 2); }
            case PRECISION_BRACKETS -> {
                int r = s + g, L = Math.max(2, s / 2 + 1);
                G.rect(-r, -r, L, t, 1); G.rect(-r, -r, t, L, 1);
                G.rect(r - L + 1, -r, L, t, 1); G.rect(r - t + 1, -r, t, L, 1);
                G.rect(-r, r - t + 1, L, t, 1); G.rect(-r, r - L + 1, t, L, 1);
                G.rect(r - L + 1, r - t + 1, L, t, 1); G.rect(r - t + 1, r - L + 1, t, L, 1);
                G.set(0, 0, 2);
            }
            case CUSTOM -> {
                String[] rows = pattern.get().split("\\|");
                int k2 = patternScale.i(), pw = 0;
                for (String row : rows) pw = Math.max(pw, row.length());
                int ox = -(pw * k2) / 2, oy = -(rows.length * k2) / 2;
                for (int y = 0; y < rows.length; y++) for (int x = 0; x < rows[y].length(); x++) {
                    char c = rows[y].charAt(x);
                    int v = c == '2' ? 2 : (c == '1' || c == '#' || c == 'x' || c == 'X') ? 1 : 0;
                    if (v > 0) G.rect(ox + x * k2, oy + y * k2, k2, k2, v);
                }
            }
        }
        if (centerDot.on()) G.rect(-h, -h, t, t, 2);
        if (ol) {
            byte[][] o = new byte[G.n][G.n];
            for (int y = 0; y < G.n; y++) for (int x = 0; x < G.n; x++) {
                if (G.g[y][x] != 0) continue;
                outer:
                for (int dy = -1; dy <= 1; dy++) for (int dx = -1; dx <= 1; dx++) {
                    int yy = y + dy, xx = x + dx;
                    if (yy >= 0 && xx >= 0 && yy < G.n && xx < G.n && G.g[yy][xx] != 0 && G.g[yy][xx] != 3) { o[y][x] = 3; break outer; }
                }
            }
            for (int y = 0; y < G.n; y++) for (int x = 0; x < G.n; x++) if (o[y][x] == 3) G.g[y][x] = 3;
        }
        List<int[]> out = new ArrayList<>();
        for (int y = 0; y < G.n; y++) {
            int x = 0;
            while (x < G.n) {
                int v = G.g[y][x];
                if (v == 0) { x++; continue; }
                int x0 = x;
                while (x < G.n && G.g[y][x] == v) x++;
                out.add(new int[]{x0 - G.r, y - G.r, x - x0, v});
            }
        }
        key = k; runs = out;
        return out;
    }

    public void render(DrawContext c, int cx, int cy, float hitPulse) {
        MinecraftClient mc = MinecraftClient.getInstance();
        float cd = mc.player != null ? mc.player.getAttackCooldownProgress(0f) : 1f;
        int extra = dynamicGap.on() && cd < 1f ? Math.round((1f - cd) * 3f) : 0;
        var pal = AV.theme().palette();
        int main = style.get() == Style.THEME ? pal.primary() : color.argb();
        if (targetTint.on() && mc.targetedEntity != null) main = targetColor.argb();
        if (hitPulse > 0 && AV.hitFx != null && AV.hitFx.isEnabled() && AV.hitFx.hitColor.on()) main = Colors.lerp(main, AV.hitFx.hitColorValue.argb(), Math.min(1f, hitPulse));
        int accent = pal.accent();
        int ocol = contrast.on() ? Colors.withAlpha(0xFF000000, Math.max(Colors.a(outlineColor.argb()), 210)) : outlineColor.argb();
        double op = opacity.d();
        for (int[] r : runs(extra)) {
            int col = r[3] == 1 ? main : r[3] == 2 ? accent : ocol;
            c.fill(cx + r[0], cy + r[1], cx + r[0] + r[2], cy + r[1] + 1, Colors.mulAlpha(col, op));
        }
        if (attackBar.on() && cd < 1f) {
            int w = 16, y = cy + size.i() + gap.i() + 6;
            c.fill(cx - w / 2 - 1, y - 1, cx + w / 2 + 1, y + 2, 0x90101418);
            c.fill(cx - w / 2, y, cx - w / 2 + Math.round(w * cd), y + 1, Colors.mulAlpha(accent, op));
        }
    }
}
