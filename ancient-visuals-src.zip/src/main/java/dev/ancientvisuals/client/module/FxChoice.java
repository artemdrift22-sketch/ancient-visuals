package dev.ancientvisuals.client.module;

import dev.ancientvisuals.client.fx.Effects;
import dev.ancientvisuals.core.particle.Trigger;
import dev.ancientvisuals.core.setting.ChoiceSetting;

/** Factory for "which effect plays on this trigger" settings. */
final class FxChoice {
    private FxChoice() {}
    static ChoiceSetting of(String id, String name, Trigger t, String preferred) {
        String def = Effects.options().contains(preferred) ? preferred : Effects.firstFor(t, "none");
        return new ChoiceSetting(id, name, def, Effects::options).desc("Effect played on: " + t.name().toLowerCase().replace('_', ' ') + ". 'none' disables it.");
    }
}
