package dev.ancientvisuals;

import dev.ancientvisuals.core.companion.Companions;
import dev.ancientvisuals.core.config.ConfigStore;
import dev.ancientvisuals.core.hud.Anchor;
import dev.ancientvisuals.core.hud.HudLayout;
import dev.ancientvisuals.core.json.Json;
import dev.ancientvisuals.core.particle.EffectCatalog;
import dev.ancientvisuals.core.search.ActionRegistry;
import dev.ancientvisuals.core.setting.IntSetting;
import dev.ancientvisuals.core.texture.*;
import dev.ancientvisuals.core.theme.Palette;
import dev.ancientvisuals.core.theme.Themes;
import dev.ancientvisuals.core.util.Colors;
import dev.ancientvisuals.core.util.Fuzzy;
import dev.ancientvisuals.core.util.UndoStack;
import org.junit.jupiter.api.Test;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

/** Pure-Java tests for the Minecraft-independent core. */
public class CoreTests {

    @Test void jsonRoundTrip() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("a", 1.5); m.put("b", "текст \"q\""); m.put("c", List.of(true, false)); m.put("d", null);
        Object back = Json.parse(Json.write(m, true));
        assertTrue(back instanceof Map);
        Map<?, ?> b = (Map<?, ?>) back;
        assertEquals("текст \"q\"", b.get("b"));
        assertEquals(1.5, ((Number) b.get("a")).doubleValue(), 1e-9);
        assertEquals(2, ((List<?>) b.get("c")).size());
    }

    @Test void colorsHexAndContrast() {
        int c = Colors.argb(255, 18, 52, 86);
        assertEquals("#FF123456", Colors.toHex(c));
        assertEquals(c, Colors.parseHex("#FF123456"));
        assertTrue(Colors.contrast(0xFFFFFFFF, 0xFF000000) > 20.0);
        assertEquals(255, Colors.a(c));
    }

    @Test void fuzzyPrefersMatches() {
        assertTrue(Fuzzy.score("hud", "HUD Editor") > Fuzzy.score("zzq", "HUD Editor"));
    }

    @Test void undoStack() {
        UndoStack<String> u = new UndoStack<>(3);
        u.push("a");
        assertTrue(u.canUndo());
        assertEquals("a", u.undo("b"));
        assertTrue(u.canRedo());
        assertEquals("b", u.redo("a"));
        for (int i = 0; i < 10; i++) u.push("x" + i);
        assertTrue(u.undoSize() <= 3);
    }

    @Test void intSettingClamps() {
        IntSetting s = new IntSetting("x", "X", 5, 0, 10);
        s.set(50);
        assertTrue(s.get() <= 10);
        s.reset();
        assertEquals(5, (int) s.get());
    }

    @Test void catalogHas80UniqueEffects() {
        List<String> ids = EffectCatalog.ids();
        assertEquals(80, ids.size());
        assertEquals(80, new HashSet<>(ids).size());
    }

    @Test void companionsAndSkins() {
        assertEquals(20, Companions.ids().size());
        assertEquals(new HashSet<>(HudSkin.ids()).size(), HudSkin.ids().size());
        assertTrue(HudSkin.ids().size() >= 15);
    }

    @Test void palettesValid() {
        Set<String> ids = new HashSet<>();
        for (Palette p : Themes.PALETTES) { assertTrue(ids.add(p.id())); assertNotNull(p.validate()); }
        assertTrue(ids.size() >= 20);
        assertTrue(Themes.SHELLS.size() >= 18);
    }

    @Test void packPaths() {
        assertTrue(PackWriter.validPath("assets/minecraft/textures/gui/a.png"));
        assertFalse(PackWriter.validPath("../evil.png"));
        assertFalse(PackWriter.validPath("/abs/a.png"));
        assertFalse(PackWriter.validPath("assets//a.png"));
        assertFalse(PackWriter.validPath("Assets/A.png"));
    }

    @Test void pixelCanvasOpsAndPng() throws Exception {
        PixelCanvas c = new PixelCanvas(4, 4);
        c.checkpoint();
        c.set(0, 0, 0xFFFF0000);
        c.mirrorHorizontal();
        assertEquals(0xFFFF0000, c.get(3, 0));
        assertTrue(c.undo());
        assertEquals(0, Colors.a(c.get(3, 0)));
        assertTrue(c.redo());
        PixelCanvas back = PngIO.read(PngIO.encode(c));
        assertEquals(4, back.width());
        assertEquals(c.get(3, 0), back.get(3, 0));
    }

    @Test void guiRecipes() throws Exception {
        assertEquals(16, GuiRecipes.ALL.size());
        assertEquals(21, GuiRecipes.TARGETS.size());
        PixelCanvas src = new PixelCanvas(8, 8);
        for (int y = 0; y < 8; y++) for (int x = 0; x < 8; x++) src.set(x, y, 0xFFC6C6C6);
        PixelCanvas out = GuiRecipes.apply(GuiRecipes.ALL.get(0), src);
        assertEquals(8, out.width());
    }

    @Test void packWriterFolder() throws Exception {
        Path dir = Files.createTempDirectory("avpack");
        PackWriter w = new PackWriter("test");
        w.put("assets/minecraft/textures/item/a.png", PngIO.encode(new PixelCanvas(2, 2)));
        Path root = w.writeFolder(dir, "AV Test");
        assertTrue(Files.exists(root.resolve("pack.mcmeta")));
        PackInspector.Report r = PackInspector.inspectFolder(root);
        assertTrue(r.ok());
        assertEquals(PackWriter.PACK_FORMAT, r.packFormat);
    }

    @Test void configStoreRoundTrip() throws Exception {
        Path dir = Files.createTempDirectory("avcfg");
        ConfigStore cs = new ConfigStore(dir);
        cs.load();
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("hello", "world");
        assertTrue(cs.save(m));
        ConfigStore.LoadResult r = new ConfigStore(dir).load();
        assertNotNull(r.data());
        assertEquals("world", r.data().get("hello"));
    }

    @Test void hudLayoutRoundTrip() {
        HudLayout l = new HudLayout();
        l.register("t", Anchor.TOP_LEFT, 5, 7);
        l.box("t").offsetX = 40;
        String s = l.serialize();
        HudLayout l2 = new HudLayout();
        l2.register("t", Anchor.TOP_LEFT, 5, 7);
        l2.deserialize(s);
        assertEquals(40, l2.box("t").offsetX, 1e-6);
        l2.resetBox("t");
        assertEquals(5, l2.box("t").offsetX, 1e-6);
    }

    @Test void actionSearch() {
        ActionRegistry a = new ActionRegistry();
        a.register("tool.hud", "HUD Editor", "tools", "layout", () -> { });
        a.register("tool.lab", "Texture Lab", "tools", "paint", () -> { });
        List<ActionRegistry.Hit> hits = a.search("hud", 5);
        assertFalse(hits.isEmpty());
        assertEquals("tool.hud", hits.get(0).action().id());
    }
}
